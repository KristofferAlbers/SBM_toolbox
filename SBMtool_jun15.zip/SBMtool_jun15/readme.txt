classtest	: is the compiled SBM toolbox
GUI.jar 	: is the java GUI to create runscripts. 
vegas		: folder contains the source code for the SBM toolbox
vegas/bin/Release/GUI/src/gui 	: folder contains the source code for the gui
