/**
This code is provided as is without any warranty!

Implementation of the Metropolis-Hastings sampling (random walker)
for real valued parameters. Defines the user settings/options and
implements the sample() function
*/

#include "Sampler.h"

const std::string MetropolisHastings_real::SAMPLERNAME = "MetropolisHastings_real";

Creator<MCMC_sampler, MetropolisHastings_real> MetropolisHastings_real::Create(MetropolisHastings_real::SAMPLERNAME);

const std::vector<SettingDescription> MetropolisHastings_real::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The real parameter to sample") },
    {   SettingDescription("sweeps","INT",false).initialInt(1).min(1).shortDescription("Number of samples")},
    {   SettingDescription("stddev","FLOAT",false).initialFloat(1.0).shortDescription("std. deviation for drawing proposals")},
    {   SettingDescription("logdomain","BOOL",false).initialBool(false).shortDescription("compute in log domain")}
};

void MetropolisHastings_real::sample()
{
    accepts = 0;
    proposals = 0;
    for(size_t t = 0 ; t<sweeps ; t++)
    {
        proposals ++;
        double par = parameter_->get();
        double newpar;
        double r;
        if(compinlog)
        {
            double lognewpar = log(par) + proposal(generator);
            newpar = exp(lognewpar);
            r = parameter_->logPosteriorRatio(newpar) + lognewpar - log(par);
        }
        else
        {
            newpar = par + proposal(generator);
            r = parameter_->logPosteriorRatio(newpar);
        }
        bool accept = exp(r) > uniform(generator);
        if (accept)
        {
            parameter_->set(newpar);
            accepts++;
        }
    }
}
