/**
This code is provided as is without any warranty!

An object of class Clustering_finite is a performance optimized
representation of a clustering with a finite number of clusters.
It implements two sequence iteratiors:
    - for iterating over all clusters
    - for iterationg over all nodes assigned to a given cluster
*/

#ifndef CLUSTERING_FINAL_H_INCLUDED
#define CLUSTERING_FINAL_H_INCLUDED

#include <boost/units/detail/utility.hpp>
#include <typeinfo>
#include <sstream>
#include <iostream>
#include <vector>


class Clustering_finite
{
public:
    struct clusterIdPos
    {
        size_t clusterId, clusterPos;
    };
    friend class ClusteringDocument;
private:
    std::vector<clusterIdPos> items;
    std::vector<bool> itemAssigned;
    std::vector<std::vector<size_t>> clusters;
    std::vector<size_t> clusterSizes;
    size_t numItems;
    size_t numClusters;
    size_t numNonEmptyClusters;
public:
    Clustering_finite() {};

    Clustering_finite(size_t numberOfItems, size_t numberOfClusters)
    {
        clusters.resize(numberOfClusters);
        clusterSizes.resize(numberOfClusters);

        items.resize(numberOfItems);
        itemAssigned.resize(numberOfItems);

        numItems = numberOfItems;
        numClusters = numberOfClusters;
        numNonEmptyClusters = 0;
    };


    Clustering_finite(size_t numberOfItems, size_t numberOfClusters, std::vector<size_t>& clusteringVector)
    {
        clusters.resize(numberOfClusters);
        clusterSizes.resize(numberOfClusters);

        items.resize(numberOfItems);
        itemAssigned.resize(numberOfItems);

        numItems = numberOfItems;
        numClusters = numberOfClusters;
        numNonEmptyClusters = 0;

        for(size_t i = 0; i<clusteringVector.size(); i++)
        {
            if(i >= numberOfItems || clusteringVector[i]>=numberOfClusters)
            {
                std::cout<<"numberOfItems or numberOfClusters found in clusteringVector larger than defined!"<< std::endl; exit(0);
                //std::cout << "argh! " << i << " " << clusteringVector[i] << std::endl;
            }
            addItem(i,clusteringVector[i]);
        }
    };

    virtual ~Clustering_finite()
    {
       // std::cout << " clustering  destroyed " << std::endl;
    }

    void addItem(size_t itemId, size_t clusterId);
    void removeItem(size_t itemId);
    void moveItem(size_t itemId, size_t clusterId);

    size_t getClusterId(size_t itemId);
    bool isempty(size_t clusterId);
    bool assigned(size_t itemId);
    size_t getSize(size_t clusterId);

    size_t getNumberOfClusters();
    size_t getNumberOfNonEmptyClusters();

    size_t getNumberOfItems();


    friend std::ostream& operator<<(std::ostream&, Clustering&);
    std::string toString();


    void print()
    {
        std::cout << "cluster\tsize\titems"<<std::endl;
        for(size_t i = 0; i<clusters.size(); i++)
        {
            std::cout << i << "\t("<< clusterSizes[i]<<")\t";
            for(size_t n = 0; n<clusters[i].size(); n++)
            {
                if(itemAssigned[clusters[i][n]])
                    std::cout << "" << clusters[i][n] << " ";

            }

            std::cout<<std::endl;
        }


    }


    class iterator;
    iterator begin();
    iterator end();

    class clusterIterator;
    clusterIterator begin(size_t clusterId);
    clusterIterator end(size_t clusterId);

};


inline void Clustering_finite::addItem(size_t itemId, size_t clusterId)
{
    assert(itemAssigned[itemId] == false);

    clusters[clusterId].push_back(itemId);

    if(clusterSizes[clusterId] == 0)
    {
        numNonEmptyClusters ++;
    }
    clusterSizes[clusterId]++;

    items[itemId] = {clusterId, clusters[clusterId].size()-1};
    itemAssigned[itemId] = true;
}

// Removes an item from its cluster
inline void Clustering_finite::removeItem(size_t itemId)
{

    size_t clusterId = items[itemId].clusterId;
    size_t clusterPos = items[itemId].clusterPos;

    size_t lastInCluster_itemId = clusters[clusterId].back();
    clusters[clusterId][clusterPos] = lastInCluster_itemId;
    clusters[clusterId].pop_back();
    clusterSizes[clusterId]--;

    items[lastInCluster_itemId].clusterPos = clusterPos;
    itemAssigned[itemId] = false;

    if(clusterSizes[clusterId] == 0)
    {
        numNonEmptyClusters --;
    }
}

inline size_t Clustering_finite::getClusterId(size_t itemId)
{
    assert(itemAssigned[itemId]);
    return(items[itemId].clusterId);
}

inline bool Clustering_finite::isempty(size_t clusterId)
{
    return clusterSizes[clusterId]==0;
}

inline bool Clustering_finite::assigned(size_t itemId)
{
    return itemAssigned[itemId];
}

inline size_t Clustering_finite::getSize(size_t clusterId)
{
    return clusterSizes[clusterId];
}

inline size_t Clustering_finite::getNumberOfClusters()
{
    return numClusters;
}

inline size_t Clustering_finite::getNumberOfNonEmptyClusters()
{
    return numNonEmptyClusters;
}


inline size_t Clustering_finite::getNumberOfItems()
{
    return numItems;
}

inline std::string Clustering_finite::toString()
{
    std::stringstream s;
    for (size_t i = 0; i != getNumberOfItems(); ++i)
    {
        s << items[i].clusterId << " ";
    }
    return s.str();
}


// Moves an item into an existing cluster
inline void Clustering_finite::moveItem(size_t itemId, size_t clusterId)
{
    assert(itemAssigned[itemId] == true);

    size_t oldClusterId = items[itemId].clusterId;
    if (clusterId != oldClusterId)
    {
        removeItem(itemId);
        addItem(itemId,clusterId);
    }
}

//-----------------------------------------------------------------------------
// clustering::iterator implementation
// Iterates all clusters.
// The function index() gives the clusterId of the current cluster in the iteration step.
// Dereferencing gives a pointer to the vector storing the itemId for the given cluster.
class Clustering_finite::iterator : public std::iterator<std::forward_iterator_tag,std::vector<size_t>>
{
private:
    std::vector<std::vector<size_t>>* clusters_;
    typename std::vector<std::vector<size_t>>::iterator it_;

public:

    iterator() {};
    iterator(const iterator& other) : clusters_(other.clusters_), it_(other.it_) {};
    iterator(std::vector<std::vector<size_t>>& clusters) : clusters_(&clusters) {};
    iterator(std::vector<std::vector<size_t>>& clusters, typename std::vector<std::vector<size_t>>::iterator it) : clusters_(&clusters), it_(it) {};


    inline iterator& operator=(const iterator& other)
    {
        it_ = other.it_;
        clusters_ = other.clusters_;
        return *this;
    }


    inline iterator& operator++()
    {
        ++it_;
        return *this;
    };

    inline iterator operator++(int)
    {
        iterator temp(*this);
        operator++();
        return temp;
    }

    inline bool operator!=(const iterator other)
    {
        return it_ != other.it_;
    };
    inline bool operator==(const iterator other)
    {
        return it_ == other.it_;
    }

    inline std::vector<size_t>& operator*()
    {
        return *it_;
    };

    inline std::vector<size_t>* operator->()
    {
        return &(*it_);
    }


    inline size_t index()
    {
        //return it_.index(); //TODO verify!
        return it_ - clusters_->begin();

    }

};




inline Clustering_finite::iterator Clustering_finite::begin()
{
    return iterator(clusters,clusters.begin());
};

inline Clustering_finite::iterator Clustering_finite::end()
{
    return iterator(clusters,clusters.end());
};



//-----------------------------------------------------------------------------
// clustering::clusterIterator implementation
// Iterates all items assigned to a given cluster.
// Dereferencing gives the itemId.
class Clustering_finite::clusterIterator : public std::iterator<std::forward_iterator_tag,std::vector<size_t>>
{
private:
    std::vector<size_t>* cluster_;
    typename std::vector<size_t>::iterator it_;

public:

    clusterIterator() {};
    clusterIterator(const clusterIterator& other) : cluster_(other.cluster_), it_(other.it_) {};
    clusterIterator(std::vector<size_t>& cluster) : cluster_(&cluster) {};
    clusterIterator(std::vector<size_t>& cluster, typename std::vector<size_t>::iterator it) : cluster_(&cluster), it_(it) {};

    inline clusterIterator& operator++()
    {
        ++it_;
        return *this;
    };

    inline clusterIterator operator++(int)
    {
        clusterIterator temp(*this);
        operator++();
        return temp;
    }

    inline bool operator!=(const clusterIterator other)
    {
        return it_ != other.it_;
    };
    inline bool operator==(const clusterIterator other)
    {
        return it_ == other.it_;
    }

    inline size_t& operator*()
    {
        return *it_;
    };

    inline size_t* operator->()
    {
        return &(*it_);
    }


    inline size_t getItemId()
    {
        return *it_;
    }
    inline size_t index()
    {
        return it_-cluster_->begin();//it_.index();
    }



};

//returns a clusterIterator for the start of a single cluster
inline Clustering_finite::clusterIterator Clustering_finite::begin(size_t clusterId)
{
    std::vector<size_t>::iterator iter = clusters[clusterId].begin();
    return clusterIterator(clusters[clusterId],iter);
}
//returns a clusterIterator for the end of a single cluster
inline Clustering_finite::clusterIterator Clustering_finite::end(size_t clusterId)
{
    std::vector<size_t>::iterator iter = clusters[clusterId].end();
    return clusterIterator(clusters[clusterId],iter);
}
















#endif // CLUSTERING_FINAL_H_INCLUDED
