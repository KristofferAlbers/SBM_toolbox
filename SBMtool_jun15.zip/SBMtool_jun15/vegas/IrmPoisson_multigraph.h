#ifndef IRMPOISSON_MULTIGRAPH_H_INCLUDED
#define IRMPOISSON_MULTIGRAPH_H_INCLUDED


#include "StatisticalModel.h"
#include "Options.h"
#include "LinkCount.h"
#include "Network.h"
#include "Clustering.h"
#include "ClusteringDocument.h"

#include "tableApproximations.h"

#include <vector>
#include <boost/assign.hpp>
#include <boost/tuple/tuple.hpp>
#include <omp.h>

using namespace std::placeholders;

class IrmPoisson_multigraph : public StatisticalModel
{

template <typename T> class NodeCounts
{
public:
    std::vector<T> linkSum;
    std::vector<T> nodePairs;
    std::vector<T> missingNodePairs;
    std::vector<T> linkSum_reversed;
    std::vector<T> nodePairs_reversed;
    std::vector<T> missingNodePairs_reversed;

    void print()
    {

        std::cout << "cluster:\t linksum \t nodepairs" << std::endl;
        for(int i = 0; i < nodePairs.size(); i++)
        {   //if(!directed)
            //    std::cout << "(i = " << i << " ) \t "<< linkSum[i] << " \t " << nodePairs[i] << "\t / \t";// << linkSum_reversed[i] << "\t"<<nodePairs_reversed[i]; // << " \t " << nodeMissingLinks[i];
           // else
                std::cout << "(i = " << i << " ) \t "<< linkSum[i] << " \t " << nodePairs[i] << "\t / \t"<< linkSum_reversed[i] << "\t"<<nodePairs_reversed[i]; // << " \t " << nodeMissingLinks[i];

           // std::cout << "\t\t" << nodeLinks_transposed[i] << " \t " << nodeNonLinks_transposed[i] << " \t " << nodeMissingLinks_transposed[i] << std::endl;
           std::cout << std::endl;
        }
        std::cout << std::endl;

    }
};




struct SufficientStatistics
{
    SquareMatrix<size_t> nodePairs;
    SquareMatrix<size_t> linkSum;
    SquareMatrix<size_t> missingNodePairs;

    bool directed;
    bool withmissing;

    size_t getNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        return nodePairs.matrix[sourceCluster*nodePairs.max+targetCluster];
    }
    size_t getLinkSum(size_t sourceCluster, size_t targetCluster)
    {
        return linkSum.matrix[sourceCluster*linkSum.max+targetCluster];
    }
    size_t getMissingNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        if(withmissing)
            return missingNodePairs.matrix[sourceCluster*missingNodePairs.max+targetCluster];
        else
            return 0;
    }

};


struct HyperParameters_poisson
{
    double alpha_;
    double logalpha_;
    double a_;
    double b_;
};

struct Data
{
    UnipartiteNetwork<size_t>& network;
    NetworkData<size_t>& data;
    NetworkData<size_t>& data_transposed;
    NetworkData<size_t>& missing;
    NetworkData<size_t>& missing_transposed;

    SufficientStatistics& sufstats;
    Clustering& clustering;
    Clustering& targetClustering;
};

public:

    //clustering data
    Clustering clusteringData;

    //parameters
    ClusteringInfinite_Parameter clustering;
    Real alpha;
    Real a;
    Real b;

    //hyperparameters data
    HyperParameters_poisson param;
    //sufficient statistics
    std::vector<SufficientStatistics> sufstats;
    //options
    int nodes_;
    bool usemissing_;
    bool directed;
    std::string missinglinksfile_;
    std::string linksfile_;

    //network data
    std::vector<UnipartiteNetwork<size_t>>& networks;

    std::vector<Data> data;

    Betaln betaln_table;
    Factorialln factln_table;
    Gammaln gammaln_table;


public:
    IrmPoisson_multigraph(std::vector<UnipartiteNetwork<size_t>>& nets, ClusteringDocument& clusteringDoc, bool directed_, bool withmissing_, Options o) : StatisticalModel("irm model bernoulli",o),
        networks(nets), clustering(this,"Z"),alpha(this,"alpha"), a(this,"a"), b(this,"b"),
        betaln_table(1000,6000,7000) , gammaln_table(6000), factln_table(6000)
    {
        //bind functions
       //bind parameter functions
        clustering.effectiveLogPosteriorRatio = std::bind(&IrmPoisson_multigraph::effectiveLogPosteriorRatio_clustering,this,_1,_2,_3,_4);
        clustering.effectiveLogPosteriorRatio_restricted = std::bind(&IrmPoisson_multigraph::effectiveLogPosteriorRatio_restricted_clustering, this, _1, _2);
        clustering.logPosteriorRatio_mergeClusters = std::bind(&IrmPoisson_multigraph::effectiveLogPosteriorRatio_mergeClusters_clustering,this,_1,_2);
        clustering.moveItem = std::bind(&IrmPoisson_multigraph::moveItem_clustering, this, _1, _2);
        clustering.moveItem_newCluster = std::bind(&IrmPoisson_multigraph::moveItem_newCluster_clustering, this, _1);
        clustering.mergeClusters = std::bind(&IrmPoisson_multigraph::mergeClusters_clustering, this, _1, _2);
        clustering.getDataPointer = std::bind(&IrmPoisson_multigraph::getDataPointer_clustering,this);
        clustering.getNumberOfItems = std::bind(&IrmPoisson_multigraph::getNumberOfItems_clustering,this);
        clustering.get = std::bind(&IrmPoisson_multigraph::get_clustering,this);
        clustering.set = std::bind(&IrmPoisson_multigraph::set_clustering,this,_1);
        alpha.get = std::bind(&IrmPoisson_multigraph::get_alpha,this);
        alpha.set = std::bind(&IrmPoisson_multigraph::set_alpha,this,_1);
        alpha.logPosteriorRatio = std::bind(&IrmPoisson_multigraph::logPosteriorRatio_alpha, this, _1);
        a.get = std::bind(&IrmPoisson_multigraph::get_a,this);
        a.set = std::bind(&IrmPoisson_multigraph::set_a,this,_1);
        a.logPosteriorRatio = std::bind(&IrmPoisson_multigraph::logPosteriorRatio_a, this, _1);
        b.get = std::bind(&IrmPoisson_multigraph::get_b,this);
        b.set = std::bind(&IrmPoisson_multigraph::set_b,this,_1);
        b.logPosteriorRatio = std::bind(&IrmPoisson_multigraph::logPosteriorRatio_b, this, _1);

        directed = directed_;
        usemissing_ = withmissing_;

        clusteringData = Clustering((clusteringDoc.clusteringVector));


        std::cout << "irm poisson; alpha = bp = bm = 1" << std::endl;
        std::cout << "withmissing = " << usemissing_ << std::endl;
        std::cout << "directed    = " << directed << std::endl;
        std::cout << "number of graphs = " << nets.size() << std::endl ;

        param.alpha_ =1;
        param.a_ =1;
        param.b_ =1;

        sufstats.resize(nets.size());
        for(int i = 0; i<nets.size(); i++)
        {
            SufficientStatistics sf;
            sufstats[i] = sf;
            data.push_back({nets[i],nets[i].data,nets[i].data_transposed, nets[i].missing,  nets[i].missing_transposed, sufstats[i],clusteringData,clusteringData});
        }


        //clusteringData.removeItem(5);
        std::cout << clusteringData<< std::endl;


        computeAllSufficientStatistics();

        data[0].sufstats.linkSum.print(4);
        std::cout << std::endl;
        data[0].sufstats.nodePairs.print(4);


        std::cout << " loglikelihood: " << computeLogLikelihood() << std::endl;
        std::cout << " logprior: " << computeLogPrior() << std::endl;
        std::cout << " logposterior: " << computeLogPosterior() << std::endl;



        NodeCounts<size_t> nc;
        getNodeCounts(5,data[0],data[0].clustering,0,4,nc);
        //nc.print();

        std::cout << " ---------------- " << std::endl;

        double dloglike0 = logLikelihood_effectiveChange(0,data[0],data[0].clustering,param,0,0,3,nc);
        double dloglike1 = logLikelihood_effectiveChange(0,data[0],data[0].clustering,param,1,0,3,nc);
        double dloglike2 = logLikelihood_effectiveChange(0,data[0],data[0].clustering,param,2,0,3,nc);
        //double dloglikeNEW = logLikelihood_effectiveChange_newCluster(0,data[0],data[0].clustering,param,0,3,nc);
        double dloglike = logLikelihood_effectiveChange_newCluster(0,data[0],data[0].clustering,param,0,3,nc);


        std::cout << "dl0 = "<< dloglike0 << std::endl;
        std::cout << "dl1 = "<< dloglike1 << std::endl;
        std::cout << "dl2 = "<< dloglike2 << std::endl;
        std::cout << "dnew = "<< dloglike  << std::endl;


/*
        NodeCounts<size_t> nc;
        getNodeCounts(0,data[0],data[0].clustering,1,4,nc);
        nc.print();

*/
        std::cout << " MERGE " << effectiveLogPosteriorRatio_mergeClusters_clustering(0,1) << std::endl;


        std::cout << "----" << std::endl;

        mergeClusters_clustering(0,1);
        //mergeClusters_clustering(0,1);

        data[0].sufstats.linkSum.print(7);
        std::cout << std::endl;
        data[0].sufstats.nodePairs.print(7);

        std::cout << "ls 0,0 = " << data[0].sufstats.getLinkSum(0,0) << std::endl;
        std::cout << "ls 1,1 = " << data[0].sufstats.getLinkSum(1,1) << std::endl;
        std::cout << "ls 2,2 = " << data[0].sufstats.getLinkSum(2,2) << std::endl;



        reportInfo("model setup completed",.5);
    }


    double computeLogPrior();
    double computeLogLikelihood();
    double computeLogPosterior();
    double computeLogLikelihood(Data& data_);

    //assist functions
    void computeAllSufficientStatistics();
    void computeSufficientStatistics(Data& data_);

    void getNodeCounts(size_t nodeId, Data& data_, Clustering& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts);

    inline double logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);
    inline double logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);


    inline double logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_poisson& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts);
    double logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_poisson& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);



    //clustering functions
    partial_vector<double> effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster);
    partial_vector<double> effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters);
    double effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2);

    void moveItem_clustering(size_t itemId, size_t clusterId);
    void moveItem_newCluster_clustering(size_t itemId);
    void mergeClusters_clustering(size_t cluster1,size_t cluster2);

    Clustering* getDataPointer_clustering();
    size_t getNumberOfItems_clustering();
    ClusteringDocument get_clustering();
    void set_clustering(ClusteringDocument& cd);



    //alpha functions
    double get_alpha();
    void set_alpha(double val);
    double logPosteriorRatio_alpha(double new_alpha);

    //bp functions
    double get_a();
    void set_a(double val);
    double logPosteriorRatio_a(double new_a);

    //bm functions
    double get_b();
    void set_b(double val);
    double logPosteriorRatio_b(double new_b);


    double FUNC(size_t ai, double ad, size_t bi, double bd)
    {

        return gammaln_table.gammaln(ai,ad) - (ai+ad)*LOG(bi,bd);
    }
    inline double LOG(size_t bi, double bd)
    {
        return log(bi+bd);
    }



};





#endif // IRMPOISSON_MULTIGRAPH_H_INCLUDED
