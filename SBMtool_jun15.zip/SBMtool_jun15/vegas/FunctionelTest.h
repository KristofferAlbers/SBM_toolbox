/**


The functional test classes provides sandbox for debugging and speed testing
the application.
*/

#ifndef FUNCTIONELTEST_H_INCLUDED
#define FUNCTIONELTEST_H_INCLUDED

//#include "IrmPoisson_collapsed.h"
//#include "IrmPoisson_collapsed_finite.h"

class TestPoisson
{
public:
/*
    static void test()
    {
        std::cout << "test poisson" << std::endl;



        std::string items = "6";
        std::string subjects = "1";
        std::string components = "4";
        std::string links = "data/testNetwork3_poisson_directed.txt";
        std::string missinglinks = "data/testNetwork3_bernoulli_directed_missing.txt";
        std::string withmissing = "false";
        std::string directed = "true";

        Options modelOptions;
        modelOptions.insert( std::pair<std::string,std::string>("items", items) );
        modelOptions.insert( std::pair<std::string,std::string>("subjects", subjects) );
        modelOptions.insert( std::pair<std::string,std::string>("components", components) );
        modelOptions.insert( std::pair<std::string,std::string>("directed", directed) );
        modelOptions.insert( std::pair<std::string,std::string>("network.links", links) );
        modelOptions.insert( std::pair<std::string,std::string>("network.missinglinks", missinglinks) );
        modelOptions.insert( std::pair<std::string,std::string>("withmissing", withmissing) );
        modelOptions.insert( std::pair<std::string,std::string>("clustering.init_random", "1") );

        std::string modelName("IrmBernoulli_infinite");

        IrmPoisson_collapsed model(modelOptions);

        model.clustering.setFromString("1 1 2 0 0 0");

        //double dlikes = model.effectiveLogLikelihoodRatio_clustering(&model.data,5,0,true);
        double dlikes = model.effectiveLogPosteriorRatio_mergeClusters_clustering(0,1);
        std::cout << "  >" << dlikes << std::endl;


        double loglike_0 = -1;
        double logprior_0 = -1;
        loglike_0 = model.computeLogLikelihood();
        logprior_0 = model.computeLogPrior();


        std::cout << "log likelihood (0) = " << loglike_0 << std::endl;
        std::cout << "log prior      (0) = " << logprior_0 << std::endl;



        std::cout << "test done :)" << std::endl;


    }
    */
};
#endif // FUNCTIONELTEST_H_INCLUDED
