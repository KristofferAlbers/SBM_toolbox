#ifndef SbmBernoulli_bipartite_H_INCLUDED
#define SbmBernoulli_bipartite_H_INCLUDED




#include "StatisticalModel.h"
#include "Options.h"
#include "settings.h"
#include "factory.h"
#include "LinkCount.h"
#include "Network.h"
#include "Clustering_final.h"
#include "ClusteringDocument.h"

#include "tableApproximations.h"

#include <vector>
#include <boost/assign.hpp>
#include <boost/tuple/tuple.hpp>
#include <omp.h>

using namespace std::placeholders;

class SbmBernoulli_bipartite : public StatisticalModel
{
    friend class FunctionelTests; //allow functionel test access to private fields


    const static std::string MODELNAME;
    const std::string PARAMETER_CLUSTERING1 = "clustering1";
    const std::string PARAMETER_CLUSTERING2 = "clustering2";
    const std::string PARAMETER_ALPHA1 = "alpha1";
    const std::string PARAMETER_ALPHA2 = "alpha2";
    const std::string PARAMETER_BP = "bp";
    const std::string PARAMETER_BM = "bm";

    const std::string OPT_NETWORK_LINKS = "network.links";
    const std::string OPT_NETWORK_MISSINGLINKS = "network.missinglinks";
    const std::string OPT_CLUSTERING1_CRP = "clustering1.init_crp";
    const std::string OPT_CLUSTERING1_RANDOM = "clustering1.init_random";
    const std::string OPT_CLUSTERING2_CRP = "clustering2.init_crp";
    const std::string OPT_CLUSTERING2_RANDOM = "clustering2.init_random";

    const std::string OPT_TABLEMAX_A = "tablemax_a";
    const std::string OPT_TABLEMAX_B = "tablemax_b";
    const std::string OPT_TABLEMAX_C = "tablemax_c";
    const std::string OPT_ITEMS1 = "items1";
    const std::string OPT_ITEMS2 = "items2";
    const std::string OPT_COMPONENTS1 = "components1";
    const std::string OPT_COMPONENTS2 = "components2";

    const std::string OPT_SUBJECTS = "subjects";

    const std::string OPT_INIT_ALPHA1 = "alpha1.init";
    const std::string OPT_INIT_ALPHA2 = "alpha2.init";
    const std::string OPT_INIT_BP = "bp.init";
    const std::string OPT_INIT_BM = "bm.init";
    const std::string OPT_USEMISSING = "withmissing";

    const std::string OPT_USEINDEPENDENTHYPERPARAMETERS = "useindependenthyperparameters";
    const std::string OPT_USECLASSAONLY = "useclass1only";

    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;


template <typename T> class NodeCounts
{
public:
    std::vector<T> nodeLinks;
    std::vector<T> nodeNonLinks;
    std::vector<T> nodeMissingLinks;
    std::vector<T> nodeLinks_transposed;
    std::vector<T> nodeNonLinks_transposed;
    std::vector<T> nodeMissingLinks_transposed;

    void print()
    {
        std::cout << "cluster:\t links \t non \t miss \t links' \t non'" << std::endl;
        for(int i = 0; i < nodeLinks.size(); i++)
        {
            std::cout << "(i = " << i << " ) \t "<< nodeLinks[i] << " \t " << nodeNonLinks[i] << "\t / \t";// << nodeLinks_transposed[i] << "\t"<<nodeNonLinks_transposed[i]; // << " \t " << nodeMissingLinks[i];
           // std::cout << "\t\t" << nodeLinks_transposed[i] << " \t " << nodeNonLinks_transposed[i] << " \t " << nodeMissingLinks_transposed[i] << std::endl;
           std::cout << std::endl;
        }
        std::cout << std::endl;
    }
};



class SufficientStatistics
{
public:
    Matrix<size_t> links;
    Matrix<size_t> nonlinks;
    Matrix<size_t> missinglinks;

    bool usemissing = false;

//    SufficientStatistics(): links(2,2),nonlinks(2,2),missinglinks(2,2){}

    SufficientStatistics(size_t init_rows, size_t init_columns,bool usemissing_) : links(init_rows,init_columns),nonlinks(init_rows,init_columns),missinglinks(init_rows,init_columns)
    {
        usemissing = usemissing_;
    }
    SufficientStatistics(SufficientStatistics& shadow, bool transpose) :
        links(shadow.links),nonlinks(shadow.nonlinks),missinglinks(shadow.missinglinks)
    {
        links.matrix->pointees++;
        nonlinks.matrix->pointees++;
        missinglinks.matrix->pointees++;

        usemissing = shadow.usemissing;
        if(transpose)
        {
            links.transpose();
            nonlinks.transpose();
            missinglinks.transpose();
        }
    }

    size_t getLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        return links.get(sourceCluster,targetCluster);
        //return links.matrix[sourceCluster*links.columns+targetCluster];
    }

    size_t getNonLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        return nonlinks.get(sourceCluster,targetCluster);
        //return nonlinks.matrix[sourceCluster*nonlinks.columns+targetCluster];
    }
    size_t getMissingLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        if(usemissing)
        {
            return missinglinks.get(sourceCluster,targetCluster);
        }
        else
            return 0;
    }

};



struct HyperParameters_bernoulli
{
    double alphaA_;
    double logalphaA_;
    double alphaB_;
    double logalphaB_;

    double bp_;
    double bm_;

    std::vector<double> bp_values;
    std::vector<double> bm_values;

    Clustering_finite* clustA;
    Clustering_finite* clustB;
    double getAlpha(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == clustA)
            return alphaA_;
        else
            return alphaB_;
    }
    double getLogAlpha(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == clustA)
            return logalphaA_;
        else
            return logalphaB_;
    }
    void setAlphaValues(Clustering_finite* clustering_pointer, double newAlpha)
    {
        if(clustering_pointer == clustA)
        {
            alphaA_ = newAlpha;
            logalphaA_ = log(newAlpha);
        }
        else
        {
            alphaB_ = newAlpha;
            logalphaB_ = log(newAlpha);
        }
    }

    double getBp(size_t clusterId_classB)
    {
        return bp_values[clusterId_classB];
    }
    double getBm(size_t clusterId_classB)
    {
        return bm_values[clusterId_classB];
    }

};


struct Data
{
    //BipartiteNetwork<size_t>& network;
    NetworkData<size_t>& data;
    NetworkData<size_t>& missing;
    SufficientStatistics& sufstats;
    Clustering_finite& clustering;
    Clustering_finite& targetClustering;
    size_t K_clustering;
    size_t K_targetClustering;
};

public:

    //clustering data
    Clustering_finite clusteringDataA;
    Clustering_finite clusteringDataB;

    //parameters
    ClusteringFinite_Parameter clusteringA;
    ClusteringFinite_Parameter clusteringB;
    Real alphaA;
    Real alphaB;
    Real bp;
    Real bm;
    std::vector<Real> bp_vector;
    std::vector<Real> bm_vector;

    size_t K_classA;   //finite number of components in class A
    size_t K_classB;   //finite number of components in class B
    size_t itemsA;
    size_t itemsB;
    size_t numSubjects; //number of subjects

    bool usemissing_;
    bool directed;
    bool network_weighted;

    bool bernMixtureOnly;
    bool independentBpBm;

    std::string missinglinksfile_;
    std::string linksfile_;


    //hyperparameters data
    HyperParameters_bernoulli param;
    //sufficient statistics
    std::vector<SufficientStatistics> sufstatsA;
    std::vector<SufficientStatistics> sufstatsB;


    //network data
    std::vector<BipartiteNetwork<size_t>> networks;

    std::vector<Data> dataA;
    std::vector<Data> dataB;


    Betaln betaln_table;


  SbmBernoulli_bipartite() : StatisticalModel(),
        clusteringA(this,PARAMETER_CLUSTERING1), clusteringB(this,PARAMETER_CLUSTERING2),
        alphaA(this,PARAMETER_ALPHA1),alphaB(this,PARAMETER_ALPHA2), bp(this,PARAMETER_BP), bm(this,PARAMETER_BM),
        betaln_table(1,1,1)
    {
    }

    SbmBernoulli_bipartite(Options o) : StatisticalModel(MODELNAME, o),
        clusteringA(this,PARAMETER_CLUSTERING1), clusteringB(this,PARAMETER_CLUSTERING2),
        alphaA(this,PARAMETER_ALPHA1),alphaB(this,PARAMETER_ALPHA2), bp(this,PARAMETER_BP), bm(this,PARAMETER_BM),
        betaln_table(getOption<int>(o,OPT_TABLEMAX_A,10000),getOption<int>(o,OPT_TABLEMAX_B,60000),getOption<int>(o,OPT_TABLEMAX_C,70000))
    {
        //bind parameter functions
        clusteringA.moveItem = std::bind(&SbmBernoulli_bipartite::moveItem_clustering, this,  &dataA, _1, _2);
        clusteringB.moveItem = std::bind(&SbmBernoulli_bipartite::moveItem_clustering, this,  &dataB, _1, _2);
        clusteringA.effectiveLogPosteriorRatio = std::bind(&SbmBernoulli_bipartite::effectiveLogPosteriorRatio_clustering,this, &dataA, _1,_2,_3,_4);
        clusteringA.effectiveLogPosteriorRatio_restricted = std::bind(&SbmBernoulli_bipartite::effectiveLogPosteriorRatio_restricted_clustering, this, &dataA , _1, _2);
        clusteringB.effectiveLogPosteriorRatio = std::bind(&SbmBernoulli_bipartite::effectiveLogPosteriorRatio_clustering,this,&dataB,_1,_2,_3,_4);
        clusteringB.effectiveLogPosteriorRatio_restricted = std::bind(&SbmBernoulli_bipartite::effectiveLogPosteriorRatio_restricted_clustering, this,&dataB, _1, _2);
        clusteringA.getDataPointer = std::bind(&SbmBernoulli_bipartite::getDataPointer_clustering,this, &clusteringDataA);
        clusteringA.getNumberOfItems = std::bind(&SbmBernoulli_bipartite::getNumberOfItems_clustering,this, &clusteringDataA);
        clusteringA.get = std::bind(&SbmBernoulli_bipartite::get_clustering,this, &clusteringDataA);
        clusteringA.set = std::bind(&SbmBernoulli_bipartite::set_clustering,this, &clusteringDataA, _1);
        clusteringA.setFromString_implement = std::bind(&SbmBernoulli_bipartite::setFromString_clustering,this, &clusteringDataA, _1);
        clusteringB.getDataPointer = std::bind(&SbmBernoulli_bipartite::getDataPointer_clustering,this, &clusteringDataB);
        clusteringB.getNumberOfItems = std::bind(&SbmBernoulli_bipartite::getNumberOfItems_clustering,this, &clusteringDataB);
        clusteringB.get = std::bind(&SbmBernoulli_bipartite::get_clustering,this, &clusteringDataB);
        clusteringB.set = std::bind(&SbmBernoulli_bipartite::set_clustering,this, &clusteringDataB, _1);
        clusteringB.setFromString_implement = std::bind(&SbmBernoulli_bipartite::setFromString_clustering,this, &clusteringDataB, _1);


        alphaA.get = std::bind(&SbmBernoulli_bipartite::get_alpha,this,&clusteringDataA);
        alphaA.set = std::bind(&SbmBernoulli_bipartite::set_alpha,this,&clusteringDataA,_1);
        alphaA.logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_alpha, this,&clusteringDataA, _1);

        alphaB.get = std::bind(&SbmBernoulli_bipartite::get_alpha,this,&clusteringDataB);
        alphaB.set = std::bind(&SbmBernoulli_bipartite::set_alpha,this,&clusteringDataB,_1);
        alphaB.logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_alpha, this,&clusteringDataB, _1);

        bp.get = std::bind(&SbmBernoulli_bipartite::get_bp,this);
        bp.set = std::bind(&SbmBernoulli_bipartite::set_bp,this,_1);
        bp.logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_bp, this, _1);
        bm.get = std::bind(&SbmBernoulli_bipartite::get_bm,this);
        bm.set = std::bind(&SbmBernoulli_bipartite::set_bm,this,_1);
        bm.logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_bm, this, _1);

        //parse options
        independentBpBm = (getOption<bool>(o,OPT_USEINDEPENDENTHYPERPARAMETERS,false));
        bernMixtureOnly = (getOption<bool>(o,OPT_USECLASSAONLY,false));

        itemsA = parseSetting<int>(OPT_ITEMS1,settingDescriptions,o);
        itemsB = parseSetting<int>(OPT_ITEMS2,settingDescriptions,o);
        K_classA = parseSetting<int>(OPT_COMPONENTS1,settingDescriptions,o);
        K_classB = parseSetting<int>(OPT_COMPONENTS2,settingDescriptions,o);
        numSubjects = parseSetting<int>(OPT_SUBJECTS,settingDescriptions,o);

        param.alphaA_ = parseSetting<double>(OPT_INIT_ALPHA1,settingDescriptions,o);
        param.logalphaA_ = log(param.alphaA_);
        param.alphaB_ = parseSetting<double>(OPT_INIT_ALPHA2,settingDescriptions,o);
        param.logalphaB_ = log(param.alphaB_);
        param.bp_ = parseSetting<double>(OPT_INIT_BP,settingDescriptions,o);
        param.bm_ = parseSetting<double>(OPT_INIT_BM,settingDescriptions,o);

        usemissing_ = parseSetting<bool>(OPT_USEMISSING,settingDescriptions,o);
        linksfile_ = parseSetting<std::string>(OPT_NETWORK_LINKS,settingDescriptions,o);



        //load network
        if(numSubjects>1){   network_weighted = true;   } else { network_weighted = false; }
        bool zeroindexed = false;
        bool missingweighted = network_weighted;
        bool missingToZero = false;
        if(usemissing_)
        {
            missinglinksfile_ = parseSetting<std::string>(OPT_NETWORK_MISSINGLINKS,settingDescriptions,o);

            BipartiteNetwork<size_t> network(itemsA, itemsB, linksfile_, missinglinksfile_, zeroindexed, missingweighted, missingToZero, network_weighted);
            networks.push_back(network);
        }
        else
        {
            BipartiteNetwork<size_t> network(itemsA, itemsB, linksfile_, zeroindexed, network_weighted);
            networks.push_back(network);
        }


          //initialize clustering
        ClusteringDocument cd1;
        int clust_random1 = parseSetting<int>(OPT_CLUSTERING1_RANDOM,settingDescriptions,o);
        cd1.init_uniform(itemsA,clust_random1);
        ClusteringDocument cd2;
        int clust_random2 = parseSetting<int>(OPT_CLUSTERING2_RANDOM,settingDescriptions,o);
        cd2.init_uniform(itemsB,clust_random2);

        clusteringDataA = Clustering_finite(itemsA,K_classA,cd1.clusteringVector);
        clusteringDataB = Clustering_finite(itemsB,K_classB,cd2.clusteringVector);


        param.clustA = &clusteringDataA;
        param.clustB = &clusteringDataB;

        for(size_t i = 0; i<networks.size(); i++)
        {
            sufstatsA.emplace_back(10,10,usemissing_);
            sufstatsB.emplace_back(sufstatsA[i],true);
            dataA.push_back({networks[i].data_classA,networks[i].missing_classA,sufstatsA[i],clusteringDataA,clusteringDataB,K_classA,K_classB});
            dataB.push_back({networks[i].data_classB,networks[i].missing_classB,sufstatsB[i],clusteringDataB,clusteringDataA,K_classB,K_classA});
        }

        if(independentBpBm)
        {
            size_t numClusters_classB = K_classB;
            for(size_t clusterId_classB = 0; clusterId_classB< numClusters_classB; clusterId_classB++)
            {
                param.bp_values.push_back(param.bp_);
                std::string bp_name = "a";
                Real bp_(this,bp_name);
                bp_vector.push_back(bp_);
                bp_vector[clusterId_classB].get = std::bind(&SbmBernoulli_bipartite::get_bp_vector,this,clusterId_classB);
                bp_vector[clusterId_classB].set = std::bind(&SbmBernoulli_bipartite::set_bp_vector,this,clusterId_classB,_1);
                bp_vector[clusterId_classB].logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_bp_vector,this,clusterId_classB,_1);

                param.bm_values.push_back(param.bm_);
                std::string bm_name = "b";
                Real bm_(this,bm_name);
                bm_vector.push_back(bm_);
                bm_vector[clusterId_classB].get = std::bind(&SbmBernoulli_bipartite::get_bm_vector,this,clusterId_classB);
                bm_vector[clusterId_classB].set = std::bind(&SbmBernoulli_bipartite::set_bm_vector,this,clusterId_classB,_1);
                bm_vector[clusterId_classB].logPosteriorRatio = std::bind(&SbmBernoulli_bipartite::logPosteriorRatio_bm_vector,this,clusterId_classB,_1);
            }
        }

        computeAllSufficientStatistics();

        reportInfo("model setup completed",.5);
    }


    double computeLogPrior();
    double computeLogLikelihood();
    double computeLogPosterior();
    double computeLogLikelihood(Data& data_, Clustering_finite& clustering_);

    //assist functions
    void computeAllSufficientStatistics();
    void computeSufficientStatistics(Data& dataA_,Data& dataB_,Clustering_finite& clusteringA_, Clustering_finite& clusteringB_);


    void getNodeCounts(size_t nodeId, Data& data_, Clustering_finite& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts);

    inline double logPrior_effectiveChange(Clustering_finite& clustering, size_t cluster, size_t currentCluster, size_t currentClusterSize);
    inline double logPrior_effectiveChange_newCluster(Clustering_finite& clustering);


    inline double logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering_finite& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts);
    inline double logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);

    //clustering functions
    partial_vector<double> effectiveLogPosteriorRatio_clustering(std::vector<Data>* data_pointer, size_t nodeId, Clustering_finite::iterator begin, Clustering_finite::iterator end, bool appendForNewCluster);
    partial_vector<double> effectiveLogPosteriorRatio_restricted_clustering(std::vector<Data>* data_pointer, size_t nodeId,std::vector<size_t>& restrictedClusters);
    //double effectiveLogPosteriorRatio_mergeClusters_clustering(std::vector<Data>* data_pointer, size_t cluster1, size_t cluster2);

    void moveItem_clustering(std::vector<Data>* data_pointer, size_t itemId, size_t clusterId);
    //void moveItem_newCluster_clustering(std::vector<Data>* data_pointer, size_t itemId);
    //void mergeClusters_clustering(std::vector<Data>* data_pointer, size_t cluster1,size_t cluster2);

    size_t getMaxNumberOfClusters(Clustering_finite* clustering_pointer);

    Clustering_finite* getDataPointer_clustering(Clustering_finite* clustering_pointer);
    size_t getNumberOfItems_clustering(Clustering_finite* clustering_pointer);


    ClusteringDocument get_clustering(Clustering_finite* clustering_pointer);
    void set_clustering(Clustering_finite* clustering_pointer, ClusteringDocument& cd);
    void setFromString_clustering(Clustering_finite* clustering_pointer, std::string str);


    //alpha functions
    double get_alpha(Clustering_finite* clustering_pointer);
    void set_alpha(Clustering_finite* clustering_pointer,double val);
    double logPosteriorRatio_alpha(Clustering_finite* clustering_pointer,double new_alpha);

    //bp functions
    double get_bp();
    void set_bp(double val);
    double logPosteriorRatio_bp(double new_bp);
    double get_bp_vector(size_t clusterId_classB);
    void set_bp_vector(size_t clusterId_classB, double val);
    double logPosteriorRatio_bp_vector(size_t clusterId_classB, double new_bp);

    //bm functions
    double get_bm();
    void set_bm(double val);
    double logPosteriorRatio_bm(double new_bm);
    double get_bm_vector(size_t clusterId_classB);
    void set_bm_vector(size_t clusterId_classB, double val);
    double logPosteriorRatio_bm_vector(size_t clusterId_classB, double new_bm);




    size_t getK(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == param.clustA)
            return K_classA;
        else
            return K_classB;
    }

    double effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster);

    static Creator<StatisticalModel, SbmBernoulli_bipartite> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};

class MixtureBernoulli_collapsed_finite : public SbmBernoulli_bipartite
{
public:
    const static std::string MODELNAME;
    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;


    MixtureBernoulli_collapsed_finite() : SbmBernoulli_bipartite()
    {
    }

    MixtureBernoulli_collapsed_finite(Options o) : SbmBernoulli_bipartite(o)
    {
        bernMixtureOnly = true;
        ClusteringDocument cd2;
        cd2.init_uniform(itemsB,itemsB);
        computeAllSufficientStatistics();
    }

    static Creator<StatisticalModel, MixtureBernoulli_collapsed_finite> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

};


#endif // SbmBernoulli_bipartite_H_INCLUDED
