/**
This code is provided as is without any warranty!

Implementation of the statistical model base class
*/

#include "StatisticalModel.h"


std::string StatisticalModel::getName() const
{
    return name_;
}

/**
    obtain pointer to a given model parameter, if it exists (has previously been
    added to the model by the addParameter function)
*/
Parameter* StatisticalModel::getParameter(std::string parameterName)
{
    for(Parameter* p:parameters)
    {
        if(p->getName().compare(parameterName)==0)
        {
            return p;
        }
    }
    //reportError("unknown parameter: "+parameterName+" requested in StatisticalModel::getParameter",1);
    return nullptr;
}

void StatisticalModel::addParameter(Parameter* parameter)
{
        parameters.push_back(parameter);
}
