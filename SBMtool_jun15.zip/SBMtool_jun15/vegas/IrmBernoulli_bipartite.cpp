
#include "IrmBernoulli_bipartite.h"

const std::string IrmBernoulli_bipartite::MODELNAME = "IrmBernoulli_bipartite";

const ModelDescription IrmBernoulli_bipartite::modelDescription("IrmBern","finite, bipartite","irm model with bernoulli likelihood and beta prior");

const std::vector<SettingDescription> IrmBernoulli_bipartite::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items1","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class1 of the network").longDescription("The number of nodes in class1 of the network")   },
    {   SettingDescription("items2","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class2 of the network").longDescription("The number of nodes in class2 of the network")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("components","INT",true).min(1).max(10000).shortDescription("Number of components in the clustering").longDescription("The maximal allowed number of components in the clustering")   },
    {   SettingDescription("bp.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bp")   },
    {   SettingDescription("bm.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bm")   },
    {   SettingDescription("alpha1.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 1") },
    {   SettingDescription("alpha2.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 2") },
    {   SettingDescription("clustering1.init_crp","FLOAT",false).initialFloat(1).min(0).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1, according to CRP").longDescription("Concentration parameter of the generating CRP")  },
    {   SettingDescription("clustering1.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1").longDescription("Initial number of components, the nodes are randomny split into")    },
    {   SettingDescription("clustering2.init_crp","FLOAT",false).initialFloat(1).min(0).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 2, according to CRP").longDescription("Concentration parameter of the generating CRP")  },
    {   SettingDescription("clustering2.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 2").longDescription("Initial number of components, the nodes are randomny split into")    }

};

const std::vector<ParameterDescription> IrmBernoulli_bipartite::parameterDescriptions
{
    {   ParameterDescription("clustering1","INFINITE_CLUSTERING").shortDescription("clustering1 parameter").longDescription("")    },
    {   ParameterDescription("clustering2","INFINITE_CLUSTERING").shortDescription("clustering2 parameter").longDescription("")    },
    {   ParameterDescription("alpha1","REAL").shortDescription("concentration parameter for clustering of group 1").longDescription("")    },
    {   ParameterDescription("alpha2","REAL").shortDescription("concentration parameter for clustering of group 2").longDescription("")    },
    {   ParameterDescription("bp","REAL").shortDescription("link-count hyperparameter").longDescription("")    },
    {   ParameterDescription("bm","REAL").shortDescription("nonlink-count hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, IrmBernoulli_bipartite> IrmBernoulli_bipartite::Create(IrmBernoulli_bipartite::MODELNAME);


void IrmBernoulli_bipartite::getNodeCounts(size_t nodeId, Data& data_, Clustering& targetClustering, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts)
{

    nodecounts.nodeLinks.clear();
    nodecounts.nodeLinks.resize(max);

    nodecounts.nodeNonLinks.clear();
    nodecounts.nodeNonLinks.resize(max);

    nodecounts.nodeMissingLinks.clear();
    nodecounts.nodeMissingLinks.resize(max);

    for(size_t c = 0 ; c< max; c++)
    {
            if(targetClustering.exist(c))
                nodecounts.nodeNonLinks[c] = numSubjects*targetClustering.getSize(c);
    }
    for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
    {

        size_t itemId = iter.getTarget();
        size_t clusterId = targetClustering.getClusterId(itemId);
        nodecounts.nodeLinks[clusterId]+=iter.getValue();
        nodecounts.nodeNonLinks[clusterId]-=iter.getValue();

    }
    if(usemissing_)
    {
        for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t clusterId = targetClustering.getClusterId(itemId);
            nodecounts.nodeMissingLinks[clusterId]+=iter.getValue();
        }
    }

}




double IrmBernoulli_bipartite::computeLogLikelihood()
{
    double likelihood = 0;
    for(size_t netID = 0 ;netID < networks.size(); netID++)
    {
        likelihood += computeLogLikelihood(dataA[netID],clusteringDataB);
    }
    return likelihood;
}

double IrmBernoulli_bipartite::computeLogLikelihood(Data& data_, Clustering& targetClustering)
{
    double bp_ = param.bp_;
    double bm_ = param.bm_;

    double value = 0;

    Clustering::iterator iterS = data_.clustering.begin();
    Clustering::iterator iterS_end = data_.clustering.end();

    for( ; iterS!=iterS_end ; ++iterS )
    {
        size_t sourceCluster = iterS.index();
        Clustering::iterator iterT = targetClustering.begin();
        Clustering::iterator iterT_end = targetClustering.end();
        for( ; iterT!=iterT_end ; ++iterT )
        {
            const size_t targetCluster = iterT.index();

            if(independentBpBm)
            {
                bp_ = param.getBp(targetCluster);
                bm_ = param.getBm(targetCluster);
            }

            const size_t links = data_.sufstats.getLinkCount(sourceCluster,targetCluster);
            const size_t nonlinks = data_.sufstats.getNonLinkCount(sourceCluster,targetCluster);
            const size_t missinglinks = data_.sufstats.getMissingLinkCount(sourceCluster,targetCluster);

            //std::cout << " l = " << links << "  n = " << nonlinks << std::endl;

            value += betaln_table.betaln(links, bp_, nonlinks - missinglinks, bm_);
            value -= betaln_table.betaln(0, bp_, 0, bm_);

            //std::cout << " vlaue" << value << std::endl;
        }

    }
    return value;
}

double IrmBernoulli_bipartite::computeLogPrior()
{
    double computedPrior = 0;
    //Clustering A
    {
        Clustering& clustering_ = clusteringDataA;
        double& alpha_ = param.alphaA_;
        double& logalpha_ = param.logalphaA_;

        const size_t noc = clustering_.getNumberOfClusters();
        const size_t J = clustering_.getNumberOfItems();

        double logprior = noc * logalpha_;
        logprior += lgamma(alpha_);
        logprior -= lgamma(J+alpha_);

        for(Clustering::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
        {
            logprior += lgamma(clustering_.getSize(iter.index()));
        }
        //logprior -= logalpha_;
        computedPrior += logprior * networks.size();
    }
    //Clustering B
    if(!bernMixtureOnly)
    {
        {
            Clustering& clustering_ = clusteringDataB;
            double& alpha_ = param.alphaB_;
            double& logalpha_ = param.logalphaB_;

            const size_t noc = clustering_.getNumberOfClusters();
            const size_t J = clustering_.getNumberOfItems();

            double logprior = noc * logalpha_;
            logprior += lgamma(alpha_);
            logprior -= lgamma(J+alpha_);

            for(Clustering::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
            {
                logprior += lgamma(clustering_.getSize(iter.index()));
            }
            //logprior -= logalpha_;
            computedPrior += logprior * networks.size();
        }
    }
    return computedPrior;
}

double IrmBernoulli_bipartite::computeLogPosterior()
{
    return computeLogPrior()+computeLogLikelihood();
}





partial_vector<double> IrmBernoulli_bipartite::effectiveLogPosteriorRatio_restricted_clustering(std::vector<Data>* data_pointer,size_t nodeId,std::vector<size_t>& restrictedClusters)
{


    std::vector<Data>& dataVector = *data_pointer;

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];

        Clustering& clustering_ = data.clustering;
        Clustering& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.links.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);

        for(std::vector<size_t>::iterator itouter = restrictedClusters.begin() ; itouter!=restrictedClusters.end() ; ++itouter)
        {
            size_t cluster = *itouter;

            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(clustering_,cluster,currentCluster,currentClusterSize);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }

        }
    }
    return logps;

}


double IrmBernoulli_bipartite::effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster,bool emptyCluster)
{
    std::vector<Data>& dataVector = *data_pointer;
    NodeCounts<size_t> nodecounts;
    double loglike = 0;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];
        Clustering& clustering_ = data.clustering;
        Clustering& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.links.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);

        if(!emptyCluster)
        {
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            loglike += dlikelihood;
        }
        else
        {
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data,param,currentCluster,currentClusterSize,nodecounts);
            loglike+=loglikelihood;
        }
    }
    return loglike;
}




partial_vector<double> IrmBernoulli_bipartite::effectiveLogPosteriorRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster)
{
    std::vector<Data>& dataVector = *data_pointer;

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];

        Clustering& clustering_ = data.clustering;
        Clustering& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.links.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);

        //existing clusters
        Clustering::iterator outerIter;
        for(outerIter = begin ; outerIter!=end; ++outerIter)
        {
            size_t cluster = outerIter.index();

            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(clustering_,cluster,currentCluster,currentClusterSize);

            //std::cout << " for cluster : " << cluster << " dl is " << dlikelihood << "  dp is " << dprior << std::endl;

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }

                //std::cout << " c:" << cluster << " dl " << dlikelihood << std::endl;//KOKO
            }

        }
        //new cluster
        if(appendForNewCluster)
        {
            double logprior = logPrior_effectiveChange_newCluster(clustering_);
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data,param,currentCluster,currentClusterSize,nodecounts);
            if(logps.exist(max))
            {
               logps[max] += logprior+loglikelihood;
            }
            else
            {
                logps.set(max,logprior+loglikelihood);
            }

               // std::cout << " new:" << " dl " << loglikelihood << std::endl;//koko
        }


    }
    return logps;

}



double IrmBernoulli_bipartite::effectiveLogPosteriorRatio_mergeClusters_clustering(std::vector<Data>* data_pointer, size_t cluster1, size_t cluster2)
{
    Clustering& clustering_ = (*data_pointer)[0].clustering;
    Clustering& targetClustering_ = (*data_pointer)[0].targetClustering;
    double logalpha_ = param.getLogAlpha(&clustering_);
    double bp_ = param.bp_;
    double bm_ = param.bm_;

    if(cluster1 == cluster2)
    {
        return 0;
    }
    else
    {
        //compute change in prior
        double dlogPrior = 0;
        dlogPrior -= clustering_.getNumberOfClusters()  * logalpha_;
        dlogPrior += (clustering_.getNumberOfClusters()-1 ) * logalpha_;
        dlogPrior -= lgamma(clustering_.getSize(cluster1));
        dlogPrior -= lgamma(clustering_.getSize(cluster2));
        dlogPrior += lgamma(clustering_.getSize(cluster1) + clustering_.getSize(cluster2) );

        dlogPrior = dlogPrior*networks.size();

        //add change in likelihood
        double dlogLikelihood = 0;

        for(size_t netID = 0; netID<networks.size(); netID++)
        {
            SufficientStatistics& sf = (*data_pointer)[netID].sufstats;
            for(Clustering::iterator citer = targetClustering_.begin(); citer!=targetClustering_.end(); ++citer)
            {
                const size_t clusterId = citer.index();

                if(independentBpBm)
                {
                    bp_ = param.getBp(clusterId);
                    bm_ = param.getBm(clusterId);
                }

                const size_t Npci = sf.getLinkCount(cluster1,clusterId);
                const size_t Nmci = sf.getNonLinkCount(cluster1,clusterId) - sf.getMissingLinkCount(cluster1,clusterId);
                const size_t Npcj = sf.getLinkCount(cluster2,clusterId);
                const size_t Nmcj = sf.getNonLinkCount(cluster2,clusterId) - sf.getMissingLinkCount(cluster2,clusterId);

                dlogLikelihood -= ( betaln_table.betaln(Npci,bp_ , Nmci,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npcj,bp_ , Nmcj,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood += ( betaln_table.betaln(Npci+Npcj,bp_ , Nmci+Nmcj, bm_) - betaln_table.betaln(0,bp_,0,bm_));
            }
        }

        return dlogPrior+dlogLikelihood;
    }

}


void IrmBernoulli_bipartite::computeAllSufficientStatistics()
{
    for(size_t i = 0; i < dataA.size(); i++)
    {
        computeSufficientStatistics(dataA[i],dataB[i],clusteringDataA,clusteringDataB);
    }
}





void IrmBernoulli_bipartite::computeSufficientStatistics(Data& dataA_,Data& dataB_,Clustering& clusteringA_, Clustering& clusteringB_)
{
    Matrix<size_t>& links = dataA_.sufstats.links;
    Matrix<size_t>& nonlinks = dataA_.sufstats.nonlinks;
    Matrix<size_t>& missinglinks = dataA_.sufstats.missinglinks;

    NetworkData<size_t>& data = dataA_.data;
    NetworkData<size_t>& missing = dataA_.missing;


    //resize
    links.clear();
    nonlinks.clear();
    missinglinks.clear();

    size_t newMaxRows = std::max(clusteringA_.getNumberOfClusters()*2,(size_t)20);
    size_t newMaxColumns = std::max(clusteringB_.getNumberOfClusters()*2,(size_t)20);

    links.setNewMaxSize(newMaxRows,newMaxColumns);
    nonlinks.setNewMaxSize(newMaxRows,newMaxColumns);
    missinglinks.setNewMaxSize(newMaxRows,newMaxColumns);

    //compute all links
    for(size_t sourceNode = 0; sourceNode < data.getNumberOfRows(); sourceNode++)
    {

        if(!clusteringA_.assigned(sourceNode))
        {
            continue;
        }

        size_t sourceCluster = clusteringA_.getClusterId(sourceNode);

        if(sourceCluster>=links.getRows())
        {
            size_t newMaxRows = std::max(sourceCluster+1,links.getRows()*2);
            size_t newMaxColumns = links.getColumns();
            links.setNewMaxSize(newMaxRows,newMaxColumns);
            nonlinks.setNewMaxSize(newMaxRows,newMaxColumns);
            missinglinks.setNewMaxSize(newMaxRows,newMaxColumns);
        }
        for(typename NetworkData<size_t>::iterator iter = data.begin(sourceNode); iter!=data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();


            if(!clusteringB_.assigned(targetNode))
            {
                continue;
            }

            bool weight = iter.getValue();
            size_t targetCluster = clusteringB_.getClusterId(targetNode);

            if(targetCluster>=links.getColumns())
            {
                size_t newMaxColumns = std::max(targetCluster+1,links.getColumns()*2);
                size_t newMaxRows = links.getRows();
                links.setNewMaxSize(newMaxRows,newMaxColumns);
                nonlinks.setNewMaxSize(newMaxRows,newMaxColumns);
                missinglinks.setNewMaxSize(newMaxRows,newMaxColumns);
            }
            links.add(weight,sourceCluster,targetCluster);
            //links.matrix[sourceCluster*links.max+targetCluster] += weight;
        }
    }


    //compute all nonlink counts
    for( Clustering::iterator a_iter = clusteringA_.begin(); a_iter!=clusteringA_.end(); ++a_iter )
    {
        size_t clusterIdFrom = a_iter.index();

        for( Clustering::iterator b_iter = clusteringB_.begin() ; b_iter!=clusteringB_.end() ; b_iter++ )
        {
            size_t clusterIdTo = b_iter.index();
            size_t nodesInClusterFrom = clusteringA_.getSize(clusterIdFrom);
            size_t nodesInClusterTo = clusteringB_.getSize(clusterIdTo);
            size_t nonlinks__ = numSubjects*nodesInClusterFrom*nodesInClusterTo - links.get(clusterIdFrom,clusterIdTo);
            nonlinks.set(nonlinks__,clusterIdFrom,clusterIdTo);
        }
    }

    //compute missing links
    if(usemissing_)
    {
        for(size_t sourceNode = 0; sourceNode < data.getNumberOfRows(); sourceNode++)
        {

            if(!clusteringA_.assigned(sourceNode))
            {
                continue;
            }

            size_t sourceCluster = clusteringA_.getClusterId(sourceNode);

            for(typename NetworkData<size_t>::iterator iter = missing.begin(sourceNode); iter!=missing.end(sourceNode) ; iter++)
            {
                size_t targetNode = iter.getTarget();

                if(!clusteringB_.assigned(targetNode))
                {
                    continue;
                }

                size_t targetCluster = clusteringB_.getClusterId(targetNode);
                missinglinks.add(iter.getValue(),sourceCluster,targetCluster);
            }
        }
    }


}






void IrmBernoulli_bipartite::moveItem_clustering(std::vector<Data>* data_pointer, size_t itemId, size_t clusterId)
{

    Clustering& clustering_ = (*data_pointer)[0].clustering;
    Clustering& targetClustering_ = (*data_pointer)[0].targetClustering;



    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data = (*data_pointer)[netID];
        size_t currentCluster = clustering_.getClusterId(itemId);

        Matrix<size_t>& links = data.sufstats.links;
        Matrix<size_t>& nonlinks = data.sufstats.nonlinks;
        Matrix<size_t>& missinglinks = data.sufstats.missinglinks;

        size_t max = links.getColumns();

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data,targetClustering_,currentCluster,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

        //remove node from sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.subtract(nodeLinks[c],currentCluster,c);
            nonlinks.subtract(nodeNonLinks[c],currentCluster,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.subtract(nodeMissingLinks[c],currentCluster,c);
            }
        }
        //move node
        currentCluster = clusterId;
        //insert node in sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.add(nodeLinks[c],currentCluster,c);
            nonlinks.add(nodeNonLinks[c],currentCluster,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.add(nodeMissingLinks[c],currentCluster,c);
            }
        }
    }
    //move the node in the datastructure
    clustering_.moveItem(itemId,clusterId);

}


void IrmBernoulli_bipartite::moveItem_newCluster_clustering(std::vector<Data>* data_pointer, size_t itemId)
{
    Clustering& clustering_ = (*data_pointer)[0].clustering;
    Clustering& targetClustering_ = (*data_pointer)[0].targetClustering;

    //obtain new clusterId and move node
    size_t oldClusterId = clustering_.getClusterId(itemId);
    clustering_.removeItem(itemId);
    size_t newClusterId = clustering_.addItem(itemId);
    //resize sufficient statistics if necessary

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data = (*data_pointer)[netID];

        Matrix<size_t>& links = data.sufstats.links;
        Matrix<size_t>& nonlinks = data.sufstats.nonlinks;
        Matrix<size_t>& missinglinks = data.sufstats.missinglinks;

        if(newClusterId>=links.getRows())
        {
            size_t newMaxRows = std::max(newClusterId+1,links.getRows()*2);
            size_t newMaxColumns = links.getColumns();
            links.setNewMaxSize(newMaxRows,newMaxColumns);
            nonlinks.setNewMaxSize(newMaxRows,newMaxColumns);
            missinglinks.setNewMaxSize(newMaxRows,newMaxColumns);
        }

        size_t max = links.getColumns();

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data,targetClustering_,oldClusterId,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

        //remove node from sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.subtract(nodeLinks[c],oldClusterId,c);
            nonlinks.subtract(nodeNonLinks[c],oldClusterId,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.subtract(nodeMissingLinks[c],oldClusterId,c);
            }
        }
        //insert node in sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.add(nodeLinks[c],newClusterId,c);
            nonlinks.add(nodeNonLinks[c],newClusterId,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.add(nodeMissingLinks[c],newClusterId,c);
            }
        }
    }

}

void IrmBernoulli_bipartite::mergeClusters_clustering(std::vector<Data>* data_pointer, size_t clusterId1,size_t clusterId2)
{

    Clustering& clustering_ = (*data_pointer)[0].clustering;
    Clustering& targetClustering_ = (*data_pointer)[0].targetClustering;

    //move nodes
    Clustering::clusterIterator iter;
    for(iter = clustering_.begin(clusterId2) ; clustering_.exist(clusterId2) && iter!=clustering_.end(clusterId2) ; ++iter)
    {
        clustering_.moveItem(*iter,clusterId1);
    }

    for(size_t netID = 0 ; netID < networks.size(); netID++)
    {
        Data& data = (*data_pointer)[netID];

        Matrix<size_t>& links = data.sufstats.links;
        Matrix<size_t>& nonlinks = data.sufstats.nonlinks;
        Matrix<size_t>& missinglinks = data.sufstats.missinglinks;

        for(Clustering::iterator titer = targetClustering_.begin(); titer!=targetClustering_.end(); ++titer)
        {
            size_t tid = titer.index();
            links.add(links.get(clusterId2,tid),clusterId1,tid);
            nonlinks.add(nonlinks.get(clusterId2,tid),clusterId1,tid);
            links.set(0,clusterId2,tid);
            nonlinks.set(0,clusterId2,tid);
            if(usemissing_)
            {
                missinglinks.add(missinglinks.get(clusterId2,tid),clusterId1,tid);
                missinglinks.set(0,clusterId2,tid);
            }
        }
    }
};



Clustering* IrmBernoulli_bipartite::getDataPointer_clustering(Clustering* clustering_pointer)
{
    return clustering_pointer;
};

size_t IrmBernoulli_bipartite::getNumberOfItems_clustering(Clustering* clustering_pointer)
{
    return clustering_pointer->getNumberOfItems();
}

ClusteringDocument IrmBernoulli_bipartite::get_clustering(Clustering* clustering_pointer)
{

    ClusteringDocument cd((clustering_pointer)->getNumberOfClusters(), *clustering_pointer);
    return cd;
};

void IrmBernoulli_bipartite::set_clustering(Clustering* clustering_pointer, ClusteringDocument& cd)
{
    Clustering clustering(cd.clusteringVector);
    *clustering_pointer = clustering;
    computeAllSufficientStatistics();
};

void IrmBernoulli_bipartite::setFromString_clustering(Clustering* clustering_pointer, std::string str)
{
    ClusteringDocument cd(str);
    set_clustering(clustering_pointer,cd);
};





//alpha functions
double IrmBernoulli_bipartite::get_alpha(Clustering* clustering_pointer)
{
    return param.getAlpha(clustering_pointer);
}
void IrmBernoulli_bipartite::set_alpha(Clustering* clustering_pointer, double val)
{
    param.setAlphaValues(clustering_pointer,val);
}
double IrmBernoulli_bipartite::logPosteriorRatio_alpha(Clustering* clustering_pointer,double new_alpha)
{
    Clustering& clustering_ = *clustering_pointer;
    double alpha_ = param.getAlpha(clustering_pointer);
    double logalpha_ = param.getLogAlpha(clustering_pointer);

    if (new_alpha <= 0) return -9999999999999999;
    int noc = clustering_.getNumberOfClusters();
    int J = clustering_.getNumberOfItems();

    double  logp = noc * log(new_alpha) + lgamma(new_alpha) - lgamma(J+new_alpha) - log(new_alpha);
            logp -= noc * logalpha_ + lgamma(alpha_) - lgamma(J+alpha_) - logalpha_;
    return  logp;

}

//bp functions
double IrmBernoulli_bipartite::get_bp()
{
    double& bp_ = param.bp_;
    return bp_;
}

void IrmBernoulli_bipartite::set_bp(double val)
{
    double& bp_ = param.bp_;
    bp_ = val;
}

double IrmBernoulli_bipartite::logPosteriorRatio_bp(double new_bp)
{
    if (new_bp <= 0) return -9999999999999999;
    double old_bp = bp.get();
    double L0 = computeLogLikelihood();
    bp.set(new_bp);
    double L1 = computeLogLikelihood();
    bp.set(old_bp);
    return L1-L0;
}


double IrmBernoulli_bipartite::get_bp_vector(size_t clusterId_classB)
{
   return param.bp_values[clusterId_classB];
}
void IrmBernoulli_bipartite::set_bp_vector(size_t clusterId_classB, double val)
{
    param.bp_values[clusterId_classB] = val;
}
double IrmBernoulli_bipartite::logPosteriorRatio_bp_vector(size_t clusterId_classB, double new_bp)
{
    if (new_bp <= 0) return -9999999999999999;
    double old_bp = get_bp_vector(clusterId_classB);
    double L0 = computeLogLikelihood();
    set_bp_vector(clusterId_classB, new_bp);
    double L1 = computeLogLikelihood();
    set_bp_vector(clusterId_classB, old_bp);
    return L1-L0;
}


//bm functions
double IrmBernoulli_bipartite::get_bm()
{
    double& bm_ = param.bm_;
    return bm_;
}

void IrmBernoulli_bipartite::set_bm(double val)
{
    double& bm_ = param.bm_;
    bm_ = val;
}

double IrmBernoulli_bipartite::logPosteriorRatio_bm(double new_bm)
{
    if (new_bm <= 0) return -9999999999999999;
    double old_bm = bm.get();
    double L0 = computeLogLikelihood();
    bm.set(new_bm);
    double L1 = computeLogLikelihood();
    bm.set(old_bm);
    return L1-L0;
}


double IrmBernoulli_bipartite::get_bm_vector(size_t clusterId_classB)
{
   return param.bm_values[clusterId_classB];
}
void IrmBernoulli_bipartite::set_bm_vector(size_t clusterId_classB, double val)
{
    param.bm_values[clusterId_classB] = val;
}
double IrmBernoulli_bipartite::logPosteriorRatio_bm_vector(size_t clusterId_classB, double new_bm)
{
    if (new_bm <= 0) return -9999999999999999;
    double old_bm = get_bm_vector(clusterId_classB);
    double L0 = computeLogLikelihood();
    set_bm_vector(clusterId_classB, new_bm);
    double L1 = computeLogLikelihood();
    set_bm_vector(clusterId_classB, old_bm);
    return L1-L0;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmBernoulli_bipartite::logPrior_effectiveChange(Clustering& clustering, size_t cluster, size_t currentCluster, size_t currentClusterSize)
{
    Clustering& clustering_ = clustering;

    double dp = 0;
    if(cluster != currentCluster)
    {
        dp = log(clustering_.getSize(cluster));
    }
    else
    {
        if(currentClusterSize>1)
            dp = log(currentClusterSize-1);
    }
    return dp;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmBernoulli_bipartite::logPrior_effectiveChange_newCluster(Clustering& clustering)
{
    const double alpha_ = param.getAlpha(&clustering);
    return log(alpha_);
}



/**
*** compute the effective change for the log_likelihood when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmBernoulli_bipartite::logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{

    double bp_ = param.bp_;
    double bm_ = param.bm_;

    std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
    std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

    double loglik = 0;


    for(Clustering::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
    {
        size_t t = targetiter.index();

        if(independentBpBm)
        {
            bp_ = param.getBp(t);
            bm_ = param.getBm(t);
        }

        loglik += betaln_table.betaln( nodeLinks[t], bp_, nodeNonLinks[t] - nodeMissingLinks[t], bm_);
        loglik -= betaln_table.betaln( 0, bp_, 0, bm_);
    }
    return loglik;
}




/**
*** compute the change in log_loglikelihood when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmBernoulli_bipartite::logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts)
{
    double bm_ = param.bm_;
    double bp_ = param.bp_;

    Matrix<size_t>& links = data_.sufstats.links;
    Matrix<size_t>& nonlinks = data_.sufstats.nonlinks;
    Matrix<size_t>& missinglinks = data_.sufstats.missinglinks;

    std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
    std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

    const size_t c = cluster;

    if(c == currentCluster)
    {

        double d_loglikelihood = 0;
        for(Clustering::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
        {
            size_t l = targetiter.index();

            if(independentBpBm)
            {
                bp_ = param.getBp(l);
                bm_ = param.getBm(l);
            }

            //const size_t r_nl = nodeLinks[l];               //links from node to cluster l
            //const size_t rn_nl = nodeNonLinks[l];
            //const size_t rm_nl = nodeMissingLinks[l];

            const double linkcount = links.get(c,l) - nodeLinks[l];
            const double nonlinkcount = nonlinks.get(c,l) - nodeNonLinks[l] - ( missinglinks.get(c,l) - nodeMissingLinks[l] );

            d_loglikelihood += betaln_table.betaln( linkcount + nodeLinks[l], bp_, nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
            d_loglikelihood -= betaln_table.betaln( linkcount, bp_, nonlinkcount, bm_ );

            //without missing
            //d_loglikelihood += betaln_table.betaln( links.get(c,l), a, nonlinks.get(c,l), b );
            //d_loglikelihood -= betaln_table.betaln( links.get(c,l)-nodeLinks[l], a, nonlinks.get(c,l)-nodeNonLinks[l] - (missinglinks.get(c,l) - nodeMissingLinks[l]), b );

        }
        return d_loglikelihood;
    }
    else
    {
        double d_loglikelihood = 0;
        for(Clustering::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
        {
            size_t l = targetiter.index();

            if(independentBpBm)
            {
                bp_ = param.getBp(l);
                bm_ = param.getBm(l);
            }

            //const size_t r_nl = nodeLinks[l];               //links from node to cluster l
            //const size_t rn_nl = nodeNonLinks[l];
            //const size_t rm_nl = nodeMissingLinks[l];


            const double linkcount = links.get(c,l);
            const double nonlinkcount = nonlinks.get(c,l) - missinglinks.get(c,l);
            d_loglikelihood += betaln_table.betaln( linkcount + nodeLinks[l], bp_ , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
            d_loglikelihood -= betaln_table.betaln( linkcount , bp_ , nonlinkcount , bm_ );

            //without missing
            //d_loglikelihood += betaln_table.betaln( links.get(c,l)+nodeLinks[l], a, nonlinks.get(c,l)+nodeNonLinks[l], b );
            //d_loglikelihood -= betaln_table.betaln( links.get(c,l), a, nonlinks.get(c,l), b );
        }
        return d_loglikelihood;
    }
}






const std::string MixtureBernoulli_collapsed::MODELNAME = "mixtureBernoulli_infinite";

const ModelDescription MixtureBernoulli_collapsed::modelDescription("bernoulli mixture model","infinite","");

const std::vector<SettingDescription> MixtureBernoulli_collapsed::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items1","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class1 of the network").longDescription("The number of nodes in class1 of the network")   },
    {   SettingDescription("components1","INT",true).min(1).max(10000).shortDescription("Number of components in the clustering of group 1").longDescription("The maximal allowed number of components in the clustering of group 1")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("bp.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bp")   },
    {   SettingDescription("bm.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bm")   },
    {   SettingDescription("alpha1.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 1") },
    {   SettingDescription("clustering1.init_crp","FLOAT",false).initialFloat(1).min(0).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1, according to CRP").longDescription("Concentration parameter of the generating CRP")  },
    {   SettingDescription("clustering1.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1").longDescription("Initial number of components, the nodes are randomny split into")    }
};

const std::vector<ParameterDescription> MixtureBernoulli_collapsed::parameterDescriptions
{
    {   ParameterDescription("clustering1","INFINITE_CLUSTERING").shortDescription("clustering1 parameter").longDescription("")    },
    {   ParameterDescription("alpha1","REAL").shortDescription("concentration parameter for clustering of group 1").longDescription("")    },
    {   ParameterDescription("bp","REAL").shortDescription("link-count hyperparameter").longDescription("")    },
    {   ParameterDescription("bm","REAL").shortDescription("nonlink-count hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, MixtureBernoulli_collapsed> MixtureBernoulli_collapsed::Create(MixtureBernoulli_collapsed::MODELNAME);
