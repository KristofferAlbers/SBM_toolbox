/**
This code is provided as is without any warranty!

Implementation of the split-merge sampler
*/

#include "Sampler.h"

#include "foundation.h"
#include <time.h>
#include <chrono>

const std::string SplitMerge_infiniteClustering::SAMPLERNAME = "SplitMerge_infiniteClustering";

Creator<MCMC_sampler, SplitMerge_infiniteClustering> SplitMerge_infiniteClustering::Create(SplitMerge_infiniteClustering::SAMPLERNAME);

const std::vector<SettingDescription> SplitMerge_infiniteClustering::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The clustering parameter to sample") },
    {   SettingDescription("proposals","INT",false).initialInt(1).min(1).shortDescription("Number of split merger proposals")},
    {   SettingDescription("gibbssweeps","INT",false).initialInt(3).min(1).shortDescription("Number of restricted gibbs sweeps performed for each proposal")}

};

void SplitMerge_infiniteClustering::sample()
{
    StatisticalModel& model = *(parameter->model_);
    int numberOfNodes = parameter->getNumberOfItems();

    results.numSplitProposed = 0;
    results.numMergeProposed = 0;
    results.numSplitAccepted = 0;
    results.numMergeAccepted = 0;

    std::vector<double> Likelihoods;
    std::vector<size_t> Clusters;


   for(size_t SM = 0; SM<proposals; SM++)
    {
        size_t node_i;
        size_t node_j;
        size_t cluster_i ;
        size_t cluster_j ;

        do
        {
            node_i = 0 + (rand() % (int)(numberOfNodes-1 - 0 + 1));
            node_j = 0 + (rand() % (int)(numberOfNodes-1 - 0 + 1));
            cluster_i = parameter->getDataPointer()->getClusterId(node_i);
            cluster_j = parameter->getDataPointer()->getClusterId(node_j);
        }
        while(node_i==node_j );

        size_t cluster_i_original = cluster_i;
        size_t cluster_j_original = cluster_j;

        if(cluster_i == cluster_j)
        {

            //remember the 'merged' clustering
            double logLikelihood_before = model.computeLogLikelihood();
            double logPrior_before = model.computeLogPrior();

            //get all nodes clustered with i and j
            std::vector<size_t> S;

            Clustering::clusterIterator it;
            for( it = parameter->getDataPointer()->begin(cluster_i); it!=parameter->getDataPointer()->end(cluster_i); ++it)
            {
                if(*it!=node_i && *it!=node_j)
                {
                    S.push_back(*it);
                }
            }

            //move node j to an empty cluster
            parameter->moveItem_newCluster(node_j);

            cluster_j = parameter->getDataPointer()->getClusterId(node_j);

            std::vector<size_t> clusterIds;
            clusterIds.push_back(cluster_i);
            clusterIds.push_back(cluster_j);

            //randomly assign all nodes in S to either cluster_i or cluster_j
            assignRandomly(S,cluster_i,cluster_j);

            //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j
            const size_t numberOfSweeps = restrictedSweeps;
            std::vector<double> transitionProbabilities = intermediateGibbsSweeps(numberOfSweeps+1,S,clusterIds);

            //proposal state now obtained, compute MH acceptance probability
            double logQtrans = transitionProbabilities[transitionProbabilities.size()-1];

            double logPrior_after = model.computeLogPrior();
            double logLikelihood_after = model.computeLogLikelihood();
            double MH_logProb = logLikelihood_after+logPrior_after-logQtrans-logLikelihood_before-logPrior_before;

            double acceptanceProbability = 1;
            if(MH_logProb<1)
            {
                acceptanceProbability = exp(MH_logProb);
            }

            double randomval = ((double) rand() / (RAND_MAX));

            if(randomval>=acceptanceProbability)
            {   //reject (merge clusters)

                for(size_t i = 0; i< S.size(); i++)
                {
                    parameter->moveItem(S[i],cluster_i_original);
                }
                parameter->moveItem(node_i,cluster_i_original);
                parameter->moveItem(node_j,cluster_j_original);
                results.numSplitProposed++;
            }
            else
            {   //accept
                results.numSplitProposed++;
                results.numSplitAccepted++;
            }
        }
        else // MERGE
        {
            double mergePosteriorRatio = parameter->logPosteriorRatio_mergeClusters(cluster_i,cluster_j);
            double randomval = ((double) rand() / (RAND_MAX));
            bool rejectRR = false;
            if(randomval > exp(mergePosteriorRatio) )
            {
                rejectRR = true;
                results.numMergeProposed++;
                continue;
            }

            //remember the 'split' configuration
            double logLikelihood_before = model.computeLogLikelihood();
            double logPrior_before = model.computeLogPrior();

            //get all nodes clustered with i and j
            std::vector<size_t> S;
            std::vector<size_t> originalClusterIds;
            Clustering::clusterIterator it;
            for( it = parameter->getDataPointer()->begin(cluster_i); it!=parameter->getDataPointer()->end(cluster_i); ++it)
            {
                if(*it!=node_i)
                {
                    S.push_back(*it);
                    originalClusterIds.push_back(parameter->getDataPointer()->getClusterId(*it));
                }
            }
            for( it = parameter->getDataPointer()->begin(cluster_j); it!=parameter->getDataPointer()->end(cluster_j); ++it)
            {
                if(*it!=node_j)
                {
                    S.push_back(*it);
                    originalClusterIds.push_back(parameter->getDataPointer()->getClusterId(*it));
                }
            }

            sortVectorPair(&S,&originalClusterIds,ORDER_RANDOM_UNIFORM);

            std::vector<size_t> clusterIds;
            clusterIds.push_back(cluster_i);
            clusterIds.push_back(cluster_j);

            //randomly assign all nodes in S to either cluster_i or cluster_j
            assignRandomly(S,cluster_i,cluster_j);

            //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j, forced into original on last sweep
            const size_t numberOfSweeps = restrictedSweeps; //sweeps before forced
            std::vector<double> logtransitionprobabilities = intermediateGibbsSweeps(numberOfSweeps+1,S,clusterIds,originalClusterIds);

            //compute transition probability from launch to original
            double logQtrans = logtransitionprobabilities[logtransitionprobabilities.size()-1];

            //merge clusters
            for(size_t n:S){
                parameter->moveItem(n,cluster_i);
            }
            parameter->moveItem(node_i,cluster_i);
            parameter->moveItem(node_j,cluster_i);

            double logPrior_after = model.computeLogPrior();
            double logLikelihood_after = model.computeLogLikelihood();

            //compute MH acceptance probability
            double MH_logProb = logQtrans+logLikelihood_after+logPrior_after-logLikelihood_before-logPrior_before;
            double acceptanceProbability = 1;

            if(MH_logProb<1)
            {
                acceptanceProbability = exp(MH_logProb);
            }


            if(randomval>=acceptanceProbability)
            {   //reject merge
                parameter->moveItem_newCluster(node_j);
                size_t newClusterJ = parameter->getDataPointer()->getClusterId(node_j);

                for(size_t i = 0; i< S.size(); i++)
                {
                    if(originalClusterIds[i]==cluster_j_original){
                        parameter->moveItem(S[i],newClusterJ);
                    }
                    else{
                        parameter->moveItem(S[i],originalClusterIds[i]);
                    }
                }
                results.numMergeProposed++;

            }
            else
            {   //accept merge
                results.numMergeProposed++;
                results.numMergeAccepted++;
            }
        }
        Likelihoods.push_back(model.computeLogPosterior());
        Clusters.push_back(parameter->getDataPointer()->getNumberOfClusters());
    }//end of split merge sweep
}


//Restricted gibbs sweeps (forced)
inline std::vector<double> SplitMerge_infiniteClustering::intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds,std::vector<size_t>& forced)
{
    //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j
    Options gibbsOptions
    {
        {"name", "Gibbs sampler for the clustering"},
        {"parameter", parameter}
    };
    Gibbs_infiniteClustering sampler(gibbsOptions);
    return sampler.sample_restricted(numberOfSweeps,nodeIds,clusterIds,forced);
}

//Restricted gibbs sweeps
inline std::vector<double> SplitMerge_infiniteClustering::intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds)
{
    //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j
    Options gibbsOptions
    {
        {"name", "Gibbs sampler for the clustering"},
        {"parameter", parameter}
    };
    Gibbs_infiniteClustering sampler(gibbsOptions);

    return sampler.sample_restricted(numberOfSweeps,nodeIds,clusterIds);
}

inline void SplitMerge_infiniteClustering::assignRandomly(std::vector<size_t>& nodeIds, size_t cluster_a, size_t cluster_b){
    for(size_t n:nodeIds)
    {
        double randomval = ((double) rand() / (RAND_MAX));
        if(randomval<0.5)
            parameter->moveItem(n,cluster_a);
        else
            parameter->moveItem(n,cluster_b);
    }
}
