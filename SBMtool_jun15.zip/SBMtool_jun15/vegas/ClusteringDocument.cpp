/**
This code is provided as is without any warranty!

define global strings for arguments used in the ClusteringDocument
class.
*/

#include "ClusteringDocument.h"
const std::string ClusteringDocument::OPT_COMPONENTS = "components";
const std::string ClusteringDocument::OPT_ITEMS = "items";
const std::string ClusteringDocument::OPT_INIT = "init";
const std::string ClusteringDocument::OPT_INIT_STRING = "string";
const std::string ClusteringDocument::OPT_INIT_RANDOM = "random";
const std::string ClusteringDocument::OPT_INIT_CRP = "crp";
const std::string ClusteringDocument::OPT_INIT_FILE = "file";

