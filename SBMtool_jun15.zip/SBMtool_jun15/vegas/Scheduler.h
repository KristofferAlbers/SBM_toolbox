/**
This code is provided as is without any warranty!

This file defines classes for the different scheduler implementations.
The base class Schedular further contains generic i/o functions for
saving strings, and the state of a parameter or model.
*/


#ifndef SCHEDULER_H_INCLUDED
#define SCHEDULER_H_INCLUDED

#include "Options.h"
#include "settings.h"
#include "StatisticalModel.h"
#include "Sampler.h"

#include <vector>
#include <time.h>

class Scheduler
{
    Options options_;

public:
    Scheduler(Options o) : options_(o) {};
    Scheduler(){};

    /** function for saving a string to a file */
    void saveString(std::string filename, int sweep, std::string content)
    {
            FILE* file = fopen(filename.c_str(), "a");
            fprintf (file, "%d\t%s\n",sweep,content.c_str());
            fclose(file);
    }
    /** function for saving current state of the model to a file */
    void saveModel(std::string filename, int sweep, double loglikelihood, double logprior, double logposterior)
    {
            FILE* file = fopen(filename.c_str(), "a");
            fprintf (file, "%d\t%f %f %f \n",sweep,loglikelihood,logprior,logposterior);
            fclose(file);
    }
    /** function for creating files, into which information for a particular parameter can be written */
    void setupParameterFiles(std::string savepath, StatisticalModel* model_p, std::vector<ParameterDescription> model_parameters)
    {
        for(ParameterDescription pd : model_parameters)
        {
            std::string parameterName(pd.name_);
            std::string filename = savepath + parameterName + ".txt";
            Parameter* parameter = model_p->getParameter(parameterName);
            std::string parameterType = parameter->type_;
            FILE* file = fopen(filename.c_str(), "a");
            std::string savestring = "type:"+parameterType;
            fprintf (file, "%\%\t%s\n",savestring.c_str());
            fprintf (file, "%\%%s\t%s\n","sweep\tvalue");
            fclose(file);

        }
    }
    /**
        saves multiple parameter values into different files
        @param savepath - file path where files are located
        @param sweep - current sweep of the sampling procedure (to be written into the files)
        @param model_p - pointer to the statistical model object
        @param model_parameters - descriptions of the parameters associated with the statistical model
    */
    void saveParameters(std::string savepath, int sweep, StatisticalModel* model_p, std::vector<ParameterDescription> model_parameters)
    {
        for(ParameterDescription pd : model_parameters)
        {
            std::string parameterName(pd.name_);
            std::string filename = savepath + parameterName + ".txt";
            Parameter* parameter = model_p->getParameter(parameterName);
            std::string content = parameter->toString();
            saveString(filename,sweep,content);
        }
    }

    /** virtual function, that must be implemented in inherited schedulers, returns descriptions of the particular scheduler options/settings */
    virtual std::vector<SettingDescription> getSettingDescriptions() = 0;

    /**
        virtual function, that must be implemented in inherited schedulers,
        called when the sampling schedule is run
    */
    virtual void runSchedule(StatisticalModel* model, std::vector<std::unique_ptr<MCMC_sampler>>& mcmcsamplers, std::vector<std::unique_ptr<Max_sampler>>& maxsamplers) = 0;
};



/**
    Scheduler implementation, for exploring the posterior landscape of a given statistical model
*/
class PosteriorLandscapeScheduler: public Scheduler
{
public:
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::string SCHEDULERNAME;

    int random_seed = -1;
    bool init_seed_random = false;

    size_t burnin_sweeps = 10;
    size_t sample_sweeps = 100;
    size_t maximize_sweeps = 10;
    bool saveBurninState;
    std::string savePath = "results";
    std::string savePath_sweep = "/sampling";
    std::string savePath_max = "/max";
    std::string savePath_burnin = "/burnin_";



    PosteriorLandscapeScheduler() : Scheduler()
    {
    }

    PosteriorLandscapeScheduler(Options o) : Scheduler(o)
    {
        random_seed = parseSetting<int>("random_seed",settingDescriptions,o);
        init_seed_random = parseSetting<bool>("init_seed_random",settingDescriptions,o);

        savePath = parseSetting<std::string>("savepath",settingDescriptions,o);
        saveBurninState = parseSetting<bool>("save_burnin_state",settingDescriptions,o);

        burnin_sweeps = parseSetting<int>("burnin_sweeps",settingDescriptions,o);
        sample_sweeps = parseSetting<int>("sample_sweeps",settingDescriptions,o);
        maximize_sweeps  = parseSetting<int>("optimize_sweeps",settingDescriptions,o);

        savePath_sweep =  savePath + "/sampling_";
        savePath_max = savePath + "/max_";
        savePath_burnin = savePath + "/burnin_";


    }

    void runSchedule(StatisticalModel* model, std::vector<std::unique_ptr<MCMC_sampler>>& mcmcsamplers, std::vector<std::unique_ptr<Max_sampler>>& maxsamplers)
    {
        //seed random generator
        int randomseed = 0;
        if(random_seed!=-1)
        {
            randomseed = random_seed;

        }
        else if(init_seed_random)
        {
            randomseed = (time(NULL));
        }
        srand(randomseed);
        std::cout << "random seed: " << randomseed << std::endl;

        std::vector<ParameterDescription> model_parameters = model->getParameterDescriptions();
         //save initial state

        //do burnin
        for(size_t sweep = 0; sweep < burnin_sweeps; sweep ++)
        {
            for(size_t i = 0 ; i< mcmcsamplers.size(); i++)
            {
                MCMC_sampler* sampler = mcmcsamplers[i].get();
                std::cout << "sampler: " << sampler->name << std::endl;
                sampler->sample();
            }
        }
        //save state after burnin
        if(saveBurninState)
        {
            saveParameters(savePath_burnin,0,model,model_parameters);
            double loglikelihood = model->computeLogLikelihood();
            double logprior = model->computeLogPrior();
            double logposterior = model->computeLogPosterior();
            saveModel(savePath_burnin+"model.txt",0,loglikelihood,logprior,logposterior);
        }

        //vector to store intermediate parameter values
        std::vector<std::string> sweep_parameter_values;

        for(size_t sweep = 1; sweep <= sample_sweeps; sweep++)
        {
            for(size_t i = 0 ; i< mcmcsamplers.size(); i++)
            {
                MCMC_sampler* sampler = mcmcsamplers[i].get();
                sampler->sample();
            }
            //save sweep parameters and model
            if( true )
            {
                saveParameters(savePath_sweep,sweep,model,model_parameters);
            }
            if( true )
            {
                double loglikelihood = model->computeLogLikelihood();
                double logprior = model->computeLogPrior();
                double logposterior = model->computeLogPosterior();
                saveModel(savePath_sweep+"model.txt",sweep,loglikelihood,logprior,logposterior);
            }
            //perform optimization to find local posterior optimum
            if(maximize_sweeps > 0)
            {
                //save current solution
                sweep_parameter_values.clear();
                for(ParameterDescription pd : model_parameters)
                {
                    Parameter* parameter = model->getParameter(pd.name_);
                    std::string content = parameter->toString();
                    sweep_parameter_values.push_back(content);
                }

                //run procedure for maximizing
                size_t sweeps_to_reach_optimum = maximize_sweeps;
                for(size_t msweep = 1; msweep <= maximize_sweeps; msweep++)
                {
                    bool optimumReached = true;

                    for(size_t i = 0 ; i< maxsamplers.size(); i++)
                    {

                        Max_sampler* sampler = maxsamplers[i].get();

                        bool sampler_optimumReached = sampler->sample();
                        if(sampler_optimumReached == false)
                        {
                            optimumReached = false;
                        }

                    }
                    if(optimumReached)
                    {
                        sweeps_to_reach_optimum = sweep;
                        break;
                    }

                }

                double loglikelihood = model->computeLogLikelihood();
                double logprior = model->computeLogPrior();
                double logposterior = model->computeLogPosterior();
                //save proposed MAP solution
                saveParameters(savePath_max,sweeps_to_reach_optimum,model,model_parameters);
                saveModel(savePath_max+"model.txt",sweep,loglikelihood,logprior,logposterior);

                //set model parameters back to values before maximizing
                int i = 0;
                for(ParameterDescription pd : model_parameters)
                {
                    std::string parameterName(pd.name_);
                    Parameter* parameter = model->getParameter(parameterName);
                    parameter->setFromString(sweep_parameter_values[i]);
                    i++;
                }
            }
        }

    }

    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
    static Creator<Scheduler, PosteriorLandscapeScheduler> Create;


};


/**
    Default scheduler implementation. Performs sequential MCMC sampling, using
    the user defineds samplers.
*/
class DefaultScheduler : public Scheduler
{

public:
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::string SCHEDULERNAME;

        int random_seed = -1;
        bool init_seed_random = false;

        size_t burnin_sweeps = 10;
        size_t sample_sweeps = 100;
        size_t maximize_sweeps = 10;

        int save_parameter_rate = 10;
        int save_modeloutput_rate = 10;
        int subsample_rate = 1;

        bool saveInitialState = true;
        bool saveBurninState = true;
        bool saveFinalState = true;
        bool saveBestState = true;
        std::string savePath = "results";

        std::string savePath_initial = "/initial_";
        std::string savePath_burnin = "/burnin_";
        std::string savePath_sweep = "/sweep_";
        std::string savePath_max = "/max_";
        std::string savePath_map = "/map_";

    DefaultScheduler() : Scheduler()
    {
    }

    DefaultScheduler(Options o) : Scheduler(o)
    {
        random_seed = parseSetting<int>("random_seed",settingDescriptions,o);
        init_seed_random = parseSetting<bool>("init_seed_random",settingDescriptions,o);

        savePath = parseSetting<std::string>("savepath",settingDescriptions,o);

        burnin_sweeps = parseSetting<int>("burnin_sweeps",settingDescriptions,o);
        sample_sweeps = parseSetting<int>("sample_sweeps",settingDescriptions,o);
        maximize_sweeps  = parseSetting<int>("optimize_sweeps",settingDescriptions,o);

        save_parameter_rate = parseSetting<int>("save_parameter_rate",settingDescriptions,o);
        save_modeloutput_rate = parseSetting<int>("save_modeloutput_rate",settingDescriptions,o);
        subsample_rate = parseSetting<int>("sub_sample_rate",settingDescriptions,o);

        saveInitialState = parseSetting<bool>("save_initial_state",settingDescriptions,o);
        saveBurninState = parseSetting<bool>("save_burnin_state",settingDescriptions,o);
        saveFinalState = parseSetting<bool>("save_final_state",settingDescriptions,o);
        saveBestState = parseSetting<bool>("save_best_state",settingDescriptions,o);

        savePath_initial = savePath+"/initial_";
        savePath_burnin = savePath+"/burnin_";
        savePath_sweep = savePath+"/sweep_";
        savePath_max = savePath+"/max_";
        savePath_map = savePath+"/map_";

    }


    void runSchedule(StatisticalModel* model, std::vector<std::unique_ptr<MCMC_sampler>>& mcmcsamplers, std::vector<std::unique_ptr<Max_sampler>>& maxsamplers)
    {
        //seed random generator
        int randomseed = 0;
        if(random_seed!=-1)
        {
            randomseed = random_seed;

        }
        else if(init_seed_random)
        {
            randomseed = (time(NULL));
        }
        srand(randomseed);
        std::cout << "random seed: " << randomseed << std::endl;

        std::vector<ParameterDescription> model_parameters = model->getParameterDescriptions();
         //save initial state

        if(saveInitialState)
        {
            saveParameters(savePath_initial,0,model,model_parameters);
            double loglikelihood = model->computeLogLikelihood();
            double logprior = model->computeLogPrior();
            double logposterior = model->computeLogPosterior();
            saveModel(savePath_initial+"model.txt",0,loglikelihood,logprior,logposterior);
        }

        //do burnin
        for(size_t sweep = 0; sweep < burnin_sweeps; sweep ++)
        {
            for(size_t i = 0 ; i< mcmcsamplers.size(); i++)
            {
                MCMC_sampler* sampler = mcmcsamplers[i].get();
                std::cout << "sampler: " << sampler->name << std::endl;
                sampler->sample();
            }
        }
        //save state after burnin
        if(saveBurninState)
        {
            saveParameters(savePath_burnin,0,model,model_parameters);
            double loglikelihood = model->computeLogLikelihood();
            double logprior = model->computeLogPrior();
            double logposterior = model->computeLogPosterior();
            saveModel(savePath_burnin+"model.txt",0,loglikelihood,logprior,logposterior);
        }

        //save solution with highest posterior (initialize as first).
        double loglikelihood_old = model->computeLogLikelihood();
        double logprior_old = model->computeLogPrior();
        double logposterior_old = model->computeLogPosterior();
        size_t max_solution_sweep = 0;
        std::vector<std::string> max_solution_parameters;
        for(ParameterDescription pd : model_parameters)
        {
            Parameter* parameter = model->getParameter(pd.name_);
            std::string content = parameter->toString();
            max_solution_parameters.push_back(content);
        }

        for(size_t sweep = 1; sweep <= sample_sweeps; sweep++)
        {
            for(size_t i = 0 ; i< mcmcsamplers.size(); i++)
            {
                MCMC_sampler* sampler = mcmcsamplers[i].get();
                sampler->sample();
            }
            if( sweep % save_parameter_rate == 0)
            {
                saveParameters(savePath_sweep,sweep,model,model_parameters);
            }
            if( sweep % save_modeloutput_rate == 0)
            {
                double loglikelihood = model->computeLogLikelihood();
                double logprior = model->computeLogPrior();
                double logposterior = model->computeLogPosterior();
                saveModel(savePath_sweep+"model.txt",sweep,loglikelihood,logprior,logposterior);
            }
            //save solution if posterior better than previous
            if( sweep % subsample_rate == 0)
            {
                double loglikelihood = model->computeLogLikelihood();
                double logprior = model->computeLogPrior();
                double logposterior = model->computeLogPosterior();

                if(logposterior>logposterior_old)
                {
                    logposterior_old = loglikelihood;
                    logprior_old = logprior;
                    logposterior_old = logposterior;
                    max_solution_sweep = sweep;

                    max_solution_parameters.clear();
                    for(ParameterDescription pd : model_parameters)
                    {
                        Parameter* parameter = model->getParameter(pd.name_);
                        std::string content = parameter->toString();
                        max_solution_parameters.push_back(content);
                    }
                }
            }
        }

        if(maximize_sweeps > 0)
        {
            //set model parameters to max found in sampling
            int i = 0;
            for(ParameterDescription pd : model_parameters)
            {
                std::string parameterName(pd.name_);
                Parameter* parameter = model->getParameter(parameterName);
                parameter->setFromString(max_solution_parameters[i]);
                i++;
            }

            double loglikelihood = model->computeLogLikelihood();
            double logprior = model->computeLogPrior();
            double logposterior = model->computeLogPosterior();

            //save max solution
            saveParameters(savePath_max,max_solution_sweep,model,model_parameters);
            saveModel(savePath_max+"model.txt",max_solution_sweep,loglikelihood,logprior,logposterior);

            //run procedure for maximizing
            size_t sweeps_to_reach_optimum = maximize_sweeps;
            for(size_t sweep = 1; sweep <= maximize_sweeps; sweep++)
            {
                bool optimumReached = true;

                for(size_t i = 0 ; i< maxsamplers.size(); i++)
                {
                    Max_sampler* sampler = maxsamplers[i].get();
                    bool sampler_optimumReached = sampler->sample();
                    if(sampler_optimumReached == false)
                    {
                        optimumReached = false;
                    }
                }
                if(optimumReached)
                {
                    sweeps_to_reach_optimum = sweep;
                    break;
                }
            }
            loglikelihood = model->computeLogLikelihood();
            logprior = model->computeLogPrior();
            logposterior = model->computeLogPosterior();
            //save proposed MAP solution
            saveParameters(savePath_map,sweeps_to_reach_optimum,model,model_parameters);
            saveModel(savePath_map+"model.txt",sweeps_to_reach_optimum,loglikelihood,logprior,logposterior);
        }
    }
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
    static Creator<Scheduler, DefaultScheduler> Create;

};

/**
    Example of a scheduler implementation that can be used to debug program modules.
    It does not perform any sampling of model parameters (ignores options/settings)
*/
class DebugScheduler : public Scheduler
{
public:
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::string SCHEDULERNAME;

    DebugScheduler() : Scheduler()
    {
    }

    DebugScheduler(Options o) : Scheduler(o)
    {
        int testnumber = parseSetting<int>("testnumber",settingDescriptions,o);
        std::cout << " ------------- test number: " << testnumber << " -------------- " << std::endl;
        std::cout << " ----------------------------------------------------" << std::endl;

        std::cout << " ----------------------------------------------------" << std::endl;
    }

    void runSchedule(StatisticalModel* model, std::vector<std::unique_ptr<MCMC_sampler>>& mcmcsamplers, std::vector<std::unique_ptr<Max_sampler>>& maxsamplers)
    {
        std::cout << "DB function: runSchedule done" << std::endl;

    }
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
    static Creator<Scheduler, DebugScheduler> Create;

};


#endif // SCHEDULER_H_INCLUDED
