/*
Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import gui.ModelSettings_list.SettingComponent;

public class MainFrame {

	public IOcommunicator communicator;
	public JFrame frame;	
	
	Model_panel modelpanel;
	Scheduler_panel schedulerpanel;
	JPanel elements = new JPanel();
	
	MacroTextArea macroArea = new MacroTextArea();
	JTextPane infoPane = new JTextPane();
	JTextPane descriptionPane = new JTextPane();
	
	SettingsField currentSelectedSettingsField;
	SettingComponent currentSelectedSettingComponent;
	
	
	public MainFrame()
	{
		communicator = new IOcommunicator();
				
		frame = new JFrame("GUI");
		frame.setSize(1000, 600);
		
		final ArrayList<String> schedluerNames = communicator.getSchedulers();
		final ArrayList<String> modelNames = communicator.getModels();
		final ArrayList<String> mcmcNames = communicator.getMCMCsamplers();
		final ArrayList<String> mapNames = communicator.getMAPsamplers();
		
		
		schedulerpanel = new Scheduler_panel(this,schedluerNames);
		modelpanel = new Model_panel(this,modelNames);
		

		

		
		elements.setLayout(new BoxLayout(elements,BoxLayout.Y_AXIS));
		final JScrollPane scroller =new JScrollPane(elements); 
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		TitledBorder scrollerBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"Configuration file editor");
		//TitledBorder scrollerBorder = new TitledBorder(new EmptyBorder(10, 10, 10, 10), "config file");
		
		scrollerBorder.setTitleColor(Color.darkGray);
		scroller.setBorder(scrollerBorder);
		//modelSelecter.setMaximumSize(new Dimension(modelSelecter.getMaximumSize().width, modelSelecter.getMinimumSize().height));

		
		
		frame.setLayout(new BorderLayout());
		frame.add(scroller,BorderLayout.CENTER);
		
		elements.add(macroArea);
		elements.add(schedulerpanel);
		elements.add(modelpanel);
		
		JPanel tipsPanel = new JPanel();
		tipsPanel.setLayout(new BoxLayout(tipsPanel, BoxLayout.Y_AXIS));
		
		descriptionPane.setEditable(false);
		descriptionPane.setBackground(new Color(240, 240, 240));
		infoPane.setEditable(false);
		infoPane.setBackground(new Color(240, 240, 240));
		TitledBorder descriptionBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"Selected model description");
		TitledBorder infoBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"Selected setting description");
		descriptionPane.setPreferredSize(new Dimension(300, 300));
		
		infoPane.setPreferredSize(new Dimension(300, 300));
		descriptionPane.setPreferredSize(new Dimension(300, 300));
		
		JScrollPane infoScroller = new JScrollPane(infoPane);
		JScrollPane descriptionScroller = new JScrollPane(descriptionPane);
		infoScroller.setBorder(infoBorder);
		descriptionScroller.setBorder(descriptionBorder);

		
		tipsPanel.add(descriptionScroller);
		tipsPanel.add(infoScroller);
		
		frame.add(tipsPanel,BorderLayout.EAST);
		
		
		
		JButton addMCMCbutton = new JButton("add MCMC sampler");
		JButton addMAPbutton = new JButton("add map sampler");
		JButton configFilebutton = new JButton("create config file");
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(addMCMCbutton);
		buttonPanel.add(addMAPbutton);
		buttonPanel.add(configFilebutton);
		
		
		frame.add(buttonPanel,BorderLayout.SOUTH);
		final MainFrame framm = this;
		addMCMCbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				elements.add(new McmcSampler_panel(framm, mcmcNames));
				elements.revalidate();
				JScrollBar vertical = scroller.getVerticalScrollBar();
				vertical.setValue( vertical.getMaximum() );	
			}
		});
		addMAPbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				elements.add(new MapSampler_panel(framm, mapNames));	
				elements.revalidate();
				elements.repaint();
				JScrollBar vertical = scroller.getVerticalScrollBar();
				vertical.setValue( vertical.getMaximum() );	
			}
		});
		configFilebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Component[] clist = elements.getComponents();


				String date = new SimpleDateFormat("dd/MM/yy HH:mm:ss").format(new Date());

				String text = "%config file, created "+date+"\n";
				for(Component c:clist)
				{
					text = text+c.toString()+"\n";
					//System.out.println(c.toString());
				}
				new ConfigFrame(text);
			}
		});
		
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public ArrayList<String> newModelSelected(String modelName) {
		ArrayList<String> modelDescription = communicator.getModel(modelName);		
		return modelDescription;		
	}

	public ArrayList<String> newSchedulerSelected(String schedulerName) {
		ArrayList<String> modelDescription = communicator.getScheduler(schedulerName);
		return modelDescription;		
	}

	public ArrayList<String> newMCMCsamplerSelected(String samplerName) {
		ArrayList<String> modelDescription = communicator.getMCMCsampler(samplerName);
		return modelDescription;
	}
	
	public ArrayList<String> newMAPsamplerSelected(String samplerName) {
		ArrayList<String> modelDescription = communicator.getMAPsampler(samplerName);	
		return modelDescription;
	}

	public void removeElement(Component o)
	{
		elements.remove(o);
		elements.revalidate();
	}
	
	class MacroTextArea extends JTextArea
	{
		public String toString()
		{
			return this.getText();
		}
	}
	
	class ConfigFrame
	{
		public ConfigFrame(String text)
		{
			frame = new JFrame("Configuration file");
			frame.setSize(300, 600);
			final JTextArea textArea = new JTextArea(text);
			JScrollPane sp = new JScrollPane(textArea);
			frame.setLayout(new BorderLayout());
			frame.add(sp,BorderLayout.CENTER);
			frame.setVisible(true);
			
			JButton saveButton = new JButton("save file");
			
			frame.add(saveButton,BorderLayout.SOUTH);
			
			saveButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					JFileChooser chooser = new JFileChooser();
					chooser.setDialogTitle("Save current file");
					chooser.setApproveButtonText("save");
					int option = chooser.showOpenDialog(frame);
					if(option == JFileChooser.APPROVE_OPTION){
						if(chooser.getSelectedFile()!=null){
							File selectedFile = chooser.getSelectedFile();
							
							FileWriter fw;
							try {
								fw = new FileWriter (selectedFile.getAbsolutePath());
						        textArea.write(fw); 
							} catch (IOException e1) {
								 JOptionPane.showMessageDialog(new JFrame(), "File could not be saved!", "IOException",
									        JOptionPane.ERROR_MESSAGE);
								e1.printStackTrace();
							}
						}
					}
				}
			});
		}
		
		
	}
}
