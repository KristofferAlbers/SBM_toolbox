/*
Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.BadLocationException;

import gui.ModelSettings_list.SettingComponent;

public class SettingsField extends JPanel{
	MainFrame mainFrame;
	JTextArea settings = new JTextArea();
	JTextPane description = new JTextPane();
	JTextPane info = new JTextPane();
	
	TitledBorder settingsBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"settings");
	TitledBorder infoBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"info");
	TitledBorder descriptionBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"description");

	
	public SettingsField(MainFrame mainFrame)
	{
		this.mainFrame = mainFrame;
				
		
				
		info.setEditable(false);
		description.setEditable(false);
		
		this.setLayout(new BorderLayout());
		this.add(settings,BorderLayout.CENTER);
		
		JScrollPane p = new JScrollPane(info);
		p.setBorder(infoBorder);
		info.setBackground(Color.yellow);
		info.setPreferredSize(new Dimension(300, 50));
		//this.add(p, BorderLayout.EAST);


		settings.addKeyListener(new KeyListener() {			
			public void keyTyped(KeyEvent arg0) {
			}			
			public void keyReleased(KeyEvent arg0) {
				pressed();
			}			
			public void keyPressed(KeyEvent arg0) {
			}
		});
		settings.addMouseListener(new MouseListener() {		
			public void mouseReleased(MouseEvent arg0) {				
			}
			public void mousePressed(MouseEvent arg0) {				
			}
			public void mouseExited(MouseEvent arg0) {
			}
			public void mouseEntered(MouseEvent arg0) {
			}
			public void mouseClicked(MouseEvent arg0) {
				pressed();
			}
		});
		
	}
	ModelSettings_list settingslist;
	void assign(String name_,String description_,ModelSettings_list settingslist,boolean setDescription)
	{
		
		descriptionBorder.setTitle(name_);
		this.settingslist = settingslist;
		
		if(setDescription)
			mainFrame.descriptionPane.setText(description_);
		
		settings.setText("");
    	 
		 
    	 String text = "";
    	 for(SettingComponent sc:settingslist.settings)
    	 {
    		 text = text+"    "+sc.name+ "  =  "+ sc.originalValue + "\n";
    	 }
    	 settings.setText(text);
    	 
	}
	
	void pressed()
	{
		int carretPos = settings.getCaretPosition();
		int line;
		try {
			line = settings.getLineOfOffset(carretPos);
			
			int start = settings.getLineStartOffset(line);
			int end = settings.getLineEndOffset(line);
			String text = settings.getText(start, end - start);
			
			String[] texts = text.split("=");
			
			String setting_ = texts[0].trim();
			
			
			info.setText("unknown setting \"" + setting_ + "\"");
			
			if(settingslist!=null)
			{
				for(SettingComponent sc : settingslist.settings)
				{
					if(sc.name.equals(setting_))
					{
						String infotext = sc.name + "  (" + sc.type + ")\n"+sc.description+
											"\n\n  default value = " + sc.originalValue + 
											"\n  critical = " + sc.isCritical +
											"\n\n"+sc.longDescription;
						mainFrame.infoPane.setText(infotext);
						
						mainFrame.currentSelectedSettingsField = this;
						mainFrame.currentSelectedSettingComponent = sc;						
					}
					
				}	

				if(texts.length<2)
				{
					
				}
				else
				{
					String value_ = texts[1].trim();	
				}
				
				
				
				System.out.println(" " + line+ "  " + text);
			}
			else
			{

			}
			
			
			
			
			
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}
	
}
