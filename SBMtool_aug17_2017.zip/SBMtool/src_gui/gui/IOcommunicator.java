/*
Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


package gui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class IOcommunicator 
{
	String executeCommand = "./";
	String programName = "network_datastructure";
	String schedulers_command = "info schedulers";
	String models_command = "info models";
	String mcmcsamplers_command = "info mcmcsamplers";
	String mapsamplers_command = "info mapsamplers";
	
	
	String getmodels_command = "./sbmTool info models";
	String getschedulers_command = "./sbmTool info schedulers";
	String getmcmcsamplers_command = "./sbmTool info mcmcsamplers";
	String getmapsamplers_command = "./sbmTool info mapsamplers";
	
	
	
	public IOcommunicator()
	{
		
		
	}

	public ArrayList<String> getModels()
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmodels_command); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 
			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
		} 
		catch(IOException e1) 
		{
			System.out.println("ERROR1");
		} 
		catch(InterruptedException e2) 
		{
			System.out.println("ERROR2");
		} 

		return lines;		
	}

	public ArrayList<String> getSchedulers()
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getschedulers_command); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
		} 
		catch(IOException e1) 
		{
			System.out.println("ERROR1");
		} 
		catch(InterruptedException e2) 
		{
			System.out.println("ERROR2");
		} 

		return lines;		
	}
	public ArrayList<String> getMCMCsamplers()
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmcmcsamplers_command); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
		} 
		catch(IOException e1) 
		{
			System.out.println("ERROR1");
		} 
		catch(InterruptedException e2) 
		{
			System.out.println("ERROR2");
		} 

		return lines;		
	}
	public ArrayList<String> getMAPsamplers()
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmapsamplers_command); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
		} 
		catch(IOException e1) 
		{
			System.out.println("ERROR1");
		} 
		catch(InterruptedException e2) 
		{
			System.out.println("ERROR2");
		} 

		return lines;		
	}
	

	public ArrayList<String> getMCMCsampler(String modelName)
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmcmcsamplers_command+" "+modelName); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
			} 
			catch(IOException e1) 
			{
				System.out.println("ERROR1");
			} 
			catch(InterruptedException e2) 
			{
				System.out.println("ERROR2");
			} 

		return lines;		
	}
	public ArrayList<String> getMAPsampler(String modelName)
	{
		System.out.println("CALLED");
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmapsamplers_command+" "+modelName); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 
			System.out.println("HERE: " + getmapsamplers_command + " " + modelName);

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
			} 
			catch(IOException e1) 
			{
				System.out.println("ERROR1");
			} 
			catch(InterruptedException e2) 
			{
				System.out.println("ERROR2");
			} 

		return lines;		
	}
	
	public ArrayList<String> getModel(String modelName)
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getmodels_command+" "+modelName); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 
			System.out.println("HERE");

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
			} 
			catch(IOException e1) 
			{
				System.out.println("ERROR1");
			} 
			catch(InterruptedException e2) 
			{
				System.out.println("ERROR2");
			} 

		return lines;		
	}
	
	public ArrayList<String> getScheduler(String schedulerName)
	{
		ArrayList<String> lines = new ArrayList<>();

		try 
		{ 
			Process p=Runtime.getRuntime().exec(getschedulers_command+" "+schedulerName); 
			p.waitFor(); 
			BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream())); 
			String line=reader.readLine(); 
			System.out.println("HERE");

			while(line!=null) 
			{ 
				System.out.println(line); 
				lines.add(line);
				line=reader.readLine(); 
			} 
			} 
			catch(IOException e1) 
			{
				System.out.println("ERROR1");
			} 
			catch(InterruptedException e2) 
			{
				System.out.println("ERROR2");
			} 

		return lines;		
	}
	
	
	
}
