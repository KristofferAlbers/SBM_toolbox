/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "IrmPoisson_multigraph.h"


void IrmPoisson_multigraph::getNodeCounts(size_t nodeId, Data& data_, Clustering& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts)
{
    nodecounts.linkSum.clear();
    nodecounts.linkSum.resize(max);

    nodecounts.nodePairs.clear();
    nodecounts.nodePairs.resize(max);

    nodecounts.missingNodePairs.clear();
    nodecounts.missingNodePairs.resize(max);


    if(directed)
    {
        nodecounts.linkSum_reversed.clear();
        nodecounts.linkSum_reversed.resize(max);

        nodecounts.nodePairs_reversed.clear();
        nodecounts.nodePairs_reversed.resize(max);

        nodecounts.missingNodePairs_reversed.clear();
        nodecounts.missingNodePairs_reversed.resize(max);


        for(size_t c = 0 ; c< max; c++)
        {
            if(clustering_.exist(c))
            {
                nodecounts.nodePairs[c] = clustering_.getSize(c);
                nodecounts.nodePairs_reversed[c] = clustering_.getSize(c);
            }

        }
        nodecounts.nodePairs[currentCluster]--;
        nodecounts.nodePairs_reversed[currentCluster]--;


        for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);

            nodecounts.linkSum[clusterId]+=value;
        }

        for(NetworkData<size_t>::iterator iter = data_.data_transposed.begin(nodeId) ; iter!=data_.data_transposed.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);

            nodecounts.linkSum_reversed[clusterId]+=value;
        }

        if(usemissing_)
        {
            for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.missingNodePairs[clusterId]++;
            }
            for(NetworkData<size_t>::iterator iter = data_.missing_transposed.begin(nodeId) ; iter!=data_.missing_transposed.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.missingNodePairs_reversed[clusterId]++;
            }
        }

    }
    else
    {
        for(size_t c = 0 ; c< max; c++)
        {
            if(clustering_.exist(c))
            {
                nodecounts.nodePairs[c] = clustering_.getSize(c);
            }
        }
        nodecounts.nodePairs[currentCluster]--;

        for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.linkSum[clusterId]+=value;
        }

        if(usemissing_)
        {
            for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.missingNodePairs[clusterId]++;
            }
            for(NetworkData<size_t>::iterator iter = data_.missing_transposed.begin(nodeId) ; iter!=data_.missing_transposed.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.missingNodePairs_reversed[clusterId]++;
            }
        }
    }

}





void IrmPoisson_multigraph::computeAllSufficientStatistics()
{
    for(int i = 0; i < data.size(); i++)
    {
        computeSufficientStatistics(data[i]);
    }
}

void IrmPoisson_multigraph::computeSufficientStatistics(Data& data_)
{

    data_.sufstats.withmissing = usemissing_;
    data_.sufstats.directed = directed;

    NetworkData<size_t>& network = data_.network.data;

    NetworkData<size_t>& missing = data_.network.missing;

    Clustering& clustering_ = data_.clustering;

    SquareMatrix<size_t>& nodePairs = data_.sufstats.nodePairs;
    SquareMatrix<size_t>& linkSum = data_.sufstats.linkSum;
    SquareMatrix<size_t>& missingNodePairs = data_.sufstats.missingNodePairs;

    nodePairs.clear();
    linkSum.clear();
    missingNodePairs.clear();

    size_t newMaxClusters = std::max(clustering_.getNumberOfClusters()*2,(size_t)20);

    nodePairs.setNewMax(newMaxClusters);
    linkSum.setNewMax(newMaxClusters);
    missingNodePairs.setNewMax(newMaxClusters);

    //compute link sums
    for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
    {
        if(!clustering_.assigned(sourceNode))
        {
            continue;
        }

        size_t sourceCluster = clustering_.getClusterId(sourceNode);

        if(sourceCluster>=nodePairs.max)
        {
            size_t newMaxClusters = std::max(sourceCluster+1,nodePairs.max*2);
            nodePairs.setNewMax(newMaxClusters);
            linkSum.setNewMax(newMaxClusters);
        }
        for(typename NetworkData<size_t>::iterator iter = network.begin(sourceNode); iter!=network.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();


            if(!clustering_.assigned(targetNode))
            {
                continue;
            }

            size_t weight = iter.getValue();

            //std::cout << sourceNode << " has link to " << targetNode << " with weight " << weight << std::endl;

            size_t targetCluster = clustering_.getClusterId(targetNode);

            if(targetCluster>=nodePairs.max)
            {
                size_t newMaxClusters = std::max(targetCluster+1,nodePairs.max*2);
                nodePairs.setNewMax(newMaxClusters);
                linkSum.setNewMax(newMaxClusters);
                missingNodePairs.setNewMax(newMaxClusters);
            }
            linkSum.matrix[sourceCluster*linkSum.max+targetCluster] += weight;
        }
    }

    if(!directed)
    {
        for(size_t i = 0 ; i < linkSum.max; i++)
        {
            linkSum.matrix[i*linkSum.max+i]/=2;
        }
    }

    for( Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer )
    {
        size_t clusterIdFrom = citer.index();

        for( Clustering::iterator iter2 = clustering_.begin() ; iter2!=clustering_.end() ; iter2++ )
        {
            size_t clusterIdTo = iter2.index();
            if(clusterIdFrom == clusterIdTo)
            {
                //within
                size_t nodesInCluster = clustering_.getSize(clusterIdTo);
                size_t pairs;
                if(!directed)
                {
                    pairs = (nodesInCluster)* (nodesInCluster - 1) *.5;
                }
                else
                {
                    pairs = (nodesInCluster)* (nodesInCluster - 1);
                }
                nodePairs.matrix[clusterIdFrom*nodePairs.max+clusterIdTo] = pairs;
            }
            else
            {
                //between
                size_t nodesInClusterFrom = clustering_.getSize(clusterIdFrom);
                size_t nodesInClusterTo = clustering_.getSize(clusterIdTo);
                size_t pairs = nodesInClusterFrom*nodesInClusterTo;

                nodePairs.matrix[clusterIdFrom*nodePairs.max+clusterIdTo] = pairs;
            }
        }
    }


    //compute missing links
    if(usemissing_)
    {
        for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
        {

            if(!clustering_.assigned(sourceNode))
            {
                continue;
            }

            size_t sourceCluster = clustering_.getClusterId(sourceNode);

            for(typename NetworkData<size_t>::iterator iter = missing.begin(sourceNode); iter!=missing.end(sourceNode) ; iter++)
            {
                size_t targetNode = iter.getTarget();

                if(!clustering_.assigned(targetNode))
                {
                    continue;
                }


                size_t targetCluster = clustering_.getClusterId(targetNode);
                missingNodePairs.matrix[sourceCluster*missingNodePairs.max+targetCluster] += 1;
            }
        }
        if(!directed)
        {
            for(size_t i = 0 ; i < missingNodePairs.max; i++)
            {
                missingNodePairs.matrix[i*missingNodePairs.max+i]/=2;
            }
        }
    }

}





double IrmPoisson_multigraph::computeLogLikelihood()
{
    double likelihood = 0;
    for(int netID = 0 ;netID < networks.size(); netID++)
    {
        likelihood += computeLogLikelihood(data[netID]);
    }
    return likelihood;
}


double IrmPoisson_multigraph::computeLogLikelihood(Data& data_)
{

    UnipartiteNetwork<size_t>& network = data_.network;
    Clustering& clustering_ = data_.clustering;
    SufficientStatistics& sufstats = data_.sufstats;

    double a = param.a_;
    double b = param.b_;

    double factsum = 0;

    for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
    {
        if(!clustering_.assigned(sourceNode))
        {
            continue;
        }

        for(typename NetworkData<size_t>::iterator iter = network.data.begin(sourceNode); iter!=network.data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();

            if((!directed && (sourceNode>targetNode) ) || !clustering_.assigned(targetNode) )
            {
                continue;
            }

            size_t value = iter.getValue();

            double factval = factln_table.logfactorial(value);
            factsum += factval;
        }
    }

    factsum = -factsum; //(log(1) - factsum)

    double clustsum = 0;

    for( Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer )
    {
        size_t clusterIdFrom = citer.index();

        for( Clustering::iterator iter2 = clustering_.begin() ; iter2!=clustering_.end() ; iter2++ )
        {
            size_t clusterIdTo = iter2.index();


            if(!directed && (clusterIdFrom>clusterIdTo) )
            {
                continue;
            }
            clustsum += ( a*log( b ) ) - ( gammaln_table.gammaln(0, a  )  );
            clustsum += ( gammaln_table.gammaln(sufstats.getLinkSum(clusterIdFrom, clusterIdTo) , a ))  - (  ( sufstats.getLinkSum(clusterIdFrom, clusterIdTo) + a ) * log( sufstats.getNodePairs(clusterIdFrom,clusterIdTo) - sufstats.getMissingNodePairs(clusterIdFrom,clusterIdTo) + b )  );
        }
    }
    //std::cout << " loglikelihood: " << clustsum << " + " << factsum << std::endl;


    return clustsum + factsum;

}

double IrmPoisson_multigraph::computeLogPrior()
{

    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;


    const size_t noc = clustering_.getNumberOfClusters();
    const size_t J = clustering_.getNumberOfItems();

    double logprior = noc * logalpha_;
    logprior += lgamma(alpha_);
    logprior -= lgamma(J+alpha_);

    for(Clustering::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
    {
        logprior += lgamma(clustering_.getSize(iter.index()));
    }
    //logprior -= logalpha_;
    //std::cout << " logprior: " << logprior << std::endl;

    return logprior * networks.size();


}

double IrmPoisson_multigraph::computeLogPosterior()
{
    return computeLogPrior()+computeLogLikelihood();
}


partial_vector<double> IrmPoisson_multigraph::effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters)
{

    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.nodePairs.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    NodeCounts<size_t> nodecounts;

    partial_vector<double> logps;

    for(int netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];

        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        for(std::vector<size_t>::iterator itouter = restrictedClusters.begin() ; itouter!=restrictedClusters.end() ; ++itouter)
        {
            size_t cluster = *itouter;
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }
        }
    }
    return logps;

}

partial_vector<double> IrmPoisson_multigraph::effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster)
{

    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.nodePairs.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(int netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];
        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        //existing clusters
        Clustering::iterator outerIter;
        for(outerIter = begin ; outerIter!=end; ++outerIter)
        {
            size_t cluster = outerIter.index();
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }
        }
        //new cluster
        if(appendForNewCluster)
        {
            double logprior = logPrior_effectiveChange_newCluster(nodeId,currentCluster,currentClusterSize,nodecounts);
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data_,clustering_,param,currentCluster,currentClusterSize,nodecounts);
            if(logps.exist(max))
            {
               logps[max] += logprior+loglikelihood;
            }
            else
            {
                logps.set(max,logprior+loglikelihood);
            }
        }

    }
    return logps;
}




double IrmPoisson_multigraph::effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2)
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;
    double& a = param.a_;
    double& b = param.b_;


    if(cluster1 == cluster2)
    {
        return 0;
    }
    else
    {
        //compute change in prior
        double dlogPrior = 0;
        dlogPrior -= clustering_.getNumberOfClusters()  * logalpha_;
        dlogPrior += (clustering_.getNumberOfClusters()-1 ) * logalpha_;
        dlogPrior -= lgamma(clustering_.getSize(cluster1));
        dlogPrior -= lgamma(clustering_.getSize(cluster2));
        dlogPrior += lgamma(clustering_.getSize(cluster1) + clustering_.getSize(cluster2) );

        dlogPrior = dlogPrior*networks.size();

        //add change in likelihood
        double dlogLikelihood = 0;

        for(int netID = 0; netID<networks.size(); netID++)
        {
            SufficientStatistics& sf = data[netID].sufstats;


            SquareMatrix<size_t>& nodePairs = sf.nodePairs;
            SquareMatrix<size_t>& linkSum = sf.linkSum;
            SquareMatrix<size_t>& missingNodePairs = sf.missingNodePairs;

            for(Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer)
            {
                const size_t clusterId = citer.index();
                if(clusterId == cluster1 || clusterId == cluster2)
                {
                    continue;
                }
                else
                {

                    const size_t Npci = linkSum.get(clusterId,cluster1);
                    const size_t Nmci = nodePairs.get(clusterId,cluster1) - missingNodePairs.get(clusterId,cluster1);
                    const size_t Npcj = linkSum.get(clusterId,cluster2);
                    const size_t Nmcj = nodePairs.get(clusterId,cluster2) - missingNodePairs.get(clusterId,cluster2);

                    dlogLikelihood -= ( FUNC(Npci,a , Nmci,b) - FUNC(0,a,0,b) );
                    dlogLikelihood -= ( FUNC(Npcj,a , Nmcj,b) - FUNC(0,a,0,b) );
                    dlogLikelihood += ( FUNC(Npci+Npcj,a , Nmci+Nmcj, b) - FUNC(0,a,0,b));

                    if(directed){
                        size_t Npci = linkSum.get(cluster1,clusterId);
                        const size_t Nmci = nodePairs.get(cluster1,clusterId) - missingNodePairs.get(cluster1,clusterId);
                        const size_t Npcj = linkSum.get(cluster2,clusterId);
                        const size_t Nmcj = nodePairs.get(cluster2,clusterId) - missingNodePairs.get(cluster2,clusterId);

                        dlogLikelihood -= ( FUNC(Npci,a , Nmci,b) - FUNC(0,a,0,b) );
                        dlogLikelihood -= ( FUNC(Npcj,a , Nmcj,b) - FUNC(0,a,0,b) );
                        dlogLikelihood += ( FUNC(Npci+Npcj,a , Nmci+Nmcj, b) - FUNC(0,a,0,b));
                    }


                }
            }
            const size_t Npii = linkSum.get(cluster1,cluster1);
            const size_t Nmii = nodePairs.get(cluster1,cluster1) - missingNodePairs.get(cluster1,cluster1);
            const size_t Npjj = linkSum.get(cluster2,cluster2);
            const size_t Nmjj = nodePairs.get(cluster2,cluster2) - missingNodePairs.get(cluster2,cluster2);
            const size_t Npij = linkSum.get(cluster1,cluster2);
            const size_t Nmij = nodePairs.get(cluster1,cluster2) - missingNodePairs.get(cluster1,cluster2);

            dlogLikelihood -= ( FUNC(Npii,a , Nmii,b) - FUNC(0,a,0,b) );
            dlogLikelihood -= ( FUNC(Npjj,a, Nmjj,b) - FUNC(0,a,0,b) );
            dlogLikelihood -= ( FUNC(Npij,a , Nmij,b) - FUNC(0,a,0,b) );

            if(directed)
            {
                const size_t Npji = linkSum.get(cluster2,cluster1);
                const size_t Nmji = nodePairs.get(cluster2,cluster1) - missingNodePairs.get(cluster1,cluster2);
                dlogLikelihood -= ( FUNC(Npji,a , Nmji,b) - FUNC(0,a,0,b) );
                dlogLikelihood += ( FUNC(Npii+Npjj+Npij+Npji,a , Nmii+Nmjj+Nmij+Nmji,b) - FUNC(0,a,0,b) );
            }
            else
            {
                dlogLikelihood += ( FUNC(Npii+Npjj+Npij,a , Nmii+Nmjj+Nmij,b) - FUNC(0,a,0,b) );
            }

        }
        return dlogPrior+dlogLikelihood;
    }
}




void IrmPoisson_multigraph::moveItem_clustering(size_t itemId, size_t clusterId)
{
/*
   Clustering& clustering_ = clusteringData;

    for(int netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.links;
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;


        size_t currentCluster = clustering_.getClusterId(itemId);
        size_t max = links.max;

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

        //remove node from sufficient statistics
        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] -= nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] -= nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                //if(c!=currentCluster)
                {
                    links.matrix[c*links.max+currentCluster]-=nodecounts.nodeLinks_transposed[c];
                    links.matrix[currentCluster*links.max+c]-=nodeLinks[c];

                    nonlinks.matrix[c*links.max+currentCluster]-=nodecounts.nodeNonLinks_transposed[c];
                    nonlinks.matrix[currentCluster*links.max+c]-=nodeNonLinks[c];

                    if(usemissing_)
                    {
                        missinglinks.matrix[c*missinglinks.max+currentCluster]-=nodecounts.nodeMissingLinks_transposed[c];
                        missinglinks.matrix[currentCluster*missinglinks.max+c]-=nodeMissingLinks[c];
                    }
                }
            }


        }

        //move node
        currentCluster = clusterId;

        //insert node in sufficient statistics

        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] += nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] += nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster]+=nodecounts.nodeLinks_transposed[c];
                links.matrix[currentCluster*links.max+c]+=nodeLinks[c];

                nonlinks.matrix[c*links.max+currentCluster]+=nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[currentCluster*links.max+c]+=nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+currentCluster]+=nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[currentCluster*missinglinks.max+c]+=nodeMissingLinks[c];
                }
            }

        }

    }

    //move the node in the datastructure
    clustering_.moveItem(itemId,clusterId);
    */
}


void IrmPoisson_multigraph::moveItem_newCluster_clustering(size_t itemId)
{
/*
    Clustering& clustering_ = clusteringData;

    //obtain new clusterId and move node
    size_t oldClusterId = clustering_.getClusterId(itemId);
    clustering_.removeItem(itemId);
    size_t newClusterId = clustering_.addItem(itemId);


    for(int netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.links;
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;

        //resize sufficient statistics if necessary
        if(newClusterId>=links.max)
        {
            size_t newMaxClusters = std::max(newClusterId+1,links.max*2);
            links.setNewMax(newMaxClusters);
            nonlinks.setNewMax(newMaxClusters);
            missinglinks.setNewMax(newMaxClusters);
        }

        size_t max = links.max;
        size_t currentCluster = clustering_.getClusterId(itemId);

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;


        if(!directed)
        {
            //remove node from sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodeNonLinks[c];
                if(c!=oldClusterId)
                {
                    links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+oldClusterId] -= nodeMissingLinks[c];
                    if(c!=oldClusterId)
                    {
                        missinglinks.matrix[oldClusterId*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }

            //add node to sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+newClusterId] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodeNonLinks[c];
                if(c!=newClusterId)
                {
                    links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+newClusterId] += nodeMissingLinks[c];
                    if(c!=newClusterId)
                    {
                        missinglinks.matrix[newClusterId*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {

            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodecounts.nodeLinks_transposed[c];
                links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];

                links.matrix[c*links.max+newClusterId] += nodecounts.nodeLinks_transposed[c];
                links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+oldClusterId] -= nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[oldClusterId*missinglinks.max+c] -= nodeMissingLinks[c];
                    missinglinks.matrix[c*missinglinks.max+newClusterId] += nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[newClusterId*missinglinks.max+c] += nodeMissingLinks[c];
                }
            }

        }

    }
    */
}

void IrmPoisson_multigraph::mergeClusters_clustering(size_t clusterId1,size_t clusterId2)
{


    Clustering& clustering_ = clusteringData;

    //move nodes
    Clustering::clusterIterator iter;
    for(iter = clustering_.begin(clusterId2) ; clustering_.exist(clusterId2) && iter!=clustering_.end(clusterId2) ; ++iter)
    {
        clustering_.moveItem(*iter,clusterId1);
    }

    for(int netID = 0 ; netID < networks.size(); netID++)
    {
        //SquareMatrix<size_t>& links = data[netID].sufstats.links;
        //SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        //SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;

        SufficientStatistics& sf = data[netID].sufstats;

        SquareMatrix<size_t>& linkSum = sf.linkSum;
        SquareMatrix<size_t>& nodePairs = sf.nodePairs;
        SquareMatrix<size_t>& missingNodePairs = sf.missingNodePairs;

        //update sufstats
        if(!directed)
        {
            //merge clusters
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                linkSum.matrix[clusterId1*linkSum.max+iter.index()] += linkSum.matrix[clusterId2*linkSum.max+iter.index()];
                linkSum.matrix[iter.index()*linkSum.max+clusterId1] = linkSum.matrix[clusterId1*linkSum.max+iter.index()];

                nodePairs.matrix[clusterId1*nodePairs.max+iter.index()] += nodePairs.matrix[clusterId2*nodePairs.max+iter.index()];
                nodePairs.matrix[iter.index()*nodePairs.max+clusterId1] = nodePairs.matrix[clusterId1*nodePairs.max+iter.index()];
            }
            linkSum.matrix[clusterId1*linkSum.max+clusterId1] += linkSum.matrix[clusterId2*linkSum.max+clusterId2];
            nodePairs.matrix[clusterId1*nodePairs.max+clusterId1] += nodePairs.matrix[clusterId2*nodePairs.max+clusterId2];

            if(usemissing_)
            {
                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    missingNodePairs.matrix[clusterId1*missingNodePairs.max+iter.index()] += missingNodePairs.matrix[clusterId2*missingNodePairs.max+iter.index()];
                    missingNodePairs.matrix[iter.index()*missingNodePairs.max+clusterId1] = missingNodePairs.matrix[clusterId1*missingNodePairs.max+iter.index()];
                }
                missingNodePairs.matrix[clusterId1*missingNodePairs.max+clusterId1] += missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId2];
            }

            //set empty row and column to zeros
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();
                linkSum.matrix[clusterId2*linkSum.max+c] = 0;
                linkSum.matrix[c*linkSum.max+clusterId2] = 0;
                nodePairs.matrix[clusterId2*nodePairs.max+c] = 0;
                nodePairs.matrix[c*nodePairs.max+clusterId2] = 0;
                if(usemissing_)
                {
                    missingNodePairs.matrix[clusterId2*missingNodePairs.max+c] = 0;
                    missingNodePairs.matrix[c*missingNodePairs.max+clusterId2] = 0;
                }

            }
            //null selflinks
            linkSum.matrix[clusterId2*linkSum.max+clusterId2] = 0;
            nodePairs.matrix[clusterId2*nodePairs.max+clusterId2] = 0;
            if(usemissing_)
            {
                missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId2] = 0;
            }

        }
        else // directed
        {
            size_t selflinks = linkSum.matrix[clusterId1*linkSum.max+clusterId1]
                             + linkSum.matrix[clusterId2*linkSum.max+clusterId2]
                             + linkSum.matrix[clusterId2*linkSum.max+clusterId1]
                             + linkSum.matrix[clusterId1*linkSum.max+clusterId2];

            size_t selfnonlinks = nodePairs.matrix[clusterId1*nodePairs.max+clusterId1]
                                + nodePairs.matrix[clusterId2*nodePairs.max+clusterId2]
                                + nodePairs.matrix[clusterId2*nodePairs.max+clusterId1]
                                + nodePairs.matrix[clusterId1*nodePairs.max+clusterId2];

            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();

                //from c to c1 and c2
                linkSum.matrix[clusterId1*linkSum.max+c] += linkSum.matrix[clusterId2*linkSum.max+c];
                linkSum.matrix[c*linkSum.max+clusterId1] += linkSum.matrix[c*linkSum.max+clusterId2];
                linkSum.matrix[clusterId2*linkSum.max+c] = 0;
                linkSum.matrix[c*linkSum.max+clusterId2] = 0;

                nodePairs.matrix[clusterId1*nodePairs.max+c] += nodePairs.matrix[clusterId2*nodePairs.max+c];
                nodePairs.matrix[c*nodePairs.max+clusterId1] += nodePairs.matrix[c*nodePairs.max+clusterId2];
                nodePairs.matrix[clusterId2*nodePairs.max+c] = 0;
                nodePairs.matrix[c*nodePairs.max+clusterId2] = 0;
            }
            linkSum.matrix[clusterId1*linkSum.max+clusterId1] = selflinks;
            linkSum.matrix[clusterId2*linkSum.max+clusterId1] = 0;
            linkSum.matrix[clusterId1*linkSum.max+clusterId2] = 0;

            nodePairs.matrix[clusterId1*nodePairs.max+clusterId1] = selfnonlinks;
            nodePairs.matrix[clusterId2*nodePairs.max+clusterId1] = 0;
            nodePairs.matrix[clusterId1*nodePairs.max+clusterId2] = 0;

            if(usemissing_)
            {
                size_t selfmissinglinks = missingNodePairs.matrix[clusterId1*missingNodePairs.max+clusterId1]
                            + missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId2]
                            + missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId1]
                            + missingNodePairs.matrix[clusterId1*missingNodePairs.max+clusterId2];

                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    size_t c = iter.index();

                    //from c to c1 and c2
                    missingNodePairs.matrix[clusterId1*missingNodePairs.max+c] += missingNodePairs.matrix[clusterId2*missingNodePairs.max+c];
                    missingNodePairs.matrix[c*missingNodePairs.max+clusterId1] += missingNodePairs.matrix[c*missingNodePairs.max+clusterId2];
                    missingNodePairs.matrix[clusterId2*missingNodePairs.max+c] = 0;
                    missingNodePairs.matrix[c*missingNodePairs.max+clusterId2] = 0;
                }
                missingNodePairs.matrix[clusterId1*missingNodePairs.max+clusterId1] = selfmissinglinks;
                missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId1] = 0;
                missingNodePairs.matrix[clusterId1*missingNodePairs.max+clusterId2] = 0;
            }

            //null selflinks
            linkSum.matrix[clusterId2*linkSum.max+clusterId2] = 0;
            nodePairs.matrix[clusterId2*nodePairs.max+clusterId2] = 0;
            if(usemissing_)
            {
                missingNodePairs.matrix[clusterId2*missingNodePairs.max+clusterId2] = 0;
            }

        }
    }

};



Clustering* IrmPoisson_multigraph::getDataPointer_clustering()
{
    Clustering& clustering_ = clusteringData;
    return &clustering_;
};

size_t IrmPoisson_multigraph::getNumberOfItems_clustering()
{
    return networks[0].getNumberOfNodes();
}

ClusteringDocument IrmPoisson_multigraph::get_clustering()
{
    Clustering& clustering_ = clusteringData;
    return ClusteringDocument(clustering_);
};

void IrmPoisson_multigraph::set_clustering(ClusteringDocument& cd)
{
    Clustering clustering(cd.clusteringVector);
    clusteringData = clustering;
    computeAllSufficientStatistics();
};



//alpha functions
double IrmPoisson_multigraph::get_alpha()
{
    double& alpha_ = param.alpha_;
    return alpha_;
}
void IrmPoisson_multigraph::set_alpha(double val)
{
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    alpha_ = val;
    logalpha_ = log(val);
}
double IrmPoisson_multigraph::logPosteriorRatio_alpha(double new_alpha)
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    if (new_alpha <= 0) return -9999999999999999;
    int noc = clustering_.getNumberOfClusters();
    int J = networks[0].getNumberOfNodes();
    double logp = noc * log(new_alpha) + lgamma(new_alpha) - lgamma(J+new_alpha) - log(new_alpha);
    logp -= noc * logalpha_ + lgamma(alpha_) - lgamma(J+alpha_) - logalpha_;
    return logp;
}

//bp functions
double IrmPoisson_multigraph::get_a()
{
    double& a_ = param.a_;
    return a_;
}

void IrmPoisson_multigraph::set_a(double val)
{
    double& a_ = param.a_;
    a_ = val;
}

double IrmPoisson_multigraph::logPosteriorRatio_a(double new_a)
{
    if (new_a <= 0) return -9999999999999999;
    double old_a = a.get();
    double L0 = computeLogLikelihood();
    a.set(new_a);
    double L1 = computeLogLikelihood();
    a.set(old_a);
    return L1-L0;
}

//bm functions
double IrmPoisson_multigraph::get_b()
{
    double& b_ = param.b_;
    return b_;
}

void IrmPoisson_multigraph::set_b(double val)
{
    double& b_ = param.b_;
    b_ = val;
}

double IrmPoisson_multigraph::logPosteriorRatio_b(double new_b)
{
    double& b_ = param.b_;

    if (new_b <= 0) return -9999999999999999;
    double old_b = b.get();
    double L0 = computeLogLikelihood();
    b.set(new_b);
    double L1 = computeLogLikelihood();
    b.set(old_b);
    return L1-L0;
}



/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmPoisson_multigraph::logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    Clustering& clustering_ = clusteringData;

    double dp = 0;
    if(cluster != currentCluster)
    {
        dp = log(clustering_.getSize(cluster));
    }
    else
    {
        if(currentClusterSize>1)
            dp = log(currentClusterSize-1);
    }
    return dp;
}


/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmPoisson_multigraph::logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    const double alpha_ = param.alpha_;
    return log(alpha_);
}


/**
*** compute the effective change for the log_likelihood when moving node nodeId from currentCluster to a new cluster
**/
double IrmPoisson_multigraph::logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_poisson& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{

    double& alpha_ = param.alpha_;
    double& a = param.a_;
    double& b = param.b_;

    SquareMatrix<size_t>& nodePairs = data_.sufstats.nodePairs;
    SquareMatrix<size_t>& linkSum = data_.sufstats.linkSum;
    SquareMatrix<size_t>& missingNodePairs = data_.sufstats.missingNodePairs;

    std::vector<size_t>& nodeNodePairs = nodecounts.nodePairs;
    std::vector<size_t>& nodeLinkSum= nodecounts.linkSum;
    std::vector<size_t>& nodeMissingNodePairs= nodecounts.missingNodePairs;

    std::vector<size_t>& nodeNodePairs_t = nodecounts.nodePairs_reversed;
    std::vector<size_t>& nodeLinkSum_t = nodecounts.linkSum_reversed;
    std::vector<size_t>& nodeMissingNodePairs_t = nodecounts.missingNodePairs_reversed;


    if(!directed)
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();
            if( l !=  currentCluster)
            {
                double val = 0;
                val += FUNC( nodeLinkSum[l], a, nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                val -= FUNC( 0, a, 0 , b);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    loglik += FUNC( nodeLinkSum[l],a , nodeNodePairs[l] - nodeMissingNodePairs[l], b);
                    loglik -= FUNC( 0, a , 0, b);
                }
            }
        }
        return loglik;
    }
    else // directed
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();
            if( l != currentCluster)
            {
                double val = 0;
                val += FUNC( nodeLinkSum[l], a, nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                val -= FUNC( 0, a, 0 , b);
                val += FUNC( nodeLinkSum_t[l], a, nodeNodePairs_t[l] - nodeMissingNodePairs_t[l] , b);
                val -= FUNC( 0, a, 0 , b);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    double val = 0;
                    val += FUNC( nodeLinkSum[l], a, nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                    val -= FUNC( 0, a, 0 , b);
                    val += FUNC( nodeLinkSum_t[l], a, nodeNodePairs_t[l] - nodeMissingNodePairs_t[l] , b);
                    val -= FUNC( 0, a, 0 , b);
                    loglik += val;
                }
            }

        }
        return loglik;
    }

}




/**
*** compute the change in log_loglikelihood when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmPoisson_multigraph::logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_poisson& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts)
{

    double& alpha_ = param.alpha_;
    double& a = param.a_;
    double& b = param.b_;

    SquareMatrix<size_t>& nodePairs = data_.sufstats.nodePairs;
    SquareMatrix<size_t>& linkSum = data_.sufstats.linkSum;
    SquareMatrix<size_t>& missingNodePairs = data_.sufstats.missingNodePairs;

    std::vector<size_t>& nodeNodePairs = nodecounts.nodePairs;
    std::vector<size_t>& nodeLinkSum= nodecounts.linkSum;
    std::vector<size_t>& nodeMissingNodePairs= nodecounts.missingNodePairs;

    std::vector<size_t>& nodeNodePairs_t = nodecounts.nodePairs_reversed;
    std::vector<size_t>& nodeLinkSum_t = nodecounts.linkSum_reversed;
    std::vector<size_t>& nodeMissingNodePairs_t = nodecounts.missingNodePairs_reversed;


    if(!directed)
    {
        double sum = 0;
        if(cluster != currentCluster)
        {
            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                if(l!=currentCluster)
                {
                    const double ls = linkSum.get(cluster,l);
                    const double np = nodePairs.get(cluster,l) - missingNodePairs.get(cluster,l);
                    sum += FUNC(ls + nodeLinkSum[l], a, np + nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                    sum -= FUNC(ls, a, np , b);
                }
                else
                {
                    if(currentClusterSize>1)
                    {
                        const double ls = linkSum.get(cluster,l) - nodeLinkSum[cluster];
                        const double np = nodePairs.get(cluster,l) - nodeNodePairs[cluster] - ( missingNodePairs.get(cluster,l) - nodeMissingNodePairs[cluster] );
                        sum += FUNC(ls + nodeLinkSum[l], a , np + nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                        sum -= FUNC(ls, a, np , b);
                    }
                }
            }
        }
        else
        {
            if(currentClusterSize>1)
            {
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {
                    size_t l = iter.index();
                    const double ls = linkSum.get(cluster,l) - nodeLinkSum[l];
                    const double np = nodePairs.get(cluster,l) - nodeNodePairs[l] - ( missingNodePairs.get(cluster,l) - nodeMissingNodePairs[l]  );
                    sum += FUNC(ls + nodeLinkSum[l], a, np + nodeNodePairs[l] - nodeMissingNodePairs[l] , b);
                    sum -= FUNC(ls , a, np, b);
                }
            }
            else
            {
                //node is alone in cluster
            }
        }
        return sum;
    }

    else //if directed DIRECTED
    {

        const size_t c = cluster;

        if(c!=currentCluster)
        {
            double d_loglikelihood = 0;

            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                const size_t n_nl = nodeLinkSum[l];             //linksum from node to cluster l
                const size_t N_nl = nodeNodePairs[l];           //nodepairs from node to cluster l
                const size_t mN_nl = nodeMissingNodePairs[l];       //missingnodepairs from node to cluster l

                const double n_ln = nodeLinkSum_t[l];             //linksum from cluster l to node
                const double N_ln = nodeNodePairs_t[l];
                const double mN_ln = nodeMissingNodePairs_t[l];




                if(l!=currentCluster )
                {
                    const double n_lc = linkSum.get(l,c);               //linksum from cluster l to cluster c
                    const double N_lc = nodePairs.get(l,c);             //nodepairs from cluster l to cluster c
                    const double mN_lc = missingNodePairs.get(l,c);

                    const double n_cl = linkSum.get(c,l);          //links from cluster c to cluster l
                    const double N_cl = nodePairs.get(c,l);
                    const double mN_cl = missingNodePairs.get(c,l);

                    if(l!=c)
                    {

                        d_loglikelihood += FUNC( n_cl + n_nl, a, N_cl + N_nl - (mN_cl + mN_nl) , b );
                        d_loglikelihood -= FUNC( n_cl, a , N_cl - mN_cl, b );

                        d_loglikelihood += FUNC( n_lc + n_ln, a, N_lc + N_ln - (mN_lc + mN_ln), b );
                        d_loglikelihood -= FUNC( n_lc, a , N_lc - mN_lc, b);
                    }
                    else // l == c
                    {
                        d_loglikelihood += FUNC( n_cl + n_nl + n_ln, a, N_cl + N_nl + N_ln - (mN_cl + mN_nl + mN_ln), b );
                        d_loglikelihood -= FUNC( n_cl, a , N_cl - mN_cl, b );
                    }

                }
                else //l==currentCluster
                {

                    const double n_nc = nodeLinkSum[c];               //links from node to cluster c
                    const double N_nc = nodeNodePairs[c];
                    const double mN_nc = nodeMissingNodePairs[c];

                    const double n_cn = nodeLinkSum_t[c];
                    const double N_cn = nodeNodePairs_t[c];
                    const double mN_cn = nodeMissingNodePairs_t[c];

                    if(l!=c) // l = q
                    {
                        const double n_cl = linkSum.get(c,l) - n_cn;          //links from cluster c to cluster l
                        const double N_cl = nodePairs.get(c,l) - N_cn;
                        const double mN_cl = missingNodePairs.get(c,l) - mN_cn;

                        const double n_lc = linkSum.get(l,c) - n_nc;          //links from cluster l to cluster c
                        const double N_lc = nodePairs.get(l,c) - N_nc;
                        const double mN_lc = missingNodePairs.get(l,c) - mN_nc;

                        d_loglikelihood += FUNC( n_cl + n_nl, a, N_cl + N_nl - (mN_cl + mN_nl), b );
                        d_loglikelihood -= FUNC( n_cl, a , N_cl - mN_cl, b );

                        d_loglikelihood += FUNC( n_lc + n_ln, a, N_lc + N_ln - (mN_lc + mN_ln), b );
                        d_loglikelihood -= FUNC( n_lc, a , N_lc - mN_lc, b);

                        //std::cout << d_loglikelihood<<std::endl;
                        //reportError("err",1);
                    }
                    else // l == c == currentcluster
                    {

                        const double n_ll = linkSum.get(c,l) - n_nl - n_ln;
                        const double N_ll = nodePairs.get(c,l) - N_nl - N_ln;
                        const double mN_ll = missingNodePairs.get(c,l) - nodeMissingNodePairs[l] - nodeMissingNodePairs_t[l];

                        d_loglikelihood += betaln_table.betaln( linkSum.get(c,l) , a , nodePairs.get(c,l) - missingNodePairs.get(c,l) , b);
                        d_loglikelihood -= betaln_table.betaln( n_ll , a , N_ll - mN_ll, b);

                    }

                }


            }
            return d_loglikelihood;
        }
        else //c==currentCluster
        {
            if(currentClusterSize>1)
            {
                double d_loglikelihood = 0;
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {
                    size_t l = iter.index();

                    const size_t n_nl = nodeLinkSum[l];               //links from node to cluster l
                    const size_t N_nl = nodeNodePairs[l];
                    const double mN_nl = nodeMissingNodePairs[l];

                    const double n_ln = nodeLinkSum_t[l];             //links from cluster l to node
                    const double N_ln = nodeNodePairs_t[l];
                    const double mN_ln = nodeMissingNodePairs_t[l];

                    const double n_nc = nodeLinkSum[c];               //links from node to cluster c
                    const double N_nc = nodeNodePairs[c];
                    const double mN_nc = nodeMissingNodePairs[c];

                    const double n_cn = nodeLinkSum_t[c];             //links from cluster c to node
                    const double N_cn = nodeNodePairs_t[c];
                    const double mN_cn = nodeMissingNodePairs_t[c];

                    if(l!=c)
                    {
                        d_loglikelihood += FUNC( linkSum.get(c,l), a, nodePairs.get(c,l) - missingNodePairs.get(c,l), b);
                        d_loglikelihood -= FUNC( linkSum.get(c,l) - nodeLinkSum[l] , a, nodePairs.get(c,l)- nodeNodePairs[l] - (missingNodePairs.get(c,l) - nodeMissingNodePairs[l]) , b );

                        d_loglikelihood += FUNC( linkSum.get(l,c), a, nodePairs.get(l,c) - missingNodePairs.get(l,c), b);
                        d_loglikelihood -= FUNC( linkSum.get(l,c) - nodeLinkSum_t[l] , a, nodePairs.get(l,c)- nodeNodePairs_t[l] - (missingNodePairs.get(l,c) - nodeMissingNodePairs_t[l]) , b );
                    }
                    else // l == c == currentcluster
                    {
                        const double n_ll = linkSum.get(c,l) - n_nl - n_ln;
                        const double N_ll = nodePairs.get(c,l) - N_nl - N_ln;
                        const double mN_ll = missingNodePairs.get(c,l) - nodeMissingNodePairs[l] - nodeMissingNodePairs_t[l];

                        d_loglikelihood += FUNC( linkSum.get(c,l) , a , nodePairs.get(c,l)-missingNodePairs.get(c,l) , b);
                        d_loglikelihood -= FUNC( n_ll , a , N_ll - mN_ll, b);


                        //std::cout << " nll:" << n_ll << "  Nll "<<N_ll << std::endl;

                    }
                }
                return d_loglikelihood;

            }
            else
            {
                return 0;
            }
        }
    }

}
