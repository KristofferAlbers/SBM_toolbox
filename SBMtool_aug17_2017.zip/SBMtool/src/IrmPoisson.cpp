/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "IrmPoisson.h"

const std::string IrmPoisson::MODELNAME = "IrmPoisson";

const ModelDescription IrmPoisson::modelDescription("IrmPois","infinite, unipartite","irm model with poisson likelihood and gamma prior");

const std::vector<SettingDescription> IrmPoisson::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("directed","BOOL",false).initialBool(false).shortDescription("Indicate if network is directed").longDescription("Define whether the network is directed (true) or undirected (false)")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items","INT",true).min(1).max(1000000).shortDescription("Number of nodes in the network").longDescription("The number of nodes in the network")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("a.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of a")   },
    {   SettingDescription("b.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of b")   },
    {   SettingDescription("alpha.init","FLOAT",false).initialFloat(1.0).shortDescription("Intitial value of alpha") },
    {   SettingDescription("clustering.init_crp","FLOAT",false).initialFloat(1).min(0).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes, according to CRP").longDescription("Concentration parameter of the generating CRP")  },
    {   SettingDescription("clustering.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes").longDescription("Initial number of components, the nodes are randomny split into")    }
};

const std::vector<ParameterDescription> IrmPoisson::parameterDescriptions
{
    {   ParameterDescription("clustering","INFINITE_CLUSTERING").shortDescription("clustering parameter").longDescription("")    },
    {   ParameterDescription("alpha","REAL").shortDescription("concentration parameter").longDescription("")    },
    {   ParameterDescription("a","REAL").shortDescription("a hyperparameter").longDescription("")    },
    {   ParameterDescription("b","REAL").shortDescription("b hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, IrmPoisson> IrmPoisson::Create(IrmPoisson::MODELNAME);


void IrmPoisson::getNodeCounts(size_t nodeId, Data& data_, Clustering& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts)
{

    nodecounts.nodePair.clear();
    nodecounts.nodePair.resize(max);

    nodecounts.linkSum.clear();
    nodecounts.linkSum.resize(max);

    nodecounts.missingNodePair.clear();
    nodecounts.missingNodePair.resize(max);


    if(directed)
    {
        nodecounts.nodePair_transposed.resize(max);
        nodecounts.nodePair_transposed.clear();
        nodecounts.linkSum_transposed.resize(max);
        nodecounts.linkSum_transposed.clear();
        nodecounts.missingNodePair_transposed.resize(max);
        nodecounts.missingNodePair_transposed.clear();

        for(size_t c = 0 ; c< max; c++)
        {
            if(clustering_.exist(c))
            {
                nodecounts.nodePair[c] = numSubjects*clustering_.getSize(c);
                nodecounts.nodePair_transposed[c] = numSubjects*clustering_.getSize(c);
            }

        }
        nodecounts.nodePair[currentCluster]-= numSubjects;
        nodecounts.nodePair_transposed[currentCluster]-= numSubjects;

        for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.linkSum[clusterId]+=value;
        }

        for(NetworkData<size_t>::iterator iter = data_.data_transposed.begin(nodeId) ; iter!=data_.data_transposed.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.linkSum_transposed[clusterId]+=value;
        }
    }
    else
    {
        for(size_t c = 0 ; c < max; c++)
        {
            if(clustering_.exist(c))
                nodecounts.nodePair[c] = numSubjects*clustering_.getSize(c);
        }
        nodecounts.nodePair[currentCluster]-= numSubjects;

        for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t value = iter.getValue();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.linkSum[clusterId]+=value;
        }


    }

    if(usemissing_)
    {
        for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.missingNodePair[clusterId]+=iter.getValue();
        }
        if(directed)
        {
            for(NetworkData<size_t>::iterator iter = data_.missing_transposed.begin(nodeId) ; iter!=data_.missing_transposed.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.missingNodePair_transposed[clusterId]+=iter.getValue();
            }
        }
    }

}




double IrmPoisson::computeLogLikelihood()
{
    double likelihood = 0;
    for(size_t netID = 0 ;netID < networks.size(); netID++)
    {
        likelihood += computeLogLikelihood(data[netID],clusteringData);
    }
    return likelihood;
}

double IrmPoisson::computeLogLikelihood(Data& data_, Clustering& clustering_)
{
    UnipartiteNetwork<size_t>& network = data_.network;

    double a = param.a_;
    double b = param.b_;

    double factsum = 0;

    for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
    {
        if(!clustering_.assigned(sourceNode))
        {
            continue;
        }

        for(typename NetworkData<size_t>::iterator iter = network.data.begin(sourceNode); iter!=network.data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();

            if(!directed && (sourceNode>targetNode) )
            {
                continue;
            }

            size_t value = iter.getValue();
            double factval = factln_table.logfactorial(value);
            factsum += factval;
        }
    }

    factsum = -factsum; //(log(1) - factsum)

    double clustsum = 0;

    for( Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer )
    {
        size_t clusterIdFrom = citer.index();

        for( Clustering::iterator iter2 = clustering_.begin() ; iter2!=clustering_.end() ; iter2++ )
        {
            size_t clusterIdTo = iter2.index();


            if(!directed && (clusterIdFrom>clusterIdTo) )
            {
                continue;
            }

            clustsum += ( a*log( b ) ) - ( gammaln_table.gammaln(0, a  )  );
            clustsum += ( gammaln_table.gammaln(data_.sufstats.getLinkSum(clusterIdFrom, clusterIdTo) , a ))  - (  ( data_.sufstats.getLinkSum(clusterIdFrom, clusterIdTo) + a ) * log( data_.sufstats.getNodePairs(clusterIdFrom,clusterIdTo) - data_.sufstats.getMissingNodePairs(clusterIdFrom,clusterIdTo) + b )  );
        }
    }
    //std::cout << " loglikelihood: " << clustsum << " + " << factsum << std::endl;
    //std::cout << params[masterThread].clustering_ << std::endl;
    //std::cout << "factsum = " << factsum << " clustsum = " << clustsum << std::endl;
    return clustsum + factsum;
}

double IrmPoisson::computeLogPrior()
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;


    const size_t noc = clustering_.getNumberOfClusters();
    const size_t J = clustering_.getNumberOfItems();

    double logprior = noc * logalpha_;
    logprior += lgamma(alpha_);
    logprior -= lgamma(J+alpha_);

    for(Clustering::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
    {
        logprior += lgamma(clustering_.getSize(iter.index()));
    }
    //logprior -= logalpha_;
    return logprior * networks.size();
}

double IrmPoisson::computeLogPosterior()
{
    return computeLogPrior()+computeLogLikelihood();
}








partial_vector<double> IrmPoisson::effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters)
{
    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.nodePairs.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    NodeCounts<size_t> nodecounts;

    partial_vector<double> logps;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];

        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        for(std::vector<size_t>::iterator itouter = restrictedClusters.begin() ; itouter!=restrictedClusters.end() ; ++itouter)
        {
            size_t cluster = *itouter;
            double dlikelihood  = 0;
            double dprior = 0;

            if(!clustering_.exist(cluster) || (cluster == currentCluster && currentClusterSize == 1) )
            {
                dlikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data_,clustering_,param,currentCluster,currentClusterSize,nodecounts);
                dprior = logPrior_effectiveChange_newCluster(nodeId,currentCluster,currentClusterSize,nodecounts);
            }
            else
            {
                dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
                dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);
            }
            if(logps.exist(cluster))
            {
               logps[cluster] += dprior+dlikelihood;
            }
            else
            {
                logps.set(cluster,dprior+dlikelihood);
            }
        }
    }
    return logps;
}



double IrmPoisson::effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster,bool emptyCluster)
{
    std::vector<Data>& dataVector = *data_pointer;
    NodeCounts<size_t> nodecounts;
    double loglike = 0;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data = dataVector[netID];
        Clustering& clustering_ = clusteringData;
        size_t max = data.sufstats.nodePairs.max;
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,dataVector[netID], clustering_, currentCluster,max,nodecounts);

        if(!emptyCluster)
        {
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            loglike += dlikelihood;
        }
        else
        {
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data,clustering_,param,currentCluster,currentClusterSize,nodecounts);

            loglike+=loglikelihood;
        }
    }
    return loglike;
}




partial_vector<double> IrmPoisson::effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster)
{
    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.nodePairs.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];
        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        //existing clusters
        Clustering::iterator outerIter;
        for(outerIter = begin ; outerIter!=end; ++outerIter)
        {
            size_t cluster = outerIter.index();
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }
        }
        //new cluster
        if(appendForNewCluster)
        {
            double logprior = logPrior_effectiveChange_newCluster(nodeId,currentCluster,currentClusterSize,nodecounts);
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data_,clustering_,param,currentCluster,currentClusterSize,nodecounts);
            if(logps.exist(max))
            {
               logps[max] += logprior+loglikelihood;
            }
            else
            {
                logps.set(max,logprior+loglikelihood);
            }
        }

    }
    return logps;
}




double IrmPoisson::effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2)
{

    Clustering& clustering_ = clusteringData;
    double& logalpha_ = param.logalpha_;
    double& a_ = param.a_;
    double& b_ = param.b_;

    if(cluster1 == cluster2)
    {
        return 0;
    }
    else
    {
        //compute change in prior
        double dlogPrior = 0;
        dlogPrior -= clustering_.getNumberOfClusters()  * logalpha_;
        dlogPrior += (clustering_.getNumberOfClusters()-1 ) * logalpha_;
        dlogPrior -= lgamma(clustering_.getSize(cluster1));
        dlogPrior -= lgamma(clustering_.getSize(cluster2));
        dlogPrior += lgamma(clustering_.getSize(cluster1) + clustering_.getSize(cluster2) );

        dlogPrior = dlogPrior*networks.size();

        //add change in likelihood
        double dlogLikelihood = 0;
        for(size_t netID = 0; netID<networks.size(); netID++)
        {
            SufficientStatistics& sufstats = data[netID].sufstats;
            for(Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer)
            {
                const size_t clusterId = citer.index();
                if(clusterId == cluster1 || clusterId == cluster2)
                {
                    continue;
                }
                else
                {
                    const size_t Npci = sufstats.getLinkSum(clusterId,cluster1);
                    const size_t Nmci = sufstats.getNodePairs(clusterId,cluster1) - sufstats.getMissingNodePairs(clusterId,cluster1);
                    const size_t Npcj = sufstats.getLinkSum(clusterId,cluster2);
                    const size_t Nmcj = sufstats.getNodePairs(clusterId,cluster2) - sufstats.getMissingNodePairs(clusterId,cluster2);

                    dlogLikelihood -= ( FUNC(Npci,a_ , Nmci,b_) - FUNC(0,a_,0,b_) );
                    dlogLikelihood -= ( FUNC(Npcj,a_ , Nmcj,b_) - FUNC(0,a_,0,b_) );
                    dlogLikelihood += ( FUNC(Npci+Npcj,a_ , Nmci+Nmcj, b_) - FUNC(0,a_,0,b_));

                    if(directed)
                    {
                        const size_t Npci = sufstats.getLinkSum(cluster1,clusterId);
                        const size_t Nmci = sufstats.getNodePairs(cluster1,clusterId) - sufstats.getMissingNodePairs(cluster1,clusterId);
                        const size_t Npcj = sufstats.getLinkSum(cluster2,clusterId);
                        const size_t Nmcj = sufstats.getNodePairs(cluster2,clusterId) - sufstats.getMissingNodePairs(cluster2,clusterId);

                        dlogLikelihood -= ( FUNC(Npci,a_ , Nmci,b_) - FUNC(0,a_,0,b_) );
                        dlogLikelihood -= ( FUNC(Npcj,a_ , Nmcj,b_) - FUNC(0,a_,0,b_) );
                        dlogLikelihood += ( FUNC(Npci+Npcj,a_ , Nmci+Nmcj, b_) - FUNC(0,a_,0,b_));
                    }
                }
            }
            if(!directed)
            {
                const size_t Npii = sufstats.getLinkSum(cluster1,cluster1);
                const size_t Nmii = sufstats.getNodePairs(cluster1,cluster1) - sufstats.getMissingNodePairs(cluster1,cluster1);
                const size_t Npjj = sufstats.getLinkSum(cluster2,cluster2);
                const size_t Nmjj = sufstats.getNodePairs(cluster2,cluster2) - sufstats.getMissingNodePairs(cluster2,cluster2);
                const size_t Npij = sufstats.getLinkSum(cluster1,cluster2);
                const size_t Nmij = sufstats.getNodePairs(cluster1,cluster2) - sufstats.getMissingNodePairs(cluster1,cluster2);

                dlogLikelihood -= ( FUNC(Npii,a_ , Nmii,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood -= ( FUNC(Npjj,a_, Nmjj,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood -= ( FUNC(Npij,a_ , Nmij,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood += ( FUNC(Npii+Npjj+Npij,a_ , Nmii+Nmjj+Nmij,b_) - FUNC(0,a_,0,b_) );
            }
            else
            {
                const size_t Npii = sufstats.getLinkSum(cluster1,cluster1);
                const size_t Nmii = sufstats.getNodePairs(cluster1,cluster1) - sufstats.getMissingNodePairs(cluster1,cluster1);
                const size_t Npjj = sufstats.getLinkSum(cluster2,cluster2);
                const size_t Nmjj = sufstats.getNodePairs(cluster2,cluster2) - sufstats.getMissingNodePairs(cluster2,cluster2);
                const size_t Npij = sufstats.getLinkSum(cluster1,cluster2);
                const size_t Nmij = sufstats.getNodePairs(cluster1,cluster2) - sufstats.getMissingNodePairs(cluster1,cluster2);
                const size_t Npji = sufstats.getLinkSum(cluster2,cluster1);
                const size_t Nmji = sufstats.getNodePairs(cluster2,cluster1) - sufstats.getMissingNodePairs(cluster2,cluster1);


                dlogLikelihood -= ( FUNC(Npii,a_ , Nmii,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood -= ( FUNC(Npjj,a_, Nmjj,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood -= ( FUNC(Npij,a_ , Nmij,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood -= ( FUNC(Npji,a_ , Nmji,b_) - FUNC(0,a_,0,b_) );
                dlogLikelihood += ( FUNC(Npii+Npjj+Npij+Npji,a_ , Nmii+Nmjj+Nmij+Nmji,b_) - FUNC(0,a_,0,b_) );
            }
        }
//        std::cout << " merge dlogprior = " << dlogPrior << "  dloglike = " << dlogLikelihood << std::endl;
        return dlogPrior+dlogLikelihood;
    }
}

void IrmPoisson::computeAllSufficientStatistics()
{
    for(size_t i = 0; i < data.size(); i++)
    {
        computeSufficientStatistics(data[i],clusteringData);
    }
}



void IrmPoisson::computeSufficientStatistics(Data& data_,Clustering& clustering_)
{
    data_.sufstats.withmissing = usemissing_;
    data_.sufstats.directed = directed;

    NetworkData<size_t>& network = data_.network.data;
    NetworkData<size_t>& missing = data_.network.missing;

    SquareMatrix<size_t>& nodePairs = data_.sufstats.nodePairs;
    SquareMatrix<size_t>& linkSum = data_.sufstats.linkSum;
    SquareMatrix<size_t>& missingNodePairs = data_.sufstats.missingNodePairs;

    nodePairs.clear();
    linkSum.clear();
    missingNodePairs.clear();

    size_t newMaxClusters = std::max(clustering_.getNumberOfClusters()*2,(size_t)20);

    data_.sufstats.setNewMax(newMaxClusters);

    //compute link sums
    for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
    {
        if(!clustering_.assigned(sourceNode))
        {
            continue;
        }

        size_t sourceCluster = clustering_.getClusterId(sourceNode);

        if(sourceCluster>=nodePairs.max)
        {
            size_t newMaxClusters = std::max(sourceCluster+1,nodePairs.max*2);
            nodePairs.setNewMax(newMaxClusters);
            linkSum.setNewMax(newMaxClusters);
            missingNodePairs.setNewMax(newMaxClusters);
        }
        for(typename NetworkData<size_t>::iterator iter = network.begin(sourceNode); iter!=network.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();


            if(!clustering_.assigned(targetNode))
            {
                continue;
            }

            size_t weight = iter.getValue();

            //std::cout << sourceNode << " has link to " << targetNode << " with weight " << weight << std::endl;

            size_t targetCluster = clustering_.getClusterId(targetNode);

            if(targetCluster>=nodePairs.max)
            {
                size_t newMaxClusters = std::max(targetCluster+1,nodePairs.max*2);
                data_.sufstats.setNewMax(newMaxClusters);
            }
            linkSum.matrix[sourceCluster*linkSum.max+targetCluster] += weight;
        }
    }

    if(!directed)
    {
        for(size_t i = 0 ; i < linkSum.max; i++)
        {
            linkSum.matrix[i*linkSum.max+i]/=2;
        }
    }

    for( Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer )
    {
        size_t clusterIdFrom = citer.index();

        for( Clustering::iterator iter2 = clustering_.begin() ; iter2!=clustering_.end() ; iter2++ )
        {
            size_t clusterIdTo = iter2.index();
            if(clusterIdFrom == clusterIdTo)
            {
                //within
                size_t nodesInCluster = clustering_.getSize(clusterIdTo);
                size_t pairs;
                if(!directed)
                {
                    pairs = (nodesInCluster)* (nodesInCluster - 1) *.5;
                }
                else
                {
                    pairs = (nodesInCluster)* (nodesInCluster - 1);
                }
                nodePairs.matrix[clusterIdFrom*nodePairs.max+clusterIdTo] = pairs;
            }
            else
            {
                //between
                size_t nodesInClusterFrom = clustering_.getSize(clusterIdFrom);
                size_t nodesInClusterTo = clustering_.getSize(clusterIdTo);
                size_t pairs = nodesInClusterFrom*nodesInClusterTo;
                nodePairs.matrix[clusterIdFrom*nodePairs.max+clusterIdTo] = pairs;
            }
        }
    }


    //compute missing links
    if(usemissing_)
    {
        for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
        {

            if(!clustering_.assigned(sourceNode))
            {
                continue;
            }

            size_t sourceCluster = clustering_.getClusterId(sourceNode);

            for(typename NetworkData<size_t>::iterator iter = missing.begin(sourceNode); iter!=missing.end(sourceNode) ; iter++)
            {
                size_t targetNode = iter.getTarget();

                if(!clustering_.assigned(targetNode))
                {
                    continue;
                }


                size_t targetCluster = clustering_.getClusterId(targetNode);
                missingNodePairs.matrix[sourceCluster*missingNodePairs.max+targetCluster] += 1;
            }
        }
        if(!directed)
        {
            for(size_t i = 0 ; i < missingNodePairs.max; i++)
            {
                missingNodePairs.matrix[i*missingNodePairs.max+i]/=2;
            }
        }
    }

}


void IrmPoisson::moveItem_clustering(size_t itemId, size_t clusterId)
{

   Clustering& clustering_ = clusteringData;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.nodePairs;           //nodePairs, linkSum, missingNodePairs
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.linkSum;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missingNodePairs;


        size_t currentCluster = clustering_.getClusterId(itemId);
        size_t max = links.max;

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);

        std::vector<size_t>& nodeLinks = nodecounts.nodePair;              //nodePairs, linkSum, missingNodePairs
        std::vector<size_t>& nodeNonLinks = nodecounts.linkSum;
        std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePair;

        std::vector<size_t>& nodeLinks_t = nodecounts.nodePair_transposed;              //nodePairs, linkSum, missingNodePairs
        std::vector<size_t>& nodeNonLinks_t = nodecounts.linkSum_transposed;
        std::vector<size_t>& nodeMissingLinks_t = nodecounts.missingNodePair_transposed;

        //remove node from sufficient statistics
        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] -= nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] -= nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                //if(c!=currentCluster)
                {
                    links.matrix[c*links.max+currentCluster]-=nodeLinks_t[c];
                    links.matrix[currentCluster*links.max+c]-=nodeLinks[c];

                    nonlinks.matrix[c*links.max+currentCluster]-=nodeNonLinks_t[c];
                    nonlinks.matrix[currentCluster*links.max+c]-=nodeNonLinks[c];

                    if(usemissing_)
                    {
                        missinglinks.matrix[c*missinglinks.max+currentCluster]-=nodeMissingLinks_t[c];
                        missinglinks.matrix[currentCluster*missinglinks.max+c]-=nodeMissingLinks[c];
                    }
                }
            }


        }

        //move node
        currentCluster = clusterId;

        //insert node in sufficient statistics

        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] += nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] += nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster]+=nodeLinks_t[c];
                links.matrix[currentCluster*links.max+c]+=nodeLinks[c];

                nonlinks.matrix[c*links.max+currentCluster]+=nodeNonLinks_t[c];
                nonlinks.matrix[currentCluster*links.max+c]+=nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+currentCluster]+=nodeMissingLinks_t[c];
                    missinglinks.matrix[currentCluster*missinglinks.max+c]+=nodeMissingLinks[c];
                }
            }

        }

    }

    //move the node in the datastructure
    clustering_.moveItem(itemId,clusterId);
}


void IrmPoisson::moveItem_newCluster_clustering(size_t itemId)
{

    Clustering& clustering_ = clusteringData;

    //obtain new clusterId and move node
    size_t oldClusterId = clustering_.getClusterId(itemId);
    clustering_.removeItem(itemId);
    size_t newClusterId = clustering_.addItem(itemId);


    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.nodePairs;               //nodePairs, linkSum, missingNodePairs
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.linkSum;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missingNodePairs;

        //resize sufficient statistics if necessary
        if(newClusterId>=links.max)
        {
            size_t newMaxClusters = std::max(newClusterId+1,links.max*2);
            links.setNewMax(newMaxClusters);
            nonlinks.setNewMax(newMaxClusters);
            missinglinks.setNewMax(newMaxClusters);
        }

        size_t max = links.max;
        size_t currentCluster = clustering_.getClusterId(itemId);

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);

        std::vector<size_t>& nodeLinks = nodecounts.nodePair;              //nodePairs, linkSum, missingNodePairs
        std::vector<size_t>& nodeNonLinks = nodecounts.linkSum;
        std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePair;

        std::vector<size_t>& nodeLinks_t = nodecounts.nodePair_transposed;              //nodePairs, linkSum, missingNodePairs
        std::vector<size_t>& nodeNonLinks_t = nodecounts.linkSum_transposed;
        std::vector<size_t>& nodeMissingLinks_t = nodecounts.missingNodePair_transposed;



        if(!directed)
        {
            //remove node from sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodeNonLinks[c];
                if(c!=oldClusterId)
                {
                    links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+oldClusterId] -= nodeMissingLinks[c];
                    if(c!=oldClusterId)
                    {
                        missinglinks.matrix[oldClusterId*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }

            //add node to sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+newClusterId] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodeNonLinks[c];
                if(c!=newClusterId)
                {
                    links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+newClusterId] += nodeMissingLinks[c];
                    if(c!=newClusterId)
                    {
                        missinglinks.matrix[newClusterId*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {

            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodeLinks_t[c];
                links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodeNonLinks_t[c];
                nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];

                links.matrix[c*links.max+newClusterId] += nodeLinks_t[c];
                links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodeNonLinks_t[c];
                nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+oldClusterId] -= nodeMissingLinks_t[c];
                    missinglinks.matrix[oldClusterId*missinglinks.max+c] -= nodeMissingLinks[c];
                    missinglinks.matrix[c*missinglinks.max+newClusterId] += nodeMissingLinks_t[c];
                    missinglinks.matrix[newClusterId*missinglinks.max+c] += nodeMissingLinks[c];
                }
            }

        }

    }
}

void IrmPoisson::mergeClusters_clustering(size_t clusterId1,size_t clusterId2)
{

    Clustering& clustering_ = clusteringData;

    //move nodes
    Clustering::clusterIterator iter;
    for(iter = clustering_.begin(clusterId2) ; clustering_.exist(clusterId2) && iter!=clustering_.end(clusterId2) ; ++iter)
    {
        clustering_.moveItem(*iter,clusterId1);
    }

    for(size_t netID = 0 ; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.nodePairs;           //nodePairs, linkSum, missingNodePairs
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.linkSum;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missingNodePairs;


        //update sufstats
        if(!directed)
        {
            //merge clusters
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                links.matrix[clusterId1*links.max+iter.index()] += links.matrix[clusterId2*links.max+iter.index()];
                links.matrix[iter.index()*links.max+clusterId1] = links.matrix[clusterId1*links.max+iter.index()];

                nonlinks.matrix[clusterId1*nonlinks.max+iter.index()] += nonlinks.matrix[clusterId2*nonlinks.max+iter.index()];
                nonlinks.matrix[iter.index()*nonlinks.max+clusterId1] = nonlinks.matrix[clusterId1*nonlinks.max+iter.index()];
            }
            links.matrix[clusterId1*links.max+clusterId1] += links.matrix[clusterId2*links.max+clusterId2];
            nonlinks.matrix[clusterId1*nonlinks.max+clusterId1] += nonlinks.matrix[clusterId2*nonlinks.max+clusterId2];

            if(usemissing_)
            {
                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    missinglinks.matrix[clusterId1*links.max+iter.index()] += missinglinks.matrix[clusterId2*links.max+iter.index()];
                    missinglinks.matrix[iter.index()*links.max+clusterId1] = missinglinks.matrix[clusterId1*links.max+iter.index()];
                }
                missinglinks.matrix[clusterId1*links.max+clusterId1] += missinglinks.matrix[clusterId2*links.max+clusterId2];
            }

            //set empty row and column to zeros
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();
                links.matrix[clusterId2*links.max+c] = 0;
                links.matrix[c*links.max+clusterId2] = 0;
                nonlinks.matrix[clusterId2*links.max+c] = 0;
                nonlinks.matrix[c*links.max+clusterId2] = 0;
                if(usemissing_)
                {
                    missinglinks.matrix[clusterId2*links.max+c] = 0;
                    missinglinks.matrix[c*links.max+clusterId2] = 0;
                }
            }
            links.matrix[clusterId2*links.max+clusterId2] = 0;
            nonlinks.matrix[clusterId2*links.max+clusterId2] = 0;
            if(usemissing_)
            {
                missinglinks.matrix[clusterId2*links.max+clusterId2] = 0;
            }


        }
        else // directed
        {
            size_t selflinks = links.matrix[clusterId1*links.max+clusterId1]
                             + links.matrix[clusterId2*links.max+clusterId2]
                             + links.matrix[clusterId2*links.max+clusterId1]
                             + links.matrix[clusterId1*links.max+clusterId2];

            size_t selfnonlinks = nonlinks.matrix[clusterId1*nonlinks.max+clusterId1]
                                + nonlinks.matrix[clusterId2*nonlinks.max+clusterId2]
                                + nonlinks.matrix[clusterId2*nonlinks.max+clusterId1]
                                + nonlinks.matrix[clusterId1*nonlinks.max+clusterId2];

            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();

                //from c to c1 and c2
                links.matrix[clusterId1*links.max+c] += links.matrix[clusterId2*links.max+c];
                links.matrix[c*links.max+clusterId1] += links.matrix[c*links.max+clusterId2];
                links.matrix[clusterId2*links.max+c] = 0;
                links.matrix[c*links.max+clusterId2] = 0;

                nonlinks.matrix[clusterId1*nonlinks.max+c] += nonlinks.matrix[clusterId2*nonlinks.max+c];
                nonlinks.matrix[c*nonlinks.max+clusterId1] += nonlinks.matrix[c*nonlinks.max+clusterId2];
                nonlinks.matrix[clusterId2*nonlinks.max+c] = 0;
                nonlinks.matrix[c*nonlinks.max+clusterId2] = 0;
            }
            links.matrix[clusterId1*links.max+clusterId1] = selflinks;
            links.matrix[clusterId2*links.max+clusterId1] = 0;
            links.matrix[clusterId1*links.max+clusterId2] = 0;

            nonlinks.matrix[clusterId1*nonlinks.max+clusterId1] = selfnonlinks;
            nonlinks.matrix[clusterId2*nonlinks.max+clusterId1] = 0;
            nonlinks.matrix[clusterId1*nonlinks.max+clusterId2] = 0;

            if(usemissing_)
            {
                size_t selfmissinglinks = missinglinks.matrix[clusterId1*missinglinks.max+clusterId1]
                            + missinglinks.matrix[clusterId2*missinglinks.max+clusterId2]
                            + missinglinks.matrix[clusterId2*missinglinks.max+clusterId1]
                            + missinglinks.matrix[clusterId1*missinglinks.max+clusterId2];

                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    size_t c = iter.index();

                    //from c to c1 and c2
                    missinglinks.matrix[clusterId1*missinglinks.max+c] += missinglinks.matrix[clusterId2*missinglinks.max+c];
                    missinglinks.matrix[c*missinglinks.max+clusterId1] += missinglinks.matrix[c*missinglinks.max+clusterId2];
                    missinglinks.matrix[clusterId2*missinglinks.max+c] = 0;
                    missinglinks.matrix[c*missinglinks.max+clusterId2] = 0;
                }
                missinglinks.matrix[clusterId1*missinglinks.max+clusterId1] = selfmissinglinks;
                missinglinks.matrix[clusterId2*missinglinks.max+clusterId1] = 0;
                missinglinks.matrix[clusterId1*missinglinks.max+clusterId2] = 0;
            }

        }
    }
};



Clustering* IrmPoisson::getDataPointer_clustering()
{
    Clustering& clustering_ = clusteringData;
    return &clustering_;
};

size_t IrmPoisson::getNumberOfItems_clustering()
{
    return networks[0].getNumberOfNodes();
}

ClusteringDocument IrmPoisson::get_clustering()
{
    Clustering& clustering_ = clusteringData;
    ClusteringDocument cd( clustering_.getNumberOfClusters(), clustering_);
    return cd;
};

void IrmPoisson::set_clustering(ClusteringDocument& cd)
{
    Clustering clustering(cd.clusteringVector);
    clusteringData = clustering;
    computeAllSufficientStatistics();
};

void IrmPoisson::setFromString_clustering(std::string s)
{
    ClusteringDocument cd(s);
    set_clustering(cd);
};



//alpha functions
double IrmPoisson::get_alpha()
{
    double& alpha_ = param.alpha_;
    return alpha_;
}
void IrmPoisson::set_alpha(double val)
{
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    alpha_ = val;
    logalpha_ = log(val);
}
double IrmPoisson::logPosteriorRatio_alpha(double new_alpha)
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    if (new_alpha <= 0) return -9999999999999999;
    int noc = clustering_.getNumberOfClusters();
    int J = networks[0].getNumberOfNodes();
    double logp = noc * log(new_alpha) + lgamma(new_alpha) - lgamma(J+new_alpha) - log(new_alpha);
    logp -= noc * logalpha_ + lgamma(alpha_) - lgamma(J+alpha_) - logalpha_;
    return logp;
}

//a functions
double IrmPoisson::get_a()
{
    double& a_ = param.a_;
    return a_;
}

void IrmPoisson::set_a(double val)
{
    double& a_ = param.a_;
    a_ = val;
}

double IrmPoisson::logPosteriorRatio_a(double new_a)
{
    if (new_a <= 0) return -9999999999999999;
    double old_a = a.get();
    double L0 = computeLogLikelihood();
    a.set(new_a);
    double L1 = computeLogLikelihood();
    a.set(old_a);
    return L1-L0;
}

//b functions
double IrmPoisson::get_b()
{
    double& b_ = param.b_;
    return b_;
}

void IrmPoisson::set_b(double val)
{
    double& b_ = param.b_;
    b_ = val;
}

double IrmPoisson::logPosteriorRatio_b(double new_b)
{
    if (new_b <= 0) return -9999999999999999;
    double old_b = b.get();
    double L0 = computeLogLikelihood();
    b.set(new_b);
    double L1 = computeLogLikelihood();
    b.set(old_b);
    return L1-L0;
}



/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmPoisson::logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    Clustering& clustering_ = clusteringData;

    double dp = 0;
    if(cluster != currentCluster)
    {
        dp = log(clustering_.getSize(cluster));
    }
    else
    {
        if(currentClusterSize>1)
            dp = log(currentClusterSize-1);
    }
    return dp;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmPoisson::logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    const double alpha_ = param.alpha_;
    return log(alpha_);
}



/**
*** compute the effective change for the log_likelihood when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmPoisson::logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    double& a = param.a_;
    double& b = param.b_;

    std::vector<size_t>& nodeLinks = nodecounts.linkSum;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodePair;
    std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePair;

    std::vector<size_t>& nodeLinks_t = nodecounts.linkSum_transposed;
    std::vector<size_t>& nodeNonLinks_t = nodecounts.nodePair_transposed;
    std::vector<size_t>& nodeMissingLinks_t = nodecounts.missingNodePair_transposed;


    if(!directed)
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();

            if( l !=  currentCluster)
            {
                double val = 0;
                val += FUNC( nodeLinks[l], a, nodeNonLinks[l] - nodeMissingLinks[l] , b);
                val -= FUNC( 0, a, 0, b);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    loglik += FUNC( nodeLinks[l],a , nodeNonLinks[l] - nodeMissingLinks[l] ,b );
                    loglik -= FUNC( 0, a , 0 , b );
                }
            }
        }

        return loglik;
    }
    else // directed
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();
            if( l != currentCluster)
            {
                double val = 0;
                val += FUNC( nodeLinks[l], a, nodeNonLinks[l] - nodeMissingLinks[l] , b);
                val -= FUNC( 0, a, 0, b);
                val += FUNC( nodeLinks_t[l], a, nodeNonLinks_t[l] - nodeMissingLinks_t[l] , b);
                val -= FUNC( 0, a, 0, b);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    double val = 0;
                    val += FUNC( nodeLinks[l], a, nodeNonLinks[l] - nodeMissingLinks[l] , b);
                    val -= FUNC( 0, a, 0, b);
                    val += FUNC( nodeLinks_t[l], a, nodeNonLinks_t[l] - nodeMissingLinks_t[l] , b);
                    val -= FUNC( 0, a, 0, b);
                    loglik += val;
                }
            }

        }
        return loglik;
    }


}




/**
*** compute the change in log_loglikelihood when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmPoisson::logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts)
{

    double& a = param.a_;
    double& b = param.b_;

    SufficientStatistics& sf = data_.sufstats;


    std::vector<size_t>& nodeLinks = nodecounts.linkSum;              //nodePairs, linkSum, missingNodePairs
    std::vector<size_t>& nodeNonLinks = nodecounts.nodePair;
    std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePair;
    std::vector<size_t>& nodeLinks_t = nodecounts.linkSum_transposed;              //nodePairs, linkSum, missingNodePairs
    std::vector<size_t>& nodeNonLinks_t = nodecounts.nodePair_transposed;
    std::vector<size_t>& nodeMissingLinks_t = nodecounts.missingNodePair_transposed;

    std::vector<size_t>& nodeSums = nodecounts.linkSum;
    std::vector<size_t>& nodePair = nodecounts.nodePair;
    std::vector<size_t>& nodeMissingPairs = nodecounts.missingNodePair;
    std::vector<size_t>& nodeSums_t = nodecounts.linkSum_transposed;
    std::vector<size_t>& nodePair_t = nodecounts.nodePair_transposed;
    std::vector<size_t>& nodeMissingPairs_t = nodecounts.missingNodePair_transposed;




    if(!directed)
    {
        double sum = 0;
        if(cluster != currentCluster)
        {
            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                if(l!=currentCluster)
                {
                    const double linksum = sf.getLinkSum(cluster,l);
                    const double nodepairs = sf.getNodePairs(cluster,l) - sf.getMissingNodePairs(cluster,l);
                    sum += FUNC(linksum + nodeSums[l], a, nodepairs + nodePair[l] - nodeMissingPairs[l] , b);
                    sum -= FUNC(linksum, a, nodepairs , b);

                    //const double linkcount = sf.getLinkSum(cluster,l);
                    //const double nonlinkcount = sf.getNonLinkCount(cluster,l) - sf.getMissingLinkCount(cluster,l);
                    //sum += betaln_table.betaln( linkcount + nodeLinks[l], a , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                    //sum -= betaln_table.betaln( linkcount , a , nonlinkcount , bm_ );
                }
                else
                {
                    if(currentClusterSize>1)
                    {

                        const double l_size = clustering_.getSize(l);
                        const double c_size = clustering_.getSize(cluster);

                        const double linksum = sf.getLinkSum(cluster,l) - nodeSums[cluster];
                        const double nodepairs = sf.getNodePairs(cluster,l) - nodePair[cluster] - ( sf.getMissingNodePairs(cluster,l) - nodeMissingPairs[cluster] );

                        sum += FUNC(linksum + nodeSums[l], a , nodepairs + nodePair[l] - nodeMissingPairs[l] , b);
                        sum -= FUNC(linksum, a, nodepairs , b);

                        //const double linkcount = sf.getLinkCount(cluster,l) - nodeLinks[cluster];
                        //const double nonlinkcount = sf.getNonLinkCount(cluster,l) - nodeNonLinks[cluster] - ( sf.getMissingLinkCount(cluster,l) - nodeMissingLinks[cluster] );
                        //sum += betaln_table.betaln( linkcount + nodeLinks[l] , a , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                        //sum -= betaln_table.betaln( linkcount, a , nonlinkcount , bm_ );
                    }
                }
            }
        }
        else
        {
            if(currentClusterSize>1)
            {
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {

                    size_t l = iter.index();
                    const double linksum = sf.getLinkSum(cluster,l) - nodeSums[l];
                    const double nodepairs = sf.getNodePairs(cluster,l) - nodePair[l] - ( sf.getMissingNodePairs(cluster,l) - nodeMissingPairs[l]  );

                    sum += FUNC(linksum + nodeSums[l], a, nodepairs + nodePair[l] - nodeMissingPairs[l] , b);
                    sum -= FUNC(linksum, a, nodepairs, b);

                    //size_t l = iter.index();
                    //const double linkcount = sf.getLinkCount(cluster,l) - nodeLinks[l];
                    //const double nonlinkcount = sf.getNonLinkCount(cluster,l) - nodeNonLinks[l] - ( sf.getMissingLinkCount(cluster,l) - nodeMissingLinks[l] );
                    //sum += betaln_table.betaln( linkcount + nodeLinks[l], a, nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                    //sum -= betaln_table.betaln( linkcount, a, nonlinkcount, bm_ );
                }
            }
            else
            {
                //node is alone in cluster
            }
        }
        return sum;
    }
    else//if directed
    {

        const size_t c = cluster;

        if(c!=currentCluster)
        {
            double d_loglikelihood = 0;

            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                const size_t r_nl = nodeLinks[l];               //links from node to cluster l
                const size_t rn_nl = nodeNonLinks[l];
                const size_t rm_nl = nodeMissingLinks[l];
                const double r_ln = nodeLinks_t[l];             //links from cluster l to node
                const double rn_ln = nodeNonLinks_t[l];
                const double rm_ln = nodeMissingLinks_t[l];

                if(l!=currentCluster )
                {

                    const double m_lc = sf.getLinkSum(l,c);          //links from cluster l to cluster c
                    const double mn_lc = sf.getNodePairs(l,c);
                    const double mm_lc = sf.getMissingNodePairs(l,c);
                    const double m_cl = sf.getLinkSum(c,l);          //links from cluster c to cluster l
                    const double mn_cl = sf.getNodePairs(c,l);
                    const double mm_cl = sf.getMissingNodePairs(c,l);

                    //const double m_lc = sf.getLinkCount(l,c);          //links from cluster l to cluster c
                    //const double mn_lc = sf.getNonLinkCount(l,c);
                    //const double mm_lc = sf.getMissingLinkCount(l,c);
                    //const double m_cl = sf.getLinkCount(c,l);          //links from cluster c to cluster l
                    //const double mn_cl = sf.getNonLinkCount(c,l);
                    //const double mm_cl = sf.getMissingLinkCount(c,l);

                    if(l!=c)
                    {
                        //std::cout << ":::(1) (v): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;
                        d_loglikelihood += FUNC( m_cl + r_nl, a, mn_cl + rn_nl - (mm_cl + rm_nl) , b );
                        d_loglikelihood -= FUNC( m_cl, a , mn_cl - mm_cl, b );

                        d_loglikelihood += FUNC( m_lc + r_ln, a, mn_lc + rn_ln - (mm_lc + rm_ln), b );
                        d_loglikelihood -= FUNC( m_lc, a , mn_lc - mm_lc, b);
                    }
                    else // l == c
                    {
                        //std::cout << ":::(2) (v): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;
                        d_loglikelihood += FUNC( m_cl + r_nl + r_ln, a, mn_cl + rn_nl + rn_ln - (mm_cl + rm_nl + rm_ln), b );
                        d_loglikelihood -= FUNC( m_cl, a , mn_cl - mm_cl, b );
                    }

                }
                else //l==currentCluster
                {
                    const double r_nc = nodeLinks[c];               //links from node to cluster c
                    const double rn_nc = nodeNonLinks[c];
                    const double rm_nc = nodeMissingLinks[c];

                    const double r_cn = nodeLinks_t[c];             //links from cluster c to node
                    const double rn_cn = nodeNonLinks_t[c];
                    const double rm_cn = nodeMissingLinks_t[c];

                    if(l!=c) // l = q
                    {
                        //std::cout << ":::(3)(v2): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;

                        const double m_cl = sf.getLinkSum(c,l) - r_cn;          //links from cluster c to cluster l
                        const double mn_cl = sf.getNodePairs(c,l) - rn_cn;
                        const double mm_cl = sf.getMissingNodePairs(c,l) - rm_cn;
                        const double m_lc = sf.getLinkSum(l,c) - r_nc;          //links from cluster l to cluster c
                        const double mn_lc = sf.getNodePairs(l,c) - rn_nc;
                        const double mm_lc = sf.getMissingNodePairs(l,c) - rm_nc;

                        //const double m_cl = sf.getLinkCount(c,l) - r_cn;          //links from cluster c to cluster l
                        //const double mn_cl = sf.getNonLinkCount(c,l) - rn_cn;
                        //const double mm_cl = sf.getMissingLinkCount(c,l) - rm_cn;
                        //const double m_lc = sf.getLinkCount(l,c) - r_nc;          //links from cluster l to cluster c
                        //const double mn_lc = sf.getNonLinkCount(l,c) - rn_nc;
                        //const double mm_lc = sf.getMissingLinkCount(l,c) - rm_nc;

                        d_loglikelihood += FUNC( m_cl + r_nl, a, mn_cl + rn_nl - (mm_cl + rm_nl), b );
                        d_loglikelihood -= FUNC( m_cl, a , mn_cl - mm_cl, b );

                        d_loglikelihood += FUNC( m_lc + r_ln, a, mn_lc + rn_ln - (mm_lc + rm_ln), b );
                        d_loglikelihood -= FUNC( m_lc, a , mn_lc - mm_lc, b);
                    }
                    else // l == c == currentcluster
                    {
                        //std::cout << ":::(4) (v0): " << l << " , " << c << "  q = " << currentCluster << std::endl;

                        const double m_ll = sf.getLinkSum(c,l) - r_nl - r_ln;
                        const double mn_ll = sf.getNodePairs(c,l) - rn_nl - rn_ln;
                        const double mm_ll = sf.getMissingNodePairs(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        //const double m_ll = sf.getLinkCount(c,l) - r_nl - r_ln;
                        //const double mn_ll = sf.getNonLinkCount(c,l) - rn_nl - rn_ln;
                        //const double mm_ll = sf.getMissingLinkCount(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        d_loglikelihood += FUNC( sf.getLinkSum(c,l) , a , sf.getNodePairs(c,l) - sf.getMissingNodePairs(c,l) , b);
                        d_loglikelihood -= FUNC( m_ll , a , mn_ll - mm_ll, b);

                        //d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l) , a , sf.getNonLinkCount(c,l) - sf.getMissingLinkCount(c,l) , b);
                        //d_loglikelihood -= betaln_table.betaln( m_ll , a , mn_ll - mm_ll, b);

                    }

                }


            }
            return d_loglikelihood;
        }
        else //c==currentCluster
        {
            if(currentClusterSize>1)
            {
                double d_loglikelihood = 0;
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {
                    size_t l = iter.index();

                    const size_t r_nl = nodeLinks[l];               //links from node to cluster l
                    const size_t rn_nl = nodeNonLinks[l];
                    //const double rm_nl = nodeMissingLinks[l];

                    const double r_ln = nodeLinks_t[l];             //links from cluster l to node
                    const double rn_ln = nodeNonLinks_t[l];
                    //const double rm_ln = nodeMissingLinks_t[l];

                    //const double r_nc = nodeLinks[c];               //links from node to cluster c
                    //const double rn_nc = nodeNonLinks[c];
                    //const double rm_nc = nodeMissingLinks[c];

                    //const double r_cn = nodeLinks_t[c];             //links from cluster c to node
                    //const double rn_cn = nodeNonLinks_t[c];
                    //const double rm_cn = nodeMissingLinks_t[c];

                    if(l!=c)
                    {

                        d_loglikelihood += FUNC( sf.getLinkSum(c,l), a, sf.getNodePairs(c,l) - sf.getMissingNodePairs(c,l), b);
                        d_loglikelihood -= FUNC( sf.getLinkSum(c,l) - nodeLinks[l] , a, sf.getNodePairs(c,l)- nodeNonLinks[l] - (sf.getMissingNodePairs(c,l) - nodeMissingLinks[l]) , b );
                        d_loglikelihood += FUNC( sf.getLinkSum(l,c), a, sf.getNodePairs(l,c) - sf.getMissingNodePairs(l,c), b);
                        d_loglikelihood -= FUNC( sf.getLinkSum(l,c) - nodeLinks_t[l] , a, sf.getNodePairs(l,c)- nodeNonLinks_t[l] - (sf.getMissingNodePairs(l,c) - nodeMissingLinks_t[l]) , b );

                        //d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l), a, sf.getNonLinkCount(c,l) - sf.getMissingLinkCount(c,l), b);
                        //d_loglikelihood -= betaln_table.betaln( sf.getLinkCount(c,l) - nodeLinks[l] , a, sf.getNonLinkCount(c,l)- nodeNonLinks[l] - (sf.getMissingLinkCount(c,l) - nodeMissingLinks[l]) , b );
                        //d_loglikelihood += betaln_table.betaln( sf.getLinkCount(l,c), a, sf.getNonLinkCount(l,c) - sf.getMissingLinkCount(l,c), b);
                        //d_loglikelihood -= betaln_table.betaln( sf.getLinkCount(l,c) - nodeLinks_t[l] , a, sf.getNonLinkCount(l,c)- nodeNonLinks_t[l] - (sf.getMissingLinkCount(l,c) - nodeMissingLinks_t[l]) , b );
                    }
                    else // l == c == currentcluster
                    {
                        const double m_ll = sf.getLinkSum(c,l) - r_nl - r_ln;
                        const double mn_ll = sf.getNodePairs(c,l) - rn_nl - rn_ln;
                        const double mm_ll = sf.getMissingNodePairs(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        //const double m_ll = sf.getLinkCount(c,l) - r_nl - r_ln;
                        //const double mn_ll = sf.getNonLinkCount(c,l) - rn_nl - rn_ln;
                        //const double mm_ll = sf.getMissingLinkCount(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        d_loglikelihood += FUNC( sf.getLinkSum(c,l) , a , sf.getNodePairs(c,l)-sf.getMissingNodePairs(c,l) , b);
                        d_loglikelihood -= FUNC( m_ll , a , mn_ll - mm_ll, b);

                        //d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l) , a , sf.getNonLinkCount(c,l)-sf.getMissingLinkCount(c,l) , b);
                        //d_loglikelihood -= betaln_table.betaln( m_ll , a , mn_ll - mm_ll, b);


                    }
                }
                return d_loglikelihood;

            }
            else
            {
                return 0;
            }
        }
    }
    /**/
}


