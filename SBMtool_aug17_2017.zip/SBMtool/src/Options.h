/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This files defines the function and templates for describing and parsing user options
in the program.
Based on the input of a string ('name') and an Options object, these functions are
used to:
    - identify wheter the Obtions object contains an option named 'name'
    - parse the option 'name' from the user options into C++ primitives or a string
By utilizing the boost::make_recursive_variant library template, recursice options are allowed
*/

#ifndef OPTIONS_H_INCLUDED
#define OPTIONS_H_INCLUDED




#include <boost/variant.hpp>
#include <boost/algorithm/string.hpp>
#include <iostream>

#include <typeinfo>
#include <map>

class Parameter;  //expect class Parameter to be defined later


class subOption
{
public:
    std::string subName;
    std::string subValue;
    subOption(){}
    subOption(std::string name, std::string value)
    {
        subName = name; subValue = value;
    }
    std::string getName(){return subName;}
    std::string getString(){ return subValue;}
    int getInt() { return std::stoi(subValue);}
    double getDouble() { return std::stod(subValue);}
    bool getBool()
    {
        std::string line = subValue;
        boost::to_lower(line);
        bool boolval =  line == "true";
        return boolval;
    }
};


typedef boost::make_recursive_variant<bool, int, double, std::string, subOption, Parameter*,std::map<std::string,boost::recursive_variant_>>::type Option;
typedef std::map<std::string, Option> Options;


template <class T> bool hasOption(Options o,std::string s)
{
    if (o.find(s) != o.end())
    {
        return true;
    }
    else
    {
        return false;
    }
}


template <class T> T getOption(Options o, std::string s)
{
    if (o.find(s) != o.end())
    {
        T t;//the default value will not be necessary
        return getOption(o,s,t);
    }
    else
    {
        std::cout << "The option '" << s << "' is mandatory, but is not set!" << std::endl;
        exit(0);
    }
}


template <class T> T getOption(Options o, std::string s, T def)
{
    if (o.find(s) != o.end())
    {
        if(o[s].type() == typeid(T))
        {
            return boost::get<T>(o[s]);
        }
        else if(o[s].type() == typeid(std::string))
        {
            if(typeid(T)==typeid(bool))
            {
                std::string line = boost::get<std::string>(o[s]);
                boost::to_lower(line);
                bool boolval =  line == "true";
                T* tp = (T*)(&boolval);
                return *tp;
            }
            else if(typeid(T)==typeid(int))
            {
                int intval = std::stoi(boost::get<std::string>(o[s]));
                T* tp = (T*)(&intval);
                return *tp;
            }
            else if(typeid(T)==typeid(double))
            {
                double doubleval = (std::stod(boost::get<std::string>(o[s])) );
                T* tp = (T*)(&doubleval);
                return *tp;
            }
            else
            {
                //error
                std::cout << " error: parsing/reading option. Unknown type." << std::endl;
                exit(0);
            }
        }
        else
        {
            //error
            std::cout << " error: parsing/reading option" << std::endl;
            exit(0);
        }
    }
    else
    {
        return def;
    }
}



#endif // OPTIONS_H_INCLUDED
