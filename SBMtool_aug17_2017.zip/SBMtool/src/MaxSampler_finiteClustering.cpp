/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This code is provided as is without any warranty!

Implementation of the sampler for identifying MAP solution for
a finite clustering parameters. Defines the user settings/options and
implements the sample() function
*/



#include "Sampler.h"


#include <float.h>
#include <time.h>
#include <chrono>
#include <algorithm>
#include <iostream>



const std::string MaxSampler_finiteClustering::SAMPLERNAME = "MaxSampler_finiteClustering";

Creator<Max_sampler, MaxSampler_finiteClustering> MaxSampler_finiteClustering::Create(MaxSampler_finiteClustering::SAMPLERNAME);


const std::vector<SettingDescription> MaxSampler_finiteClustering::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The clustering parameter to sample") },
    {   SettingDescription("sweeps","INT",false).initialInt(2).min(1).shortDescription("Number of sweeps performed in sequence of the sampler")}
};


bool MaxSampler_finiteClustering::sample()
{

    int numthreads = 1;


    int items = parameter->getNumberOfItems();
    bool print = true;

    std::vector<size_t> selectedClusters(numthreads);
    std::vector<bool> requestChange(numthreads);

    numberOfChanges.clear();

    sweepsPerformed = 0;
    localOptimumReached = false;
    int changes = 0;

    for(size_t sweepnumber = 0; sweepnumber<sweeps; sweepnumber++)
    {

        size_t numNodes = items;
        int sequence[numNodes];
        //randomize the sequence nodes are sampled
        for (size_t n=0; n<numNodes; n++)
        {
            sequence[n] = n;
        }
        for (size_t n = 0; n < numNodes-1; n++)
        {
            int offset = rand()/(1+RAND_MAX/(numNodes-n));
            int val = sequence[n];
            sequence[n] = sequence[n+offset];
            sequence[n+offset] = val;
        }

        changes = 0;

        for(int sequenceIteration = 0; sequenceIteration<items; sequenceIteration++)
        {
        	int node = sequence[sequenceIteration];

            size_t currentClusterID = parameter->getDataPointer()->getClusterId(node);
            int currentClusterSize = parameter->getDataPointer()->getSize(currentClusterID);


            if( print && node%5000 == 0 ){
               // std::cout << "max posterior for node" << node << "   nocs = " << parameter->getDataPointer()->getNumberOfClusters() << "    efs:" << effectiveSweeps<< std::endl;
            }
            partial_vector<double> likelihoods = parameter->effectiveLogPosteriorRatio(node,parameter->getDataPointer()->begin(),parameter->getDataPointer()->end(),false);

            std::vector<int> ids;
            std::vector<double> vals;
            std::vector<double> probabilities;

            double maxlogP = -(DBL_MAX-1);
            int selectedCluster = -1;

            std::vector<size_t> maxpositions;

            for(partial_vector<double>::iterator it = likelihoods.begin(); it!=likelihoods.end(); ++it)
            {
                double val = *it;
                if(val>=maxlogP)
                {
                    if(it.index() == currentClusterID && currentClusterSize == 1)
                    {

                    }
                    else
                    {
                        if(val>maxlogP)
                        {
                            maxlogP = val;
                            maxpositions.clear();
                            maxpositions.push_back(it.index());
                            selectedCluster = it.index();
                        }
                        else
                        {
                            double randomval = ((double) rand() / (RAND_MAX));

                            if(randomval>0.5)
                            {
                                maxpositions.push_back(it.index());
                                selectedCluster = it.index();

                            }

                        }
                    }

                }

            }

            bool moveNode = false;

            if(selectedCluster != currentClusterID)
            {
                moveNode = true;
            }

            if(moveNode)
            {
                parameter->moveItem(node,selectedCluster);
                changes ++ ;

            }
        }


        if(changes == 0)
        {
            localOptimumReached = true;
            break;
        }
        numberOfChanges.push_back(changes);

        sweepsPerformed ++ ;


    }
/*
    FILE *effile;
    effile = fopen("effectivesweeps.txt", "a");
    fprintf(effile, "%i\n", effectiveSweeps);
    fclose(effile);
*/
    return localOptimumReached;
}
