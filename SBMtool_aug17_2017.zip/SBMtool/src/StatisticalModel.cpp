/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
Implementation of the statistical model base class
*/

#include "StatisticalModel.h"


std::string StatisticalModel::getName() const
{
    return name_;
}

/**
    obtain pointer to a given model parameter, if it exists (has previously been
    added to the model by the addParameter function)
*/
Parameter* StatisticalModel::getParameter(std::string parameterName)
{
    for(Parameter* p:parameters)
    {
        if(p->getName().compare(parameterName)==0)
        {
            return p;
        }
    }
    //reportError("unknown parameter: "+parameterName+" requested in StatisticalModel::getParameter",1);
    return nullptr;
}

void StatisticalModel::addParameter(Parameter* parameter)
{
        parameters.push_back(parameter);
}
