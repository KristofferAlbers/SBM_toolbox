/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
This code is provided as is without any warranty!

Implementation of the parameter base class.
By a StatisticalModel pointer, the parameter is added to the model when constructed.
*/

#ifndef PARAMETER_CPP_INCLUDED
#define PARAMETER_CPP_INCLUDED

#include "Parameter.h"

Parameter::Parameter(StatisticalModel* m, std::string n) : model_(m), name_(n), options_(m->getParameterOptions(n))
{
    m->addParameter(this);
}

std::string Parameter::getModelName()
{
    return model_->getName();
}
std::string Parameter::getName()
{
    return name_;
}
std::string Parameter::getType()
{
    return type_;
}
std::string Parameter::getDescription()
{
    return description_;
}

#endif // PARAMETER_CPP_INCLUDED
