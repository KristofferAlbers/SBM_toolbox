/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This code is provided as is without any warranty!

    This file contains simple utility functions
        - for manipulating vectors
        - obtaining random values
    ideally, these functions should be generilized in order to
    utilize standard matrix manipulation libraries.
*/

#ifndef FOUNDATION_H_INCLUDED
#define FOUNDATION_H_INCLUDED

#include <vector>

const int ORDER_RANDOM_UNIFORM = 1;
const int ORDER_DESCENDING = 2;
const int ORDER_ASCENDING = 3;

inline int randui(int from_including, int to_including){
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(from_including, to_including);
    return dis(gen);
}


template<class T,class V>
inline void sortVectorPair(std::vector<T>* v1,std::vector<V>* v2, int order){

      assert(v1->size() == v2->size());
      std::vector<T>& sources = *v1;
      std::vector<V>& targets = *v2;

      int comparisons = 0;
      switch ( order )
      {
         case ORDER_RANDOM_UNIFORM:
            for(int i = 0 ; i < sources.size() ; i++ )
            {
                int swappos = randui(0,i);
                std::swap( sources[i], sources[swappos] );
                std::swap( targets[i], targets[swappos] );
            }
            break;
         case ORDER_ASCENDING:
            for(int i=1; i<sources.size(); i++)
            {
                if(sources[i]< sources[i-1])
                {
                    int ii = i;
                    T s = sources[i];
                    V t = targets[i];
                    do
                    {
                        sources[ii] = sources[ii - 1];
                        targets[ii] = targets[ii - 1];
                        ii--;
                        comparisons++;
                    }
                    while(ii > 0 && sources[ii - 1] > s);
                    sources[ii] = s;
                    targets[ii] = t;
                }
            }
            break;
         case ORDER_DESCENDING:
            std::cout << "ORDER_DESCENDING not implemented" << std::endl;
            exit(0);
            break;
         default:
            break;
      }

}



#endif // FOUNDATION_H_INCLUDED
