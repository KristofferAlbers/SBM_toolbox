/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
Implementation of the Gibbs sampler for an infinite clustering parameter
Defines the user settings/options and implements the sample() function
*/


#include "Sampler.h"

#include <time.h>
#include <chrono>

#include <algorithm>
#include <iostream>

const std::string Gibbs_infiniteClustering::SAMPLERNAME = "Gibbs_infiniteClustering";

Creator<MCMC_sampler, Gibbs_infiniteClustering> Gibbs_infiniteClustering::Create(Gibbs_infiniteClustering::SAMPLERNAME);


const std::vector<SettingDescription> Gibbs_infiniteClustering::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The clustering parameter to sample") },
    {   SettingDescription("sweeps","INT",false).initialInt(1).min(1).shortDescription("Number of sweeps performed in sequence of the sampler")}
};


void Gibbs_infiniteClustering::sample()
{
    int items = parameter -> getNumberOfItems();
    int numthreads = 1;

    std::vector<Clustering::iterator> iterators(numthreads+1);
    std::vector<int> ids;
    std::vector<double> vals;
    std::vector<double> probabilities;

    size_t currentClusterID;
    int currentClusterSize;
    bool ignoreCurrentCluser;

    size_t numNodes = items;
    int sequence[numNodes];
    //randomize the sequence nodes are sampled
    for (size_t n=0; n<numNodes; n++)
    {
    	sequence[n] = n;
    }
    for (size_t n = 0; n < numNodes-1; n++)
    {
    	int offset = rand()/(1+RAND_MAX/(numNodes-n));
    	int val = sequence[n];
    	sequence[n] = sequence[n+offset];
    	sequence[n+offset] = val;
    }

    int movedItems = 0;

//omp_set_num_threads(numthreads); <--opemmp
    #pragma omp parallel
    {
//        int ID = omp_get_thread_num(); <--openmp
        int ID = 0;
        for(int sequenceIteration = 0; sequenceIteration<items; sequenceIteration++)
        {
        	int node = sequence[sequenceIteration];

            if(print && node%5000 == 0 )
            {
                std::cout << " gibbs for node " << node << " nocs = "<< parameter->getDataPointer()->getNumberOfClusters() << "  " << movedItems<<std::endl;
            }

            #pragma omp single
            {
                currentClusterID = parameter->getDataPointer()->getClusterId(node);
                currentClusterSize = parameter->getDataPointer()->getSize(currentClusterID);
                if(currentClusterSize == 1)
                {
                    ignoreCurrentCluser = true;
                }
                else
                {
                    ignoreCurrentCluser = false;
                }

                ids.clear();
                vals.clear();
                probabilities.clear();

                iterators[0] = parameter->getDataPointer()->begin();
                iterators[numthreads] = parameter->getDataPointer()->end();
                for(int p = 1 ; p < numthreads ; p++)
                {
                    iterators[p] = iterators[numthreads];
                }
                const int clustersPrThread = parameter->getDataPointer()->getNumberOfClusters() / numthreads;
                int i = 0;
                int curthread = 0;
                for(Clustering::iterator iter = iterators[0] ; iter!=iterators[numthreads] ; ++iter)
                {
                    i++;
                    if(i>clustersPrThread)
                    {
                        i=1;
                        curthread++;
                        iterators[curthread] = iter;
                        if(curthread == numthreads-1)
                        {
                            break;
                        }
                    }
                }

            }//end single, implicit barrier

            partial_vector<double> likelihoods = parameter->effectiveLogPosteriorRatio(node,iterators[ID],iterators[ID+1],ID==0);

            #pragma omp critical
            {
                if(ignoreCurrentCluser)
                {
                    for(partial_vector<double>::iterator piter = likelihoods.begin() ; piter != likelihoods.end(); ++piter)
                    {
                        if(piter.index() != currentClusterID)
                        {
                            ids.push_back(piter.index());
                            vals.push_back(*piter);
                        }
                    }
                }
                else
                {
                    for(partial_vector<double>::iterator piter = likelihoods.begin() ; piter != likelihoods.end(); ++piter)
                    {
                        ids.push_back(piter.index());
                        vals.push_back(*piter);
                    }
                }

            }//end critical

            #pragma omp barrier

            #pragma omp single
            {
//               sortVectorPair(&ids,&vals,ORDER_ASCENDING); //get deterministic behaviour (behaves similar to single threaded) <--openmp
                double maxlogP = *max_element(std::begin(vals), std::end(vals));
                double sumP = 0;
                for(auto it = vals.begin() ; it!=vals.end(); ++it)
                {
                    *it = exp(*it-maxlogP);
                    sumP+=*it;
                }

                probabilities.resize(vals.size());
                for(size_t i = 0 ; i< vals.size() ; i++)
                {
                    probabilities[i] = vals[i]/sumP;
                }
                std::vector<double> cumsum;
                cumsum.resize(vals.size());
                std::partial_sum(probabilities.begin(), probabilities.end(), cumsum.begin(), std::plus<double>());

                double randomval = ((double) rand() / (RAND_MAX));
                int chosenIndex = std::upper_bound(cumsum.begin(), cumsum.end(), randomval)-cumsum.begin();

                if(!(parameter->getDataPointer()->exist(ids[chosenIndex])))
                {
                    parameter->moveItem_newCluster(node);
                }
                else
                {
                    parameter->moveItem(node,ids[chosenIndex]);
                }

                if(ids[chosenIndex] != currentClusterID)
                {
                    movedItems++;
                }

            }//end single, implicit barrier

        }//end node loop

    }//end parallel section
}







std::vector<double> Gibbs_infiniteClustering::sample_restricted(size_t numberOfSweeps,std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds)
{
    return sample_(numberOfSweeps,nodeIds,clusterIds,nullptr);
}

std::vector<double> Gibbs_infiniteClustering::sample_restricted(size_t numberOfSweeps, std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds,std::vector<size_t>& forcedIntoFinalClusterIds){

    return sample_(numberOfSweeps,nodeIds,clusterIds,&forcedIntoFinalClusterIds);
}

//this function is only used to profile the gibbs sampler
std::vector<double> Gibbs_infiniteClustering::sample_(size_t numberOfSweeps,std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds, std::vector<size_t>* forcedIntoClusterIds)
{

    int T = numberOfSweeps;
    std::vector<double> sumOfLogProbabilitiesVector;
    sumOfLogProbabilitiesVector.reserve(numberOfSweeps);

//to measure sample time
//    std::chrono::high_resolution_clock::time_point time_beforeSampler = std::chrono::high_resolution_clock::now();
    for(int t = 0; t<T; t++)
    {
        double sumOfLogProbabilities = 0;
        for(size_t nodeIndex = 0; nodeIndex< nodeIds.size() ; nodeIndex++)
        {
//            std::chrono::high_resolution_clock::time_point time_before = std::chrono::high_resolution_clock::now();
            size_t node = nodeIds[nodeIndex];

            std::vector<int> ids;
            std::vector<double> vals;
            std::vector<double> dlogps;

            std::vector<double> probabilities;
            size_t forcedIntoClusterId = 0;
            size_t forcedIntoClusterIndex = 0;
            if(forcedIntoClusterIds!=nullptr)
            {
                forcedIntoClusterId = (*forcedIntoClusterIds)[nodeIndex];
            }
//            std::chrono::high_resolution_clock::time_point time_beforePost = std::chrono::high_resolution_clock::now();
            partial_vector<double> likelihoods = parameter->effectiveLogPosteriorRatio_restricted(node,clusterIds);
//            std::chrono::high_resolution_clock::time_point time_afterPost = std::chrono::high_resolution_clock::now();
//            std::chrono::duration<double> postTime = std::chrono::duration_cast<std::chrono::duration<double>>(time_afterPost - time_beforePost);
//            std::cout << "                   post time " << (double)postTime.count() << std::endl;

//            std::chrono::high_resolution_clock::time_point time_beforeRest = std::chrono::high_resolution_clock::now();
            for(partial_vector<double>::iterator it = likelihoods.begin(); it!=likelihoods.end(); ++it)
            {
                if(it.index()==forcedIntoClusterId)
                {
                    forcedIntoClusterIndex = ids.size();
                }
                ids.push_back(it.index());
                vals.push_back(*it);
                dlogps.push_back(*it);
            }

            double maxlogP = *max_element(std::begin(vals), std::end(vals));
            double sumP = 0;
            for(auto it = vals.begin() ; it!=vals.end(); ++it)
            {
                *it = exp(*it-maxlogP);
                sumP+=*it;
            }

            probabilities.resize(vals.size());
            for(size_t i = 0 ; i< vals.size() ; i++)
            {
                probabilities[i] = vals[i]/sumP;
            }

            if(forcedIntoClusterIds==nullptr || t<T-1 ){ //nodes are not forced
                std::vector<double> cumsum;
                cumsum.resize(vals.size());
                std::partial_sum(probabilities.begin(), probabilities.end(), cumsum.begin(), std::plus<double>());

                double randomval = uniform(generator);
                //double randomval = ((double) rand() / (RAND_MAX));
                int chosenIndex = std::upper_bound(cumsum.begin(), cumsum.end(), randomval)-cumsum.begin();

                parameter->moveItem(node,ids[chosenIndex]);

                double logProb = dlogps[chosenIndex]-maxlogP-log(sumP);
                sumOfLogProbabilities  = sumOfLogProbabilities +logProb;
            }
            else{ //force node into cluster
                parameter->moveItem(node,ids[forcedIntoClusterIndex]);

                double logProb = dlogps[forcedIntoClusterIndex]-maxlogP-log(sumP);
                sumOfLogProbabilities  = sumOfLogProbabilities +logProb;
            }
//        std::chrono::high_resolution_clock::time_point time_afterRest = std::chrono::high_resolution_clock::now();
//        std::chrono::duration<double> restTime = std::chrono::duration_cast<std::chrono::duration<double>>(time_afterRest - time_beforeRest);
//        std::cout << "                   rest time " << (double)restTime.count() << std::endl;

//            std::chrono::high_resolution_clock::time_point time_after = std::chrono::high_resolution_clock::now();
//            std::chrono::duration<double> tTime = std::chrono::duration_cast<std::chrono::duration<double>>(time_after - time_before);
//            std::cout << "                   nodeindex "<< nodeIndex << " time " << (double)tTime.count() << std::endl;
        }
        sumOfLogProbabilitiesVector.push_back(sumOfLogProbabilities);
    }
//    std::chrono::high_resolution_clock::time_point time_afterSampler = std::chrono::high_resolution_clock::now();
//    std::chrono::duration<double> samplerTime = std::chrono::duration_cast<std::chrono::duration<double>>(time_afterSampler - time_beforeSampler);
//    std::cout << "                restricted gibbs time " << (double)samplerTime.count() << std::endl;
    return sumOfLogProbabilitiesVector;
}
