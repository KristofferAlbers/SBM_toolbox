/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**

This file defines classes that are used to represent various types of networks,
as well as iterators to efficiently iterate over links within these networks.
*/

#ifndef NETWORK_H_INCLUDED
#define NETWORK_H_INCLUDED


#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "NetworkDocument.h"

/**
struct to store the entry of a link
*/
template <typename T> struct dataEntry
{
    size_t target;  //id of node
    T value;        //weight of the link
};

/**
Object of class NetworkData is used as container for an adjacency list
Multiple objects might be utilized to represent a network, depending on the network topology
*/
template <typename T> class NetworkData
{
public:
    std::string name;           //name, to identify the adjacency list
private:
    std::vector<size_t> targetsStartForSource_;
    std::vector<dataEntry<T>> data_;
    size_t numberOfRows;
    size_t numberOfColumns;
    T noValue_;

public:

    /**
        Constructor
        @param name_ - name to identify the object
        @param noValue - assumed link value returned if a requested link is not stored
    */
    NetworkData(std::string name_, T noValue)
    {
        name = name_;
        noValue_ = noValue;
    }
    virtual ~NetworkData()
    {
    }


    /** @return the number of nodes */
    size_t getNumberOfNodes()
    {
        return std::max(numberOfColumns,numberOfRows);
    }
    /** @return the number of rows, if considered an assignment matrix */
    size_t getNumberOfRows()
    {
        return numberOfRows;
    };
    /** @return the number of columns, if considered an assignment matrix */
    size_t getNumberOfColumns()
    {
        return numberOfColumns;
    };
    /**
        returns the value for the link from node @param sourceId to node @param targetId
        @return the value of the link
    */
    T getValue(size_t sourceId, size_t targetId)
    {
        //binary search
        int min = targetsStartForSource_[sourceId];
        int max = targetsStartForSource_[sourceId+1]-1;

        while(max >= min){
            int mid = (max - min)/2 + min;
            size_t midvalId = (data_)[mid].target;
            if(  midvalId == targetId ) {
                return data_[mid].value;
            }
            else if( midvalId < targetId){
                min = mid + 1;
            }
            else {
                max = mid - 1;
            }
        }
        return noValue_;
    }

    /**
        Populate the object with nodes as defined by a NetworkDocument object
        @param numberOfRows_ - number of rows in the assignment matrix
        @param numberOfColumns_ - number of columns in the assignment matrix
        @param matrix - the networkDocument object defining the assignment matrix
        @param transposed - true: store links to nodes instead of links from nodes
        @param swapped - swap between which node is considered target and source in each link
    */
    void populate(int numberOfRows_,int numberOfColumns_,NetworkDocument<T>& matrix, bool transposed,bool swapped)
    {
        numberOfRows = numberOfRows_;
        numberOfColumns = numberOfColumns_;

        std::vector<size_t>* consider_source;
        std::vector<size_t>* consider_target;
        std::vector<T>* consider_values;
        if(!transposed)
        {
            if(swapped)
            {
                consider_source = &matrix.targets;
                consider_target = &matrix.sources;
            }
            else
            {
                consider_source = &matrix.sources;
                consider_target = &matrix.targets;
            }
            consider_values = &matrix.values;
        }
        else
        {
            if(swapped)
            {
                consider_source = &matrix.targets_t;
                consider_target = &matrix.sources_t;
            }
            else
            {
                consider_source = &matrix.sources_t;
                consider_target = &matrix.targets_t;
            }
            consider_values = &matrix.values_t;
        }

        std::vector<size_t>& sources = *consider_source;
        std::vector<size_t>& targets = *consider_target;
        std::vector<T>& values = *consider_values;

        targetsStartForSource_.clear();
        targetsStartForSource_.reserve(numberOfRows);

        size_t curSource = 0;
        int numTargetsForSource = 0;
        targetsStartForSource_.push_back(0);

        for(size_t i = 0 ; i<targets.size() ; i++ ){
            while(sources[i]!=curSource){
                targetsStartForSource_.push_back(data_.size());
                curSource++;
                numTargetsForSource = 0;
            }
            data_.push_back({targets[i],values[i]});
            numTargetsForSource ++ ;
        }
        for(size_t i = curSource+1;i<numberOfRows;i++)
            targetsStartForSource_.push_back(data_.size());

        targetsStartForSource_.push_back(data_.size());
    }

    /**
        Populate the object with nodes as defined by a NetworkDocument object
        @param numberOfRows_ - number of rows in the assignment matrix
        @param numberOfColumns_ - number of columns in the assignment matrix
        @param matrix - the networkDocument object defining the assignment matrix
        @param ignore - networkDocument defining missing links in the network
        @param missingToZero true: set missing links to zero, false: subtract value of missing link from actual link
        @param transposed - true: store links to nodes instead of links from nodes
        @param swapped - swap between which node is considered target and source in each link
    */
    void populate(int numberOfRows_, int numberOfColumns_,NetworkDocument<T>& matrix, NetworkDocument<T>& ignore, bool missingToZero, bool transposed,bool swapped)
    {
        numberOfRows = numberOfRows_;
        numberOfColumns = numberOfColumns_;

        std::vector<size_t>* consider_source;
        std::vector<size_t>* consider_target;
        std::vector<T>* consider_values;
        if(!transposed)
        {
            if(swapped)
            {
                consider_source = &matrix.targets;
                consider_target = &matrix.sources;
            }
            else
            {
                consider_source = &matrix.sources;
                consider_target = &matrix.targets;
            }
            consider_values = &matrix.values;
        }
        else
        {
            if(swapped)
            {
                consider_source = &matrix.targets_t;
                consider_target = &matrix.sources_t;
            }
            else
            {
                consider_source = &matrix.sources_t;
                consider_target = &matrix.targets_t;
            }
            consider_values = &matrix.values_t;
        }

        std::vector<size_t>& sources = *consider_source;
        std::vector<size_t>& targets = *consider_target;
        std::vector<T>& values = *consider_values;

        std::vector<size_t>* consider_ignore_source;
        std::vector<size_t>* consider_ignore_target;
        std::vector<T>* consider_ignore_values;
        if(!transposed)
        {
            if(swapped)
            {
                consider_ignore_source = &ignore.targets;
                consider_ignore_target = &ignore.sources;
            }
            else
            {
                consider_ignore_source = &ignore.sources;
                consider_ignore_target = &ignore.targets;
            }
            consider_ignore_values = &ignore.values;
        }
        else
        {
            if(swapped)
            {
                consider_ignore_source = &ignore.targets_t;
                consider_ignore_target = &ignore.sources_t;
            }
            else
            {
                consider_ignore_source = &ignore.sources_t;
                consider_ignore_target = &ignore.targets_t;
            }
            consider_ignore_values = &ignore.values_t;
        }

        std::vector<size_t>& ignoreSources = *consider_ignore_source;
        std::vector<size_t>& ignoreTargets = *consider_ignore_target;
        std::vector<T>& ignoreValues = *consider_ignore_values;


        targetsStartForSource_.clear();
        targetsStartForSource_.reserve(numberOfRows);

        size_t curSource = 0;
        int numTargetsForSource = 0;
        targetsStartForSource_.push_back(0);

        int nextIgnorePos = 0;
        size_t nextSourceIgnore = ignoreSources[0];
        size_t nextTargetIgnore = ignoreTargets[0];
        T nextIgnoreValue = ignoreValues[0];

        for(size_t i = 0 ; i<targets.size() ; i++ ){
            while(sources[i]!=curSource){
                targetsStartForSource_.push_back(data_.size());
                curSource++;
                numTargetsForSource = 0;
            }
            if(true) //no consistincy between matrix and ignore
            {
                while(nextSourceIgnore < curSource && nextIgnorePos<ignoreSources.size())
                {
                    nextIgnorePos++;
                    nextSourceIgnore = ignoreSources[nextIgnorePos];
                    nextTargetIgnore = ignoreTargets[nextIgnorePos];
                    nextIgnoreValue = ignoreValues[nextIgnorePos];
                }
                while(nextSourceIgnore == curSource && nextTargetIgnore<targets[i] && nextIgnorePos<ignoreSources.size())
                {
                    nextIgnorePos++;
                    nextSourceIgnore = ignoreSources[nextIgnorePos];
                    nextTargetIgnore = ignoreTargets[nextIgnorePos];
                    nextIgnoreValue = ignoreValues[nextIgnorePos];

                }
            }
            //add link if not ignored
            if(nextSourceIgnore == curSource && nextTargetIgnore==targets[i])
            {
                if(!missingToZero)
                {
                    T value = values[i] - ignoreValues[nextIgnorePos];
                    data_.push_back({targets[i],value});
                    numTargetsForSource ++ ;
                }

                nextIgnorePos++;
                nextSourceIgnore = ignoreSources[nextIgnorePos];
                nextTargetIgnore = ignoreTargets[nextIgnorePos];
                nextIgnoreValue = ignoreValues[nextIgnorePos];

            }
            else
            {
                data_.push_back({targets[i],values[i]});
                numTargetsForSource ++ ;
            }
        }
        for(size_t i = curSource+1;i<numberOfRows;i++)
            targetsStartForSource_.push_back(data_.size());

        targetsStartForSource_.push_back(data_.size());
    }


    /**
        Iterator for links in the adjacency list
    */
    class iterator: public std::iterator<std::forward_iterator_tag, T>
    {
        private:
            std::vector<dataEntry<T>>* data_;
            typename std::vector<dataEntry<T>>::iterator iter_;
            int startAt_;

        public:
            iterator() {};
            iterator(const iterator& other) : data_(other.data_), iter_(other.iter_) {};
            iterator(std::vector<dataEntry<T>>& data, typename std::vector<dataEntry<T>>::iterator iter) : data_(&data), iter_(iter) {};

            inline iterator& operator=(const iterator& other)
            {
                iter_ = other.iter_;
                data_ = other.data_;
                return *this;
            }
            inline iterator& operator++()
            {
                ++iter_;
                return *this;
            };
            inline iterator operator++(int)
            {
                iterator temp(*this);
                operator++();
                return temp;
            }
            inline bool operator!=(const iterator other)
            {
                return iter_ != other.iter_;
            };
            inline bool operator==(const iterator other)
            {
                return iter_ == other.iter_;
            }
            inline T getValue(){
                return (*iter_).value;
            }
            inline size_t getTarget(){
                return (*iter_).target;
            }
            inline size_t index()
            {
                std::cout << "unimplemented function  'class iterator: public std::iterator<std::forward_iterator_tag, T>'  in Network.h" << std::endl;
                return 0;
            }
        };
    iterator begin(int sourceId)
    {
        typename std::vector<dataEntry<T>>::iterator iter = data_.begin()+targetsStartForSource_[sourceId];
        return iterator(data_,iter);
    };
    iterator end(int sourceId)
    {
        typename std::vector<dataEntry<T>>::iterator iter = data_.begin()+targetsStartForSource_[sourceId+1];
        return iterator(data_,iter);
    };

    /**
        Debug function for printing the stored data
    */
    void print()
    {
        std::cout << "network: " << name << " <bool>" << std::endl;
        for(size_t i = 0; i<getNumberOfRows();i++){
            for(size_t j = 0; j<getNumberOfColumns();j++)
            {
                std::cout << getValue(i,j) << " ";
            }
            std::cout<<" "<<std::endl;
        }
    }


};

/**
    Template specialization of class Network for boolean values
    An object of class Network<bool> can be used to store a network with binary links,
    that has no associated weight.
**/
template <> class NetworkData<bool>{

public:
    std::string name;   //name used to identify the network

private:
    std::vector<size_t> targetsStartForSource_;
    std::vector<size_t> data_;
    size_t numberOfRows, numberOfColumns;

public:
    /** @param name_ */
    NetworkData(std::string name_)
    {
        name = name_;
    }
    /**
        @param name_
        @param zeroValue - value returned if no link is present
    */
    NetworkData(std::string name_, bool zeroValue)
    {
        name = name_;
    }

    virtual ~NetworkData()
    {
    }
    /** @return number of nodes */
    size_t getNumberOfNodes()
    {
        return std::max(numberOfColumns,numberOfRows);
    }
    /** @return number of rows when considering the network as an assignment matrix*/
    size_t getNumberOfRows()
    {
        return numberOfRows;
    }
    /** @return number of columns when considering the network as an assignment matrix*/
    size_t getNumberOfColumns()
    {
        return numberOfColumns;
    }

    /** Function definition for requesting value of a link between two nodes*/
    bool getValue(size_t sourceId, size_t targetId);

    /**
        Populate the network data structure according to a NetworkDocument object
        @param numberOfRows_
        @param numberOfColumns_
        @param matrix - NetworkData object defining the adjacency matrix of the network
        @param transposed - true: store links to nodes instead of from nodes
        @param swapped - true: swap source and target for all links.
    */
    void populate(size_t numberOfRows_, int numberOfColumns_, NetworkDocument<bool>& matrix, bool transposed,bool swapped)
    {

        numberOfRows = numberOfRows_;
        numberOfColumns = numberOfColumns_;



        std::vector<size_t>* consider_source;
        std::vector<size_t>* consider_target;
        if(!transposed)
        {
            if(swapped)
            {
                consider_source = &matrix.targets;
                consider_target = &matrix.sources;
            }
            else
            {
                consider_source = &matrix.sources;
                consider_target = &matrix.targets;
            }

        }
        else
        {
            if(swapped)
            {
                consider_source = &matrix.targets_t;
                consider_target = &matrix.sources_t;
            }
            else
            {
                consider_source = &matrix.sources_t;
                consider_target = &matrix.targets_t;
            }

        }

        std::vector<size_t>& sources = *consider_source;
        std::vector<size_t>& targets = *consider_target;

        targetsStartForSource_.clear();
        targetsStartForSource_.reserve(numberOfRows);

        size_t curSource = 0;
        int numTargetsForSource = 0;
        targetsStartForSource_.push_back(0);

        for(size_t i = 0 ; i<targets.size() ; i++ ){
            while(sources[i]!=curSource){
                targetsStartForSource_.push_back(data_.size());
                curSource++;
                numTargetsForSource = 0;
            }
            data_.push_back(targets[i]);
            numTargetsForSource ++ ;
        }
        for(size_t i = curSource+1;i<numberOfRows;i++)
            targetsStartForSource_.push_back(data_.size());

        targetsStartForSource_.push_back(data_.size());
    }

    /**
        Populate the network data structure according to a NetworkDocument objects
        @param numberOfRows_
        @param numberOfColumns_
        @param matrix - NetworkData object defining the adjacency matrix of the network
        @param ignore - NetworkData object defining missing links in the network
        @param missingToZero - true: set missing links to zero, false: subtract value of missing link from actual link value
        @param transposed - true: store links to nodes instead of from nodes
        @param swapped - true: swap source and target for all links.
    */
    void populate(size_t numberOfRows_, size_t numberOfColumns_, NetworkDocument<bool>& matrix, NetworkDocument<bool>& ignore,bool missingToZero, bool transposed,bool swapped)
    {

        numberOfColumns = numberOfColumns_;
        numberOfRows = numberOfRows_;

        std::vector<size_t>* consider_source;
        std::vector<size_t>* consider_target;
        if(!transposed)
        {
            if(swapped)
            {
                consider_source = &matrix.targets;
                consider_target = &matrix.sources;
            }
            else
            {
                consider_source = &matrix.sources;
                consider_target = &matrix.targets;
            }

        }
        else
        {
            if(swapped)
            {
                consider_source = &matrix.targets_t;
                consider_target = &matrix.sources_t;
            }
            else
            {
                consider_source = &matrix.sources_t;
                consider_target = &matrix.targets_t;
            }
        }

        std::vector<size_t>& sources = *consider_source;
        std::vector<size_t>& targets = *consider_target;


        std::vector<size_t>* consider_ignore_source;
        std::vector<size_t>* consider_ignore_target;
        if(!transposed)
        {
            consider_ignore_source = &ignore.sources;
            consider_ignore_target = &ignore.targets;
        }
        else
        {
            consider_ignore_source = &ignore.sources_t;
            consider_ignore_target = &ignore.targets_t;
        }
        std::vector<size_t>& ignoreSources = *consider_ignore_source;
        std::vector<size_t>& ignoreTargets = *consider_ignore_target;



        targetsStartForSource_.clear();
        targetsStartForSource_.reserve(numberOfRows);

        size_t curSource = 0;
        int numTargetsForSource = 0;
        targetsStartForSource_.push_back(0);

        size_t nextIgnorePos = 0;
        size_t nextSourceIgnore = ignoreSources[0];
        size_t nextTargetIgnore = ignoreTargets[0];


        for(size_t i = 0 ; i<targets.size() ; i++ ){
            while(sources[i]!=curSource){
                targetsStartForSource_.push_back(data_.size());
                curSource++;
                numTargetsForSource = 0;
            }
            if(true) //no consistincy between matrix and ignore
            {
                while(nextSourceIgnore < curSource && nextIgnorePos<ignoreSources.size())
                {
                    nextIgnorePos++;
                    nextSourceIgnore = ignoreSources[nextIgnorePos];
                    nextTargetIgnore = ignoreTargets[nextIgnorePos];
                }
                while(nextSourceIgnore == curSource && nextTargetIgnore<targets[i] && nextIgnorePos<ignoreSources.size())
                {
                    nextIgnorePos++;
                    nextSourceIgnore = ignoreSources[nextIgnorePos];
                    nextTargetIgnore = ignoreTargets[nextIgnorePos];
                }
            }
            //add link if not ignored
            if(nextSourceIgnore == curSource && nextTargetIgnore==targets[i])
            {
                nextIgnorePos++;
                nextSourceIgnore = ignoreSources[nextIgnorePos];
                nextTargetIgnore = ignoreTargets[nextIgnorePos];
            }
            else
            {
                data_.push_back(targets[i]);
                numTargetsForSource ++ ;
            }
        }
        for(size_t i = curSource+1;i<numberOfRows;i++)
            targetsStartForSource_.push_back(data_.size());

        targetsStartForSource_.push_back(data_.size());

    }


    void print();

    class iterator;
    iterator begin(int sourceId);
    iterator end(int sourceId);

};

/**
Implementation of NetworkData<bool> function for obtaining the link value between
nodes @param sourceId and @param targetId.
*/
inline bool NetworkData<bool>::getValue(size_t sourceId, size_t targetId){
    //binary search
	int min = targetsStartForSource_[sourceId];
	int max = targetsStartForSource_[sourceId+1]-1;

	while(max >= min){
		int mid = (max - min)/2 + min;
        size_t midval = (data_)[mid];
		if(  midval == targetId ) {
			return true;
		}
		else if( midval < targetId){
			min = mid + 1;
		}
		else {
			max = mid - 1;
		}
	}
    return false;
}

/**
Debug function to print data stored in a NetworkData<bool> object
*/
inline void NetworkData<bool>::print()
{
    std::cout << "network: " << name << " <bool>" << std::endl;
    for(size_t i = 0; i<getNumberOfRows();i++){
        for(size_t j = 0; j<getNumberOfColumns();j++){
            if(getValue(i,j))
            {
                std::cout << "1";
            }
            else
            {
                std::cout << ".";
            }
        }
        std::cout<<""<<std::endl;
    }
}

/**
Iterator for class NetworkData<bool>
*/
class NetworkData<bool>::iterator : public std::iterator<std::forward_iterator_tag, bool>
{

private:
    std::vector<size_t>* data_;
    typename std::vector<size_t>::iterator iter_;
    int startAt_;

public:
    iterator() {};
    iterator(const iterator& other) : data_(other.data_), iter_(other.iter_) {};
    iterator(std::vector<size_t>& data, typename std::vector<size_t>::iterator iter) : data_(&data), iter_(iter) {};

    inline iterator& operator=(const iterator& other)
    {
        iter_ = other.iter_;
        data_ = other.data_;
        return *this;
    }
    inline iterator& operator++()
    {
        ++iter_;
        return *this;
    };
    inline iterator operator++(int)
    {
        iterator temp(*this);
        operator++();
        return temp;
    }
    inline bool operator!=(const iterator other)
    {
        return iter_ != other.iter_;
    };
    inline bool operator==(const iterator other)
    {
        return iter_ == other.iter_;
    }
    inline bool getValue(){
        return true;
    }
    inline size_t getTarget(){
        return *iter_;
    }
    inline size_t index()
    {
        std::cout << "unimplemented function  'inline size_t index()'  in sparse_matrix.h" << std::endl;
        return 0;
    }
};

/** get begin for iterator for links associated with a given node @param sourceId */
inline NetworkData<bool>::iterator NetworkData<bool>::begin(int sourceId)
{
        std::vector<size_t>::iterator iter = data_.begin()+targetsStartForSource_[sourceId];
        return iterator(data_,iter);
};

/** get end for iterator for links associated with a given node @param sourceId */
inline NetworkData<bool>::iterator NetworkData<bool>::end(int sourceId)
{
        typename std::vector<size_t>::iterator iter = data_.begin()+targetsStartForSource_[sourceId+1];
        return iterator(data_,iter);
};



/**
An object of this class represents a biparite network (where number of rows can differ from number
of columns in the assignment matrix)
*/
template <typename T> class BipartiteNetwork
{

public:
    bool withmissing;
    size_t numberOfRows;
    size_t numberOfColumns;


    NetworkData<T> data_classA;
    NetworkData<T> data_classB;

    NetworkData<T> missing_classA;
    NetworkData<T> missing_classB;


    /**
        Construct bipartite network data structure according to a NetworkDocument objects
         - with missing data -
        @param numberOfNodes_classA - number of nodes in the first class of nodes (rows in adjacency matrix)
        @param numberOfNodes_classB - number of nodes in the second class of nodes (columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param zeroIndexedFiles - boolean to define if first node in the network file is identified by 0 (zero)
        @param missingDataFile - NetworkData object defining missing links in the network
        @param missingToZero - true: set missing links to zero, false: subtract value of missing link from actual link value
        @param weighted - boolean to define if network is weighted
    */
    BipartiteNetwork(int numberOfNodes_classA, int numberOfNodes_classB, std::string dataFile, std::string missingDataFile, bool zeroIndexedFiles, bool missingWeighted, bool missingToZero, bool weighted) :
                data_classA("data class A",0), data_classB("data class B",0), missing_classA("missing class A",0), missing_classB("missing class B",0)
    {
        withmissing = true;
        NetworkDocument<T> links(numberOfNodes_classA,numberOfNodes_classB,dataFile,true,weighted,zeroIndexedFiles,true);
        NetworkDocument<T> missinglinks(numberOfNodes_classA,numberOfNodes_classB,missingDataFile,true,missingWeighted,zeroIndexedFiles,true);

        data_classA.populate(numberOfNodes_classA,numberOfNodes_classB,links,missinglinks,missingToZero,false,false);
        data_classB.populate(numberOfNodes_classB,numberOfNodes_classA, links,missinglinks,missingToZero,true,false);

        missing_classA.populate(numberOfNodes_classA,numberOfNodes_classB,missinglinks,false,false);
        missing_classB.populate(numberOfNodes_classB,numberOfNodes_classA,missinglinks,true,false);
    }

    /**
        Construct bipartite network data structure according to a NetworkDocument objects
         - without missing data -
        @param numberOfNodes_classA - number of nodes in the first class of nodes (rows in adjacency matrix)
        @param numberOfNodes_classB - number of nodes in the second class of nodes (columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param zeroIndexedFiles - boolean to define if first node in the network file is identified by 0 (zero)
        @param weighted - boolean to define if network is weighted
    */
    BipartiteNetwork(int numberOfNodes_classA, int numberOfNodes_classB, std::string dataFile, bool zeroIndexedFile, bool weighted) :
                data_classA("data class A",0), data_classB("data class B",0), missing_classA("missing class A",0), missing_classB("missing class B",0)
    {
        withmissing = false;
        NetworkDocument<T> links(numberOfNodes_classA,numberOfNodes_classB,dataFile,true,weighted,zeroIndexedFile,true);
        data_classA.populate(numberOfNodes_classA,numberOfNodes_classB,links,false,false);
        data_classB.populate(numberOfNodes_classB,numberOfNodes_classA, links, true,false);
    }



    /**
        Limited constructer for bipartite network data structure according to a NetworkDocument objects
         - without missing data, assuming network data is zero-indexed
        @param numberOfNodes_classA - number of nodes in the first class of nodes (rows in adjacency matrix)
        @param numberOfNodes_classB - number of nodes in the second class of nodes (columns in adjacency matrix)
        @param data_ - NetworkData object defining the adjacency matrix of the network
    */
    BipartiteNetwork(int numberOfNodes_classA, int numberOfNodes_classB, NetworkDocument<T>& data_) :
                data_classA("data class A",0), data_classB("data class B",0), missing_classA("missing class A",0), missing_classB("missing class B",0)
    {
        withmissing = false;
        data_classA.populate(numberOfNodes_classA,numberOfNodes_classB,data_,false,false);
        data_classB.populate(numberOfNodes_classB,numberOfNodes_classA, data_, true,false);
    }

    /**
        Limited constructer for bipartite network data structure according to a NetworkDocument objects
         - with missing data, assuming network data is zero-indexed
        @param numberOfNodes_classA - number of nodes in the first class of nodes (rows in adjacency matrix)
        @param numberOfNodes_classB - number of nodes in the second class of nodes (columns in adjacency matrix)
        @param data_ - NetworkData object defining the adjacency matrix of the network
        @param missing_ - NetworkData object defining missing links in the network
        @param missingToZero - true: set missing links to zero, false: subtract value of missing link from actual link value
    */    BipartiteNetwork(int numberOfNodes_classA, int numberOfNodes_classB, NetworkDocument<T>& data_, NetworkDocument<T>& missing_, bool missingToZero) :
                data_classA("data class A",0), data_classB("data class B",0), missing_classA("missing class A",0), missing_classB("missing class B",0)
    {
        withmissing = true;
        data_classA.populate(numberOfNodes_classA,numberOfNodes_classB,data_,missing_,missingToZero,false,false);
        data_classB.populate(numberOfNodes_classB,numberOfNodes_classA, data_,missing_,missingToZero,true,false);

        missing_classA.populate(numberOfNodes_classA,numberOfNodes_classB,missing_,false,false);
        missing_classB.populate(numberOfNodes_classB,numberOfNodes_classA,missing_,true,false);
    }




};


/**
An object of this class represents a unipartite network. Templated argument define types of links
in the network.
*/
template <typename T> class UnipartiteNetwork
{
public:
    NetworkData<T> data;
    NetworkData<T> data_transposed;
    NetworkData<T> missing;
    NetworkData<T> missing_transposed;
    bool directed;
    bool withmissing;
    size_t numberOfNodes;

    /**
        Construct unipartite network data structure according to a NetworkDocument objects
         - with missing data -
        @param numberOfNodes_ - number of nodes in the network (rows == columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param missingDataFile - NetworkData object defining the missing links
        @param zeroIndexedFiles - boolean to define if first node in the network file is identified by 0 (zero)
        @param missingWeighted - missing links are weighted
        @param missingToZero - true: set missing links to zero, false: subtract value of missing link from actual link value
        @param weighted - boolean to define if network is weighted
        @param directed_ - true: network is directed, false: network is undirected
    */
    UnipartiteNetwork(size_t numberOfNodes_,std::string dataFile, std::string missingDataFile, bool zeroIndexedFiles, bool missingWeighted, bool missingToZero, bool weighted, bool directed_) :
            data("data",0), data_transposed("data_transposed",0), missing("missing",0), missing_transposed("missing_transposed",0)
    {

        numberOfNodes = numberOfNodes_;
        withmissing = true;
        directed = directed_;

        NetworkDocument<T> links(numberOfNodes_,numberOfNodes_,dataFile,directed,weighted,zeroIndexedFiles,false);
        NetworkDocument<T> missinglinks(numberOfNodes_,numberOfNodes_,missingDataFile,directed,missingWeighted,zeroIndexedFiles,false);

        data.populate(numberOfNodes,numberOfNodes,links,missinglinks,missingToZero,false,false);
        missing.populate(numberOfNodes,numberOfNodes,missinglinks,false,false);
        if(directed_)
        {
            data_transposed.populate(numberOfNodes,numberOfNodes,links,missinglinks,missingToZero,true,false);
            missing_transposed.populate(numberOfNodes,numberOfNodes,missinglinks,true,false);
        }
    }

    /**
        Construct unipartite network data structure according to a NetworkDocument objects
         - without missing data -
        @param numberOfNodes_ - number of nodes in the network (rows == columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param zeroIndexedFiles - boolean to define if first node in the network file is identified by 0 (zero)
        @param weighted - boolean to define if network is weighted
        @param directed_ - true: network is directed, false: network is undirected
    */
    UnipartiteNetwork(size_t numberOfNodes_,std::string dataFile, bool zeroIndexedFile, bool weighted, bool directed_) :
            data("data",0), data_transposed("data_transposed",0), missing("missing",0), missing_transposed("missing_transposed",0)
    {
        numberOfNodes = numberOfNodes_;
        directed = directed_;
        withmissing = false;

        NetworkDocument<T> links(numberOfNodes_,numberOfNodes_,dataFile,directed,weighted,zeroIndexedFile,false);

        data.populate(numberOfNodes,numberOfNodes,links,false,false);
        if(directed)
        {
            data_transposed.populate(numberOfNodes,numberOfNodes, links, true,false);
        }

    }

    /**
        Limited constructor for unipartite network data structure according to a NetworkDocument objects
         - with missing data -
        @param numberOfNodes_ - number of nodes in the network (rows == columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param missing_ - NetworkData object defining missing links in the network
        @param missingToZero - true: set missing links to zero, false: subtract value of missing link from actual link value
        @param directed_ - true: network is directed, false: network is undirected
    */
    UnipartiteNetwork(int numberOfNodes_, NetworkDocument<T>& data_, NetworkDocument<T>& missing_,bool missingToZero, bool directed_):
            data("data",0), data_transposed("data_transposed",0), missing("missing",0), missing_transposed("missing_transposed",0)
    {
        numberOfNodes = numberOfNodes_;
        withmissing = true;
        directed = directed_;

        data.populate(numberOfNodes,numberOfNodes,data_,missing_,missingToZero,false,false);
        missing.populate(numberOfNodes,numberOfNodes,missing_,false,false);
        if(directed_)
        {
            data_transposed.populate(numberOfNodes,numberOfNodes,data_,missing_,missingToZero,true,false);
            missing_transposed.populate(numberOfNodes,numberOfNodes,missing_,true,false);
        }
    }

    /**
        Limited constructor for unipartite network data structure according to a NetworkDocument objects
         - without missing data -
        @param numberOfNodes_ - number of nodes in the network (rows == columns in adjacency matrix)
        @param dataFile - NetworkData object defining the adjacency matrix of the network
        @param directed_ - true: network is directed, false: network is undirected
    */
    UnipartiteNetwork(int numberOfNodes_, NetworkDocument<T> data_, bool directed_) :
        data("data",0), data_transposed("data_transposed",0), missing("missing",0), missing_transposed("missing_transposed",0)
    {
        numberOfNodes = numberOfNodes_;
        directed = directed_;
        withmissing = false;
        data.populate(numberOfNodes,numberOfNodes,data_,false,false);
        if(directed)
        {
            data_transposed.populate(numberOfNodes,numberOfNodes, data_, true,false);
        }
    }

    /** @return number of nodes in the network */
    size_t getNumberOfNodes()
    {
        return numberOfNodes;
    }


};


#endif // NETWORK_H_INCLUDED
