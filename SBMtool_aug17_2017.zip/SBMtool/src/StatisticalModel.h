/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This file defines the base class from which model classes can be inherited
*/



#ifndef STATISTICALMODEL_H_INCLUDED
#define STATISTICALMODEL_H_INCLUDED


#include "Options.h"
#include "settings.h"
#include "Parameter.h"
#include <string>
#include <vector>


class StatisticalModel
{
protected:
    std::string name_;                  //name of the statistical model
    Options options_;                   //user options parsed to the model
    std::vector<Parameter*> parameters; //list of parameters associated with the model
public:
    StatisticalModel(std::string n,Options o) : name_(n), options_(o) {}
    StatisticalModel(){};

    std::string getName() const;

    //virtual functions that must be implemented
    virtual double computeLogLikelihood() = 0;
    virtual double computeLogPosterior() = 0;
    virtual double computeLogPrior() = 0;

    Parameter* getParameter(std::string parameterName);

    //returns options associated with a parameter
    Options getParameterOptions(std::string parameterName)
    {
        return getOption(options_,parameterName,Options());
    };
    //add parameter to the model
    void addParameter(Parameter* parameter);

//structures used by programmer to describe the model, parameters and options in the\
    context of the particular model
virtual std::vector<ParameterDescription> getParameterDescriptions() = 0;
virtual std::vector<SettingDescription> getSettingDescriptions() = 0;
virtual ModelDescription getModelDescription() = 0;


};


#endif // STATISTICALMODEL_H_INCLUDED
