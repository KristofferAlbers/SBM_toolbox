/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
This code is provided as is without any warranty!

Implementation of the Metropolis-Hastings sampling (random walker)
for real valued parameters. Defines the user settings/options and
implements the sample() function
*/

#include "Sampler.h"

const std::string MetropolisHastings_real::SAMPLERNAME = "MetropolisHastings_real";

Creator<MCMC_sampler, MetropolisHastings_real> MetropolisHastings_real::Create(MetropolisHastings_real::SAMPLERNAME);

const std::vector<SettingDescription> MetropolisHastings_real::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The real parameter to sample") },
    {   SettingDescription("sweeps","INT",false).initialInt(1).min(1).shortDescription("Number of samples")},
    {   SettingDescription("stddev","FLOAT",false).initialFloat(1.0).shortDescription("std. deviation for drawing proposals")},
    {   SettingDescription("logdomain","BOOL",false).initialBool(false).shortDescription("compute in log domain")}
};

void MetropolisHastings_real::sample()
{
    accepts = 0;
    proposals = 0;
    for(size_t t = 0 ; t<sweeps ; t++)
    {
        proposals ++;
        double par = parameter_->get();
        double newpar;
        double r;
        if(compinlog)
        {
            double lognewpar = log(par) + proposal(generator);
            newpar = exp(lognewpar);
            r = parameter_->logPosteriorRatio(newpar) + lognewpar - log(par);
        }
        else
        {
            newpar = par + proposal(generator);
            r = parameter_->logPosteriorRatio(newpar);
        }
        bool accept = exp(r) > uniform(generator);
        if (accept)
        {
            parameter_->set(newpar);
            accepts++;
        }
    }
}
