/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "SbmPoisson_bipartite.h"

const std::string SbmPoisson_bipartite::MODELNAME = "SbmPoisson_bipartite";

const ModelDescription SbmPoisson_bipartite::modelDescription("SbmPoirs","finite, bipartite","irm model with poisson likelihood and gamma prior");

const std::vector<SettingDescription> SbmPoisson_bipartite::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items1","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class1 of the network").longDescription("The number of nodes in class1 of the network")   },
    {   SettingDescription("items2","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class2 of the network").longDescription("The number of nodes in class2 of the network")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("components1","INT",true).min(1).max(10000).shortDescription("Number of components in the clustering of group 1").longDescription("The maximal allowed number of components in the clustering of group 1")   },
    {   SettingDescription("components2","INT",true).min(1).max(10000).shortDescription("Number of components in the clustering of group 2").longDescription("The maximal allowed number of components in the clustering of group 2")   },
    {   SettingDescription("a.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of a")   },
    {   SettingDescription("b.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of b")   },
    {   SettingDescription("alpha1.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 1") },
    {   SettingDescription("alpha2.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 2") },
    {   SettingDescription("clustering1.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1").longDescription("Initial number of components, the nodes are randomny split into")    },
    {   SettingDescription("clustering2.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 2").longDescription("Initial number of components, the nodes are randomny split into")    }

};

const std::vector<ParameterDescription> SbmPoisson_bipartite::parameterDescriptions
{
    {   ParameterDescription("clustering1","INFINITE_CLUSTERING").shortDescription("clustering1 parameter").longDescription("")    },
    {   ParameterDescription("clustering2","INFINITE_CLUSTERING").shortDescription("clustering2 parameter").longDescription("")    },
    {   ParameterDescription("alpha1","REAL").shortDescription("concentration parameter for clustering of group 1").longDescription("")    },
    {   ParameterDescription("alpha2","REAL").shortDescription("concentration parameter for clustering of group 2").longDescription("")    },
    {   ParameterDescription("a","REAL").shortDescription("a hyperparameter").longDescription("")    },
    {   ParameterDescription("b","REAL").shortDescription("b hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, SbmPoisson_bipartite> SbmPoisson_bipartite::Create(SbmPoisson_bipartite::MODELNAME);


void SbmPoisson_bipartite::getNodeCounts(size_t nodeId, Data& data_, Clustering_finite& targetClustering, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts)
{

    nodecounts.nodePairs.clear();
    nodecounts.nodePairs.resize(max);

    nodecounts.linkSum.clear();
    nodecounts.linkSum.resize(max);

    nodecounts.missingNodePairs.clear();
    nodecounts.missingNodePairs.resize(max);


    for(size_t c = 0 ; c < max; c++)
    {
        if(c<targetClustering.getNumberOfClusters())
            nodecounts.nodePairs[c] = numSubjects*targetClustering.getSize(c);
    }

    for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
    {
        size_t itemId = iter.getTarget();
        size_t value = iter.getValue();
        size_t clusterId = targetClustering.getClusterId(itemId);
        nodecounts.linkSum[clusterId]+=value;
    }

    if(usemissing_)
    {
        for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t clusterId = targetClustering.getClusterId(itemId);
            nodecounts.missingNodePairs[clusterId]+=iter.getValue();
        }
    }

}




double SbmPoisson_bipartite::computeLogLikelihood()
{
    double likelihood = 0;
    for(size_t netID = 0 ;netID < networks.size(); netID++)
    {
        likelihood += computeLogLikelihood(dataA[netID],clusteringDataB);
    }
    return likelihood;
}

double SbmPoisson_bipartite::computeLogLikelihood(Data& data_, Clustering_finite& targetClustering)
{
    NetworkData<size_t>& data = data_.data;

    double a = param.a_;
    double b = param.b_;

    double factsum = 0;

    for(size_t sourceNode = 0; sourceNode < data.getNumberOfRows(); sourceNode++)
    {
        if(!data_.clustering.assigned(sourceNode))
        {
            continue;
        }

        for(typename NetworkData<size_t>::iterator iter = data.begin(sourceNode); iter!=data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();

            size_t value = iter.getValue();
            double factval = factln_table.logfactorial(value);
            factsum += factval;
        }
    }

    factsum = -factsum; //(log(1) - factsum)

    Clustering_finite::iterator iterS = data_.clustering.begin();
    Clustering_finite::iterator iterS_end = data_.clustering.end();

    double clustsum = 0;

    for( ; iterS!=iterS_end ; ++iterS )
    {
        size_t sourceCluster = iterS.index();

        Clustering_finite::iterator iterT = targetClustering.begin();
        Clustering_finite::iterator iterT_end = targetClustering.end();
        for( ; iterT!=iterT_end ; ++iterT )
        {
            const size_t targetCluster = iterT.index();

            if(independentAB)
            {
                a = param.getA(targetCluster);
                b = param.getB(targetCluster);
            }

            clustsum += ( a*log( b ) ) - ( gammaln_table.gammaln(0, a  )  );
            clustsum += ( gammaln_table.gammaln(data_.sufstats.getLinkSum(sourceCluster, targetCluster) , a ))  - (  ( data_.sufstats.getLinkSum(sourceCluster, targetCluster) + a ) * log( data_.sufstats.getNodePairs(sourceCluster,targetCluster) - data_.sufstats.getMissingNodePairs(sourceCluster,targetCluster) + b )  );
        }
    }
    return clustsum + factsum;
}

double SbmPoisson_bipartite::computeLogPrior()
{
    double computedPrior = 0;
    //Clustering_finite A
    {
        //finite
        Clustering_finite& clustering_ = clusteringDataA;
        double& alpha_ = param.alphaA_;
        size_t K = getMaxNumberOfClusters(&clustering_);
        const size_t noc = clustering_.getNumberOfNonEmptyClusters();
        const size_t J = clustering_.getNumberOfItems();

        double logprior = lgamma(alpha_);
        logprior -= lgamma(J+alpha_);
        logprior -= noc*lgamma(alpha_/K);

        for(Clustering_finite::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
        {
            if(!clustering_.isempty(iter.index()))
            {
                logprior += lgamma(clustering_.getSize(iter.index()) + alpha_/K);
            }
        }
        computedPrior += logprior * networks.size();
    }


    //Clustering_finite B
    if(!bernMixtureOnly)
    {
        {
            //finite
            Clustering_finite& clustering_ = clusteringDataB;
            double& alpha_ = param.alphaB_;
            size_t K = getMaxNumberOfClusters(&clustering_);
            const size_t noc = clustering_.getNumberOfNonEmptyClusters();
            const size_t J = clustering_.getNumberOfItems();

            double logprior = lgamma(alpha_);
            logprior -= lgamma(J+alpha_);
            logprior -= noc*lgamma(alpha_/K);

            for(Clustering_finite::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
            {
                logprior += lgamma(clustering_.getSize(iter.index()));
            }
            computedPrior += logprior * networks.size();

        }
    }

    return computedPrior;
}

double SbmPoisson_bipartite::computeLogPosterior()
{
    return computeLogPrior()+computeLogLikelihood();
}





partial_vector<double> SbmPoisson_bipartite::effectiveLogPosteriorRatio_restricted_clustering(std::vector<Data>* data_pointer,size_t nodeId,std::vector<size_t>& restrictedClusters)
{


    std::vector<Data>& dataVector = *data_pointer;

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];

        Clustering_finite& clustering_ = data.clustering;
        Clustering_finite& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.linkSum.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);

        for(std::vector<size_t>::iterator itouter = restrictedClusters.begin() ; itouter!=restrictedClusters.end() ; ++itouter)
        {
            size_t cluster = *itouter;

            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(clustering_,cluster,currentCluster,currentClusterSize);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }

        }
    }
    return logps;

}


double SbmPoisson_bipartite::effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster)
{

    std::vector<Data>& dataVector = *data_pointer;
    NodeCounts<size_t> nodecounts;
    double loglike = 0;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];
        Clustering_finite& clustering_ = data.clustering;
        Clustering_finite& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.linkSum.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);
        double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
        loglike += dlikelihood;
    }
    return loglike;
}




partial_vector<double> SbmPoisson_bipartite::effectiveLogPosteriorRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId, Clustering_finite::iterator begin, Clustering_finite::iterator end, bool appendForNewCluster)
{
    std::vector<Data>& dataVector = *data_pointer;

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t subject = 0; subject < dataVector.size(); subject++)
    {
        Data& data = dataVector[subject];

        Clustering_finite& clustering_ = data.clustering;
        Clustering_finite& targetClustering_ = data.targetClustering;
        size_t max = data.sufstats.linkSum.getColumns();
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,data, targetClustering_, currentCluster,max,nodecounts);

        //existing clusters
        Clustering_finite::iterator outerIter;
        for(outerIter = begin ; outerIter!=end; ++outerIter)
        {
            size_t cluster = outerIter.index();

            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(clustering_,cluster,currentCluster,currentClusterSize);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }

        }
        //new cluster
        if(appendForNewCluster)
        {
            double logprior = logPrior_effectiveChange_newCluster(clustering_);
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data,param,currentCluster,currentClusterSize,nodecounts);
            if(logps.exist(max))
            {
               logps[max] += logprior+loglikelihood;
            }
            else
            {
                logps.set(max,logprior+loglikelihood);
            }
        }


    }
    return logps;

}



void SbmPoisson_bipartite::computeAllSufficientStatistics()
{
    for(size_t i = 0; i < dataA.size(); i++)
    {
        computeSufficientStatistics(dataA[i],dataB[i],clusteringDataA,clusteringDataB);
    }
}


void SbmPoisson_bipartite::computeSufficientStatistics(Data& dataA_,Data& dataB_,Clustering_finite& clusteringA_, Clustering_finite& clusteringB_)
{
    Matrix<size_t>& linkSum = dataA_.sufstats.linkSum;
    Matrix<size_t>& nodePairs = dataA_.sufstats.nodePairs;
    Matrix<size_t>& missingNodePairs = dataA_.sufstats.missingNodePairs;

    NetworkData<size_t>& data = dataA_.data;
    NetworkData<size_t>& missing = dataA_.missing;


    //resize
    linkSum.clear();
    nodePairs.clear();
    missingNodePairs.clear();

    size_t newMaxRows = std::max(clusteringA_.getNumberOfClusters()*2,(size_t)20);
    size_t newMaxColumns = std::max(clusteringB_.getNumberOfClusters()*2,(size_t)20);

    linkSum.setNewMaxSize(newMaxRows,newMaxColumns);
    nodePairs.setNewMaxSize(newMaxRows,newMaxColumns);
    missingNodePairs.setNewMaxSize(newMaxRows,newMaxColumns);

    //compute linksum
    for(size_t sourceNode = 0; sourceNode < data.getNumberOfRows(); sourceNode++)
    {
        if(!clusteringA_.assigned(sourceNode))
        {
            continue;
        }
        size_t sourceCluster = clusteringA_.getClusterId(sourceNode);

        if(sourceCluster>=linkSum.getRows())
        {
            size_t newMaxRows = std::max(sourceCluster+1,linkSum.getRows()*2);
            size_t newMaxColumns = linkSum.getColumns();
            linkSum.setNewMaxSize(newMaxRows,newMaxColumns);
            nodePairs.setNewMaxSize(newMaxRows,newMaxColumns);
            missingNodePairs.setNewMaxSize(newMaxRows,newMaxColumns);
        }

        for(typename NetworkData<size_t>::iterator iter = data.begin(sourceNode); iter!=data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();


            if(!clusteringB_.assigned(targetNode))
            {
                continue;
            }

            size_t weight = iter.getValue();
            size_t targetCluster = clusteringB_.getClusterId(targetNode);

            if(targetCluster>=linkSum.getColumns())
            {
                size_t newMaxColumns = std::max(targetCluster+1,linkSum.getColumns()*2);
                size_t newMaxRows = linkSum.getRows();
                linkSum.setNewMaxSize(newMaxRows,newMaxColumns);
                nodePairs.setNewMaxSize(newMaxRows,newMaxColumns);
                missingNodePairs.setNewMaxSize(newMaxRows,newMaxColumns);
            }
            linkSum.add(weight, sourceCluster, targetCluster);
        }
    }

    for( Clustering_finite::iterator a_iter = clusteringA_.begin(); a_iter!=clusteringA_.end(); ++a_iter )
    {
        size_t clusterIdFrom = a_iter.index();

        for( Clustering_finite::iterator b_iter = clusteringB_.begin() ; b_iter!=clusteringB_.end() ; b_iter++ )
        {
            size_t clusterIdTo = b_iter.index();

            //between
            size_t nodesInClusterFrom = clusteringA_.getSize(clusterIdFrom);
            size_t nodesInClusterTo = clusteringB_.getSize(clusterIdTo);
            size_t pairs = nodesInClusterFrom*nodesInClusterTo;
            nodePairs.set(pairs,clusterIdFrom,clusterIdTo);
            //nodePairs.matrix[clusterIdFrom*nodePairs.max+clusterIdTo] = pairs;
        }
    }

    //compute missing nodepairs
    if(usemissing_)
    {
        for(size_t sourceNode = 0; sourceNode < data.getNumberOfRows(); sourceNode++)
        {

            if(!clusteringA_.assigned(sourceNode))
            {
                continue;
            }

            size_t sourceCluster = clusteringA_.getClusterId(sourceNode);

            for(typename NetworkData<size_t>::iterator iter = missing.begin(sourceNode); iter!=missing.end(sourceNode) ; iter++)
            {
                size_t targetNode = iter.getTarget();

                if(!clusteringB_.assigned(targetNode))
                {
                    continue;
                }

                size_t targetCluster = clusteringB_.getClusterId(targetNode);
                missingNodePairs.add(iter.getValue(),sourceCluster,targetCluster); //todo verify +1
            }
        }
    }

}






void SbmPoisson_bipartite::moveItem_clustering(std::vector<Data>* data_pointer, size_t itemId, size_t clusterId)
{

    Clustering_finite& clustering_ = (*data_pointer)[0].clustering;
    Clustering_finite& targetClustering_ = (*data_pointer)[0].targetClustering;



    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data = (*data_pointer)[netID];
        size_t currentCluster = clustering_.getClusterId(itemId);

        Matrix<size_t>& links = data.sufstats.nodePairs;           //nodePairs, linkSum, missingNodePairs
        Matrix<size_t>& nonlinks = data.sufstats.linkSum;
        Matrix<size_t>& missinglinks = data.sufstats.missingNodePairs;

        size_t max = links.getColumns();

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data,targetClustering_,currentCluster,max,nodecounts);

        std::vector<size_t>& nodeLinks = nodecounts.nodePairs;              //nodePairs, linkSum, missingNodePairs
        std::vector<size_t>& nodeNonLinks = nodecounts.linkSum;
        std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePairs;

        //remove node from sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.subtract(nodeLinks[c],currentCluster,c);
            nonlinks.subtract(nodeNonLinks[c],currentCluster,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.subtract(nodeMissingLinks[c],currentCluster,c);
            }
        }
        //move node
        currentCluster = clusterId;
        //insert node in sufficient statistics
        for(size_t c = 0; c<links.getColumns(); c++)
        {
            links.add(nodeLinks[c],currentCluster,c);
            nonlinks.add(nodeNonLinks[c],currentCluster,c);
        }
        if(usemissing_)
        {
            for(size_t c = 0; c<links.getColumns(); c++)
            {
                missinglinks.add(nodeMissingLinks[c],currentCluster,c);
            }
        }
    }
    //move the node in the datastructure
    clustering_.moveItem(itemId,clusterId);

}

size_t SbmPoisson_bipartite::getMaxNumberOfClusters(Clustering_finite* clustering_pointer)
{
    if(clustering_pointer == &clusteringDataA)
        return K_classA;
    else if(clustering_pointer == &clusteringDataB)
        return K_classB;
    else
    {
        reportError("error in IrmBernoulli_collapsed_finite_final::getMaxNumberOfClusters_clustering, unknow clustering",1);
    }
};


Clustering_finite* SbmPoisson_bipartite::getDataPointer_clustering(Clustering_finite* clustering_pointer)
{
    return clustering_pointer;
};

size_t SbmPoisson_bipartite::getNumberOfItems_clustering(Clustering_finite* clustering_pointer)
{
    return clustering_pointer->getNumberOfItems();
}

ClusteringDocument SbmPoisson_bipartite::get_clustering(Clustering_finite* clustering_pointer)
{
    size_t K = getK(clustering_pointer);
    return ClusteringDocument(K,*clustering_pointer);
};

void SbmPoisson_bipartite::set_clustering(Clustering_finite* clustering_pointer, ClusteringDocument& cd)
{

    Clustering_finite clustering(cd.numberOfItems,cd.fixedNumberOfComponents,cd.clusteringVector);
    *clustering_pointer = clustering;
    computeAllSufficientStatistics();
};

void SbmPoisson_bipartite::setFromString_clustering(Clustering_finite* clustering_pointer, std::string str)
{
    size_t nocs = getK(clustering_pointer);
    ClusteringDocument cd(nocs,str);
    set_clustering(clustering_pointer,cd);
};


//alpha functions
double SbmPoisson_bipartite::get_alpha(Clustering_finite* clustering_pointer)
{
    return param.getAlpha(clustering_pointer);
}
void SbmPoisson_bipartite::set_alpha(Clustering_finite* clustering_pointer, double val)
{
    param.setAlphaValues(clustering_pointer,val);
}
double SbmPoisson_bipartite::logPosteriorRatio_alpha(Clustering_finite* clustering_pointer,double new_alpha)
{
    double old_alpha = get_alpha(clustering_pointer);
    double P0 = computeLogPrior();
    set_alpha(clustering_pointer,new_alpha);
    double P1 = computeLogPrior();
    set_alpha(clustering_pointer,old_alpha);
    return P1-P0;
}

//bp functions
double SbmPoisson_bipartite::get_a()
{
    double& a_ = param.a_;
    return a_;
}

void SbmPoisson_bipartite::set_a(double val)
{
    double& a_ = param.a_;
    a_ = val;
}

double SbmPoisson_bipartite::logPosteriorRatio_a(double new_a)
{
    if (new_a <= 0) return -9999999999999999;
    double old_a = a.get();
    double L0 = computeLogLikelihood();
    a.set(new_a);
    double L1 = computeLogLikelihood();
    a.set(old_a);
    return L1-L0;
}


double SbmPoisson_bipartite::get_a_vector(size_t clusterId_classB)
{
   return param.a_values[clusterId_classB];
}
void SbmPoisson_bipartite::set_a_vector(size_t clusterId_classB, double val)
{
    param.a_values[clusterId_classB] = val;
}
double SbmPoisson_bipartite::logPosteriorRatio_a_vector(size_t clusterId_classB, double new_a)
{
    if (new_a <= 0) return -9999999999999999;
    double old_a = get_a_vector(clusterId_classB);
    double L0 = computeLogLikelihood();
    set_a_vector(clusterId_classB, new_a);
    double L1 = computeLogLikelihood();
    set_a_vector(clusterId_classB, old_a);
    return L1-L0;
}


//bm functions
double SbmPoisson_bipartite::get_b()
{
    double& b_ = param.b_;
    return b_;
}

void SbmPoisson_bipartite::set_b(double val)
{
    double& b_ = param.b_;
    b_ = val;
}

double SbmPoisson_bipartite::logPosteriorRatio_b(double new_b)
{
    if (new_b <= 0) return -9999999999999999;
    double old_b = b.get();
    double L0 = computeLogLikelihood();
    b.set(new_b);
    double L1 = computeLogLikelihood();
    b.set(old_b);
    return L1-L0;
}


double SbmPoisson_bipartite::get_b_vector(size_t clusterId_classB)
{
   return param.b_values[clusterId_classB];
}
void SbmPoisson_bipartite::set_b_vector(size_t clusterId_classB, double val)
{
    param.b_values[clusterId_classB] = val;
}
double SbmPoisson_bipartite::logPosteriorRatio_b_vector(size_t clusterId_classB, double new_b)
{
    if (new_b <= 0) return -9999999999999999;
    double old_b = get_b_vector(clusterId_classB);
    double L0 = computeLogLikelihood();
    set_b_vector(clusterId_classB, new_b);
    double L1 = computeLogLikelihood();
    set_b_vector(clusterId_classB, old_b);
    return L1-L0;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double SbmPoisson_bipartite::logPrior_effectiveChange(Clustering_finite& clustering, size_t cluster, size_t currentCluster, size_t currentClusterSize)
{
    Clustering_finite& clustering_ = clustering;

    double dp = 0;
    if(cluster != currentCluster)
    {
        dp = log(clustering_.getSize(cluster));
    }
    else
    {
        if(currentClusterSize>1)
            dp = log(currentClusterSize-1);
    }
    return dp;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to a new cluster
**/
inline double SbmPoisson_bipartite::logPrior_effectiveChange_newCluster(Clustering_finite& clustering)
{
    const double alpha_ = param.getAlpha(&clustering);
    return log(alpha_);
}



/**
*** compute the effective change for the log_likelihood when moving node nodeId from currentCluster to a new cluster
**/
inline double SbmPoisson_bipartite::logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{

    double a_ = param.a_;
    double b_ = param.b_;

    std::vector<size_t>& nodeLinks = nodecounts.linkSum;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodePairs;
    std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePairs;

    double loglik = 0;


    for(Clustering_finite::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
    {
        size_t t = targetiter.index();

        if(independentAB)
        {
            a_ = param.getA(t);
            b_ = param.getB(t);
        }

        loglik += FUNC( nodeLinks[t], a_, nodeNonLinks[t] - nodeMissingLinks[t], b_);
        loglik -= FUNC( 0, a_, 0, b_);
    }
    return loglik;
}




/**
*** compute the change in log_loglikelihood when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double SbmPoisson_bipartite::logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering_finite& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts)
{
    double a_ = param.a_;
    double b_ = param.b_;

    Matrix<size_t>& links = data_.sufstats.linkSum;
    Matrix<size_t>& nonlinks = data_.sufstats.nodePairs;
    Matrix<size_t>& missinglinks = data_.sufstats.missingNodePairs;

    std::vector<size_t>& nodeLinks = nodecounts.linkSum;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodePairs;
    std::vector<size_t>& nodeMissingLinks = nodecounts.missingNodePairs;

    const size_t c = cluster;

    if(c == currentCluster)
    {

        double d_loglikelihood = 0;
        for(Clustering_finite::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
        {
            size_t l = targetiter.index();

            if(independentAB)
            {
                a_ = param.getA(l);
                b_ = param.getB(l);
            }

            //const size_t r_nl = nodeLinks[l];               //links from node to cluster l
            //const size_t rn_nl = nodeNonLinks[l];
            //const size_t rm_nl = nodeMissingLinks[l];

            const double linkcount = links.get(c,l) - nodeLinks[l];
            const double nonlinkcount = nonlinks.get(c,l) - nodeNonLinks[l] - ( missinglinks.get(c,l) - nodeMissingLinks[l] );

            d_loglikelihood += FUNC( linkcount + nodeLinks[l], a_, nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , b_ );
            d_loglikelihood -= FUNC( linkcount, a_, nonlinkcount, b_ );

            //without missing
            //d_loglikelihood += betaln_table.betaln( links.get(c,l), a, nonlinks.get(c,l), b );
            //d_loglikelihood -= betaln_table.betaln( links.get(c,l)-nodeLinks[l], a, nonlinks.get(c,l)-nodeNonLinks[l] - (missinglinks.get(c,l) - nodeMissingLinks[l]), b );

        }
        return d_loglikelihood;
    }
    else
    {
        double d_loglikelihood = 0;
        for(Clustering_finite::iterator targetiter = data_.targetClustering.begin() ; targetiter!=data_.targetClustering.end() ; ++targetiter)
        {
            size_t l = targetiter.index();

            if(independentAB)
            {
                a_ = param.getA(l);
                b_ = param.getB(l);
            }

            //const size_t r_nl = nodeLinks[l];               //links from node to cluster l
            //const size_t rn_nl = nodeNonLinks[l];
            //const size_t rm_nl = nodeMissingLinks[l];


            const double linkcount = links.get(c,l);
            const double nonlinkcount = nonlinks.get(c,l) - missinglinks.get(c,l);
            d_loglikelihood += FUNC( linkcount + nodeLinks[l], a_ , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , b_ );
            d_loglikelihood -= FUNC( linkcount , a_ , nonlinkcount , b_ );

            //without missing
            //d_loglikelihood += betaln_table.betaln( links.get(c,l)+nodeLinks[l], a, nonlinks.get(c,l)+nodeNonLinks[l], b );
            //d_loglikelihood -= betaln_table.betaln( links.get(c,l), a, nonlinks.get(c,l), b );
        }
        return d_loglikelihood;
    }
}






const std::string MixturePoisson_collapsed_finite::MODELNAME = "mixturePoisson_finite";

const ModelDescription MixturePoisson_collapsed_finite::modelDescription("poisson mixture model","finite","");

const std::vector<SettingDescription> MixturePoisson_collapsed_finite::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items1","INT",true).min(1).max(1000000).shortDescription("Number of nodes in class1 of the network").longDescription("The number of nodes in class1 of the network")   },
    {   SettingDescription("components1","INT",true).min(1).max(10000).shortDescription("Number of components in the clustering of group 1").longDescription("The maximal allowed number of components in the clustering of group 1")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("bp.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bp")   },
    {   SettingDescription("bm.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bm")   },
    {   SettingDescription("alpha1.init","FLOAT",false).initialFloat(1).shortDescription("Intitial value of alpha for clustering of group 1") },
    {   SettingDescription("clustering1.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes in group 1").longDescription("Initial number of components, the nodes are randomny split into")    }
};

const std::vector<ParameterDescription> MixturePoisson_collapsed_finite::parameterDescriptions
{
    {   ParameterDescription("clustering1","INFINITE_CLUSTERING").shortDescription("clustering1 parameter").longDescription("")    },
    {   ParameterDescription("alpha1","REAL").shortDescription("concentration parameter for clustering of group 1").longDescription("")    },
    {   ParameterDescription("a","REAL").shortDescription("a hyperparameter").longDescription("")    },
    {   ParameterDescription("b","REAL").shortDescription("b hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, MixturePoisson_collapsed_finite> MixturePoisson_collapsed_finite::Create(MixturePoisson_collapsed_finite::MODELNAME);

