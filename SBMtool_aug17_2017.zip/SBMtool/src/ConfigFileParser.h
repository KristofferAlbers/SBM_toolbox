/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
This code is provided as is without any warranty!

An object of the ConfigFileParser is used to parse user supplied
configuration files into sets of user options that can be interpreted
internally. From a correctly formatted configuration file, the options
for scheduler, model and samplers are identified, separated and parsed
into data structures.
*/

#ifndef CONFIGFILEPARSER_H_INCLUDED
#define CONFIGFILEPARSER_H_INCLUDED

#include <boost/algorithm/string.hpp>
#include <boost/foreach.hpp>


class ConfigFileParser
{
public:
    std::map<std::string,std::string> variables;

    //data structure to represent a line in the configuration file
    struct line
    {
        std::string name;
        std::string val;
        bool hasvalue;
        bool beginOf;
        bool endOf;
        bool valueIsFile;
    };

    //data structure to represent a particular set of options
    //(by name and value) read from the configuration file
    struct configsettings
    {
        std::string type;
        std::string parameter;
        std::vector<std::string> optionNames;
        std::vector<std::string> optionValues;
    };

    std::ifstream file;
    std::vector<line> lines;
    size_t lineInPlines = 0;
    inline line getPLine()
    {
        return lines[lineInPlines++];
    }

    configsettings model;
    configsettings scheduler;
    std::vector<configsettings> mcmcsamplers;
    std::vector<configsettings> maxsamplers;

    ConfigFileParser(std::string configfilename) : file(configfilename.c_str())
    {
        loadConfigFile();
        //parse file
        const std::string MODEL_STR("model");   //to identify options associated with the model
        const std::string SCHEDULER_STR("scheduler");   //to identify options associated with the scheduler
        const std::string MCMCSAMPLER_STR("mcmcsampler");   //to identify options associated with mcmc samplers
        const std::string MAXSAMPLER_STR("maxsampler"); //to identify options associated with map samplers

        while( lineInPlines<lines.size() )
        {
            line pl = getPLine();
            if(!pl.hasvalue)
            {
                std::vector<std::string> substrings;
                boost::split(substrings,pl.name,boost::is_any_of("()")); //remove comments

                if(substrings.size()<2)
                {
                     std::cout << "ERROR: in config file." << std::endl;
                    exit(0);
                }

                configsettings* configs;
                //parse model
                if(substrings[0] == MODEL_STR)
                {
                    model.type = substrings[1];
                    configs = &model;
                }
                else if(substrings[0] == MCMCSAMPLER_STR)
                {
                    mcmcsamplers.emplace_back(configsettings());
                    configs = &mcmcsamplers[mcmcsamplers.size()-1];
                    boost::trim(substrings[1]);
                    configs->type = substrings[1];
                }
                else if(substrings[0] == MAXSAMPLER_STR)
                {
                    maxsamplers.emplace_back(configsettings());
                    configs = &maxsamplers[maxsamplers.size()-1];
                    boost::trim(substrings[1]);
                    configs->type = substrings[1];
                }
                else if(substrings[0] == SCHEDULER_STR)
                {
                    configs = & scheduler;
                    boost::trim(substrings[1]);
                    configs -> type = substrings[1];
                }

                while( lineInPlines<lines.size() )
                {
                    line pl = getPLine();
                    if(pl.hasvalue)
                    {
                        if(pl.name == "parameter")
                        {
                            configs->parameter = pl.val;
                        }
                        else
                        {
                            configs->optionNames.push_back(pl.name);
                            configs->optionValues.push_back(pl.val);
                        }

                    }
                    else
                    {
                        lineInPlines--;
                        break;
                    }
                }
            }
        }
    }



	void loadConfigFile()
	{
		std::string line;
		while (std::getline(file, line))
		{
                addConfigLine(line);
		}
    }


    void addConfigLine(std::string line)
    {
        boost::trim(line);
        //ignore empty lines
        if (line.compare(std::string("")) == 0)
        {
            return;
        }
        //ignore commented lines (line is known not empty)
        if(line.at(0) == '%')
        {
            return;
        }

        if(line.at(0) == '#')
        {
            //add as variable

            std::vector<std::string> substrings;
            boost::split( substrings, line, boost::is_any_of("=") );
            if(substrings.size()<2)
            {
                std::cout << "ERROR: in config file, a variable has no value." << std::endl;
                exit(0);
            }
            std::string variable_name = substrings[0];
            std::string variable_string = substrings[1];
            boost::trim(variable_name);
            boost::trim(variable_string);

            variable_string = getValue(variable_string);

            variables[variable_name] = variable_string;
            return;
        }

        boost::trim_left(line);
        std::vector<std::string> substrings;
        boost::split( substrings, line, boost::is_any_of("=") );
        if(substrings.size()>1)
        {
            if(substrings[1].compare(std::string(""))==0)
            {
                std::cout << "ERROR: parsing config file line '" << line << "'" << std::endl;
                exit(0);
            }

            std::string name = substrings[0];
            boost::split(substrings,substrings[1],boost::is_any_of("%")); //remove comments
            std::string value = substrings[0];
            boost::trim(name);
            boost::trim(value);

            value = getValue(value);
            lines.push_back({name,value,true,false,false,false});

        }
        else
        {
            boost::trim(substrings[0]);
            bool beginParan = (substrings[0].compare(std::string("{"))==0);
            bool endParan = (substrings[0].compare(std::string("}"))==0);

            lines.push_back({substrings[0],std::string(""),false,beginParan,endParan,false});
        }

    }

    std::string getValue(std::string value)
    {
         //value is a variable
        if(value.at(0) == '#')
        {
            std::map<std::string,std::string>::iterator it = variables.find(value);
            if(it!=variables.end())
            {
                value = variables[value];
            }
            else
            {
                std::cout << "ERROR: in config file, a variable has no value." << std::endl;
                exit(0);
            }
        }
        //if value is in quatations, the value comes from a file!
        std::vector<std::string> substrings;
        boost::split(substrings,value,boost::is_any_of("'\""));


        if(substrings.size()==3)
        {
            //read file
            std::ifstream file_(substrings[1].c_str());
            std::string file_content;
            std::getline(file_, file_content);

            value = file_content;
        }
        else if(substrings.size()==2)
        {
                std::cout << "ERROR: in config file, parsing value '" << value << "'" << std::endl;
                exit(0);
        }
        else
        {

        }
        return value;

    }

};


#endif // CONFIGFILEPARSER_H_INCLUDED
