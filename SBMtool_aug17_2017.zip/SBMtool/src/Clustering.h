/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
An object of class Clustering_finite is a performance optimized
representation of a clustering with an undefined (infinite) number of clusters.
It implements two sequence iteratiors:
    - for iterating over all clusters
    - for iterationg over all nodes assigned to a given cluster
It utilizes the partial_vector container to represent lists of clusterings
and lists of clusters.
*/

#ifndef CLUSTERING_H_INCLUDED
#define CLUSTERING_H_INCLUDED

#include "partial_vector.h"

#include <boost/units/detail/utility.hpp>
#include <typeinfo>
#include <sstream>
#include <iostream>
#include <vector>


class Clustering
{
public:
    struct clusterIdPos
    {
        size_t clusterId, clusterPos;
    };
    friend class ClusteringDocument;
private:
    partial_vector<clusterIdPos> items;
    partial_vector<partial_vector<size_t>> clusters;

public:
    Clustering() {};

    Clustering(std::vector<size_t>& clusteringVector)
    {
        for(size_t i = 0; i<clusteringVector.size(); i++)
        {
            addItem_force(i,clusteringVector[i]);
        }
    };

    virtual ~Clustering()
    {
       // std::cout << " clustering  destroyed " << std::endl;
    }

    void addItem(size_t itemId, size_t clusterId);
    size_t addItem(size_t itemId);
    void addItem_force(size_t itemId, size_t clusterId);
    void removeItem(size_t itemId);
    void moveItem(size_t itemId, size_t clusterId);
    void removeCluster(size_t clusterId);

    size_t getClusterId(size_t itemId);
    bool exist(size_t clusterId);
    bool assigned(size_t itemId);
    size_t getSize(size_t clusterId);

    size_t getNumberOfClusters();
    size_t getNumberOfItems();
    void pack();

    friend std::ostream& operator<<(std::ostream&, Clustering&);
    std::string toString();


    class iterator;
    iterator begin();
    iterator end();

    class clusterIterator;
    clusterIterator begin(size_t clusterId);
    clusterIterator end(size_t clusterId);

};

inline std::ostream& operator<<(std::ostream& os, const Clustering::clusterIdPos& c)
{
    os << c.clusterId << "." << c.clusterPos;
    return os;
}

inline std::string Clustering::toString()
{
    std::stringstream s;
    for (size_t i = 0; i != getNumberOfItems(); ++i)
    {
        s << items[i].clusterId << " ";
    }
    return s.str();
}


// Add a new item into a cluster. If the specified cluster does not exists,
// it is created.
inline void Clustering::addItem_force(size_t itemId, size_t clusterId)
{

    assert(!items.exist(itemId));
    if(clusters.exist(clusterId))
    {
        addItem(itemId, clusterId);
    }
    else
    {
        partial_vector<size_t> newCluster;
        size_t newPos = newCluster.push(itemId);
        clusters.set(clusterId,newCluster);
        items.set(itemId, {clusterId, newPos});

        for(size_t i=0; i<clusters.unused_.size();i++)
        {//hack!
            if(clusters.unused_[i] == clusterId)
                clusters.unused_.erase(clusters.unused_.begin()+i);
        }
    }

}

// Add a new item into an existing cluster
inline void Clustering::addItem(size_t itemId, size_t clusterId)
{
    assert(clusters.exist(clusterId));
    assert(!items.exist(itemId));

    size_t newPos = clusters[clusterId].push(itemId);
    items.set(itemId, {clusterId, newPos});
}

// Add a new item into a new cluster
inline size_t Clustering::addItem(size_t itemId)
{
    partial_vector<size_t> newCluster;
    size_t newPos = newCluster.push(itemId);
    size_t clusterId = clusters.push(newCluster);
    items.set(itemId, {clusterId, newPos});

    return clusterId;
}

// Removes an item from its cluster, possibly deleting the cluster if it is empty
inline void Clustering::removeItem(size_t itemId)
{
    size_t clusterId = items[itemId].clusterId;
    size_t clusterPos = items[itemId].clusterPos;
    clusters[clusterId].erase(clusterPos);
    if (clusters[clusterId].size() == 0)
    {
        clusters.erase(clusterId);
    }
    items.erase(itemId);
}

// Moves an item into an existing cluster
inline void Clustering::moveItem(size_t itemId, size_t clusterId)
{
    assert(clusters.exist(clusterId));
    assert(items.exist(itemId));

    size_t oldClusterId = items[itemId].clusterId;
    if (clusterId != oldClusterId)
    {
        size_t oldClusterPos = items[itemId].clusterPos;
        clusters[oldClusterId].erase(oldClusterPos);
        if (clusters[oldClusterId].size() == 0)
        {
            clusters.erase(oldClusterId);
        }
        size_t clusterPos = clusters[clusterId].push(itemId);
        items[itemId].clusterId = clusterId;
        items[itemId].clusterPos = clusterPos;
    }
}

// Removes a cluster
inline void Clustering::removeCluster(size_t clusterId)
{
    for (auto i = clusters[clusterId].begin(); i != clusters[clusterId].end(); ++i)
    {
        items.erase(*i);
    }
    clusters.erase(clusterId);
}

//Returns the current number of clusters
inline size_t Clustering::getNumberOfClusters()
{
    return clusters.size();
}

//Returns true if the cluster exists
inline bool Clustering::exist(size_t clusterId)
{
    return clusters.exist(clusterId);
}

//Returns the number of items
inline size_t Clustering::getNumberOfItems()
{
    return items.size();
}

//Returns true if the item is currently assigned to a cluster
inline bool Clustering::assigned(size_t itemId)
{
    return(items.exist(itemId));
}

//Returns the number of elements in the particular cluster
inline size_t Clustering::getSize(size_t clusterId)
{
    assert(clusters.exist(clusterId));
    return clusters[clusterId].size();
}



inline void Clustering::pack()
{
    for (auto c = clusters.begin(); c != clusters.end(); ++c)
    {
        size_t clusterId = c.index();
        partial_vector<size_t> newItems;
        for (auto i = c->begin(); i != c->end(); ++i)
        {
            size_t itemId = *i;
            size_t itemPos = newItems.push(itemId);
            items.set(itemId, {clusterId, itemPos});
        }
        clusters.set(clusterId, newItems);
    }
}


inline size_t Clustering::getClusterId(size_t itemId)
{
    assert(items.exist(itemId));
    return(items[itemId].clusterId);
}


inline std::ostream& operator<<(std::ostream& os, Clustering& c)
{

    std::cout << "Clustering (N=" << c.clusters.size() << "):" << std::endl;
    for (auto i = c.clusters.begin(); i != c.clusters.end(); ++i)
    {
        os << "  " << i.index() << " (n=" << i->size() << "): ";
        for (auto j = i->begin(); j != i->end(); ++j)
        {
            if (j != i->begin()) os << ", ";
            os << *j;
        }
        os << std::endl;
    }
    std::cout << "Items (K=" << c.items.size() << "):" << std::endl;
    for (auto i = c.items.begin(); i != c.items.end(); ++i)
    {
        os << "  " << i.index() << ": " << i->clusterId << "." << i->clusterPos << std::endl;
    }
    std::cout << " unused clusers (deque):" << std::endl;
    for(size_t i = 0; i<c.clusters.unused_.size();i++)
    {
        std::cout << c.clusters.unused_[i] << " ";
    }
    std::cout << std::endl;

    return os;
}






//-----------------------------------------------------------------------------
// clustering::iterator implementation
// Iterates all clusters.
// The function index() gives the clusterId of the current cluster in the iteration step.
// Dereferencing gives a pointer to the partial_vector storing the itemId for the given cluster.
class Clustering::iterator : public std::iterator<std::forward_iterator_tag,partial_vector<size_t>>
{
private:
    partial_vector<partial_vector<size_t>>* clusters_;
    typename partial_vector<partial_vector<size_t>>::iterator it_;

public:

    iterator() {};
    iterator(const iterator& other) : clusters_(other.clusters_), it_(other.it_) {};
    iterator(partial_vector<partial_vector<size_t>>& clusters) : clusters_(&clusters) {};
    iterator(partial_vector<partial_vector<size_t>>& clusters, typename partial_vector<partial_vector<size_t>>::iterator it) : clusters_(&clusters), it_(it) {};


    inline iterator& operator=(const iterator& other)
    {
        it_ = other.it_;
        clusters_ = other.clusters_;
        return *this;
    }


    inline iterator& operator++()
    {
        ++it_;
        return *this;
    };

    inline iterator operator++(int)
    {
        iterator temp(*this);
        operator++();
        return temp;
    }

    inline bool operator!=(const iterator other)
    {
        return it_ != other.it_;
    };
    inline bool operator==(const iterator other)
    {
        return it_ == other.it_;
    }

    inline partial_vector<size_t>& operator*()
    {
        return *it_;
    };

    inline partial_vector<size_t>* operator->()
    {
        return &(*it_);
    }


    inline size_t index()
    {
        return it_.index();
    }

};




inline Clustering::iterator Clustering::begin()
{
    return iterator(clusters,clusters.begin());
};

inline Clustering::iterator Clustering::end()
{
    return iterator(clusters,clusters.end());
};





//-----------------------------------------------------------------------------
// clustering::clusterIterator implementation
// Iterates all items assigned to a given cluster.
// Dereferencing gives the itemId.
class Clustering::clusterIterator : public std::iterator<std::forward_iterator_tag,std::vector<size_t>>
{
private:
    partial_vector<size_t>* cluster_;
    typename partial_vector<size_t>::iterator it_;

public:

    clusterIterator() {};
    clusterIterator(const clusterIterator& other) : cluster_(other.cluster_), it_(other.it_) {};
    clusterIterator(partial_vector<size_t>& cluster) : cluster_(&cluster) {};
    clusterIterator(partial_vector<size_t>& cluster, typename partial_vector<size_t>::iterator it) : cluster_(&cluster), it_(it) {};

    inline clusterIterator& operator++()
    {
        ++it_;
        return *this;
    };

    inline clusterIterator operator++(int)
    {
        clusterIterator temp(*this);
        operator++();
        return temp;
    }

    inline bool operator!=(const clusterIterator other)
    {
        return it_ != other.it_;
    };
    inline bool operator==(const clusterIterator other)
    {
        return it_ == other.it_;
    }

    inline size_t& operator*()
    {
        return *it_;
    };

    inline size_t* operator->()
    {
        return &(*it_);
    }


    inline size_t getItemId()
    {
        return *it_;
    }
    inline size_t index()
    {
        return it_.index();
    }



};

//returns a clusterIterator for the start of a single cluster
inline Clustering::clusterIterator Clustering::begin(size_t clusterId)
{
    assert(clusters.exist(clusterId));
    partial_vector<size_t>::iterator iter = clusters[clusterId].begin();
    return clusterIterator(clusters[clusterId],iter);
}
//returns a clusterIterator for the end of a single cluster
inline Clustering::clusterIterator Clustering::end(size_t clusterId)
{
    assert(clusters.exist(clusterId));
    partial_vector<size_t>::iterator iter = clusters[clusterId].end();
    return clusterIterator(clusters[clusterId],iter);
}
















#endif // CLUSTERING_H_INCLUDED
