/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
Defines global functions, (implemented in the main.cpp file).
These are used to report errors, warnings and infomation while
running the application. According to the reported level of
criticality of the information, the application can act
appropriately.
*/

#ifndef MY_FOO_HEADER_
#define MY_FOO_HEADER_

#include <iostream>
#include <string>

    int reportError(std::string error_string,double criticality);
    int reportError(std::string error_title,std::string error_string,double criticality);

    int reportWarning(std::string warning_string,double criticality);
    int reportWarning(std::string warning_title,std::string warning_string,double criticality);

    int reportInfo(std::string info_string);
    int reportInfo(std::string info_string,double criticality);
    int reportInfo(std::string info_title,std::string info_string,double criticality);



#endif
