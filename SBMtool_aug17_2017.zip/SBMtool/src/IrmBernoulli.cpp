/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "IrmBernoulli.h"

const std::string IrmBernoulli::MODELNAME = "IrmBernoulli";

const ModelDescription IrmBernoulli::modelDescription("IrmBern","infinite, unipartite","irm model with bernoulli likelihood and beta prior");

const std::vector<SettingDescription> IrmBernoulli::settingDescriptions
{
    {   SettingDescription("network.links","FILEPATH",true).shortDescription("File containing the links in the network").longDescription("file containing all links observed in the network")    },
    {   SettingDescription("network.missinglinks","FILEPATH",false).shortDescription("File containing missing links in the network").longDescription("file containing all unobserved (missing) links in the network")    },
    {   SettingDescription("directed","BOOL",false).initialBool(false).shortDescription("Indicate if network is directed").longDescription("Define whether the network is directed (true) or undirected (false)")    },
    {   SettingDescription("withmissing","BOOL",false).initialBool(false).shortDescription("Indicate to use missing links").longDescription("Define whether information about missing data should be included in inference")    },
    {   SettingDescription("items","INT",true).min(1).max(1000000).shortDescription("Number of nodes in the network").longDescription("The number of nodes in the network")   },
    {   SettingDescription("subjects","INT",true).min(1).max(10000).shortDescription("Number of subjects collapsed in the network").longDescription("The number of subjects collapsed into the network")   },
    {   SettingDescription("bp.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bp")   },
    {   SettingDescription("bm.init","FLOAT",false).initialFloat(1.0).min(0).shortDescription("Intitial value of bm")   },
    {   SettingDescription("alpha.init","FLOAT",false).initialFloat(1.0).shortDescription("Intitial value of alpha") },
    {   SettingDescription("clustering.init_crp","FLOAT",false).initialFloat(1).min(0).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes, according to CRP").longDescription("Concentration parameter of the generating CRP")  },
    {   SettingDescription("clustering.init_random","INT",false).initialInt(1).min(1).max(100000).mutualExclusiveGroup("INIT_CLUSTERING").shortDescription("Intitial partition of nodes").longDescription("Initial number of components, the nodes are randomny split into")    }
};

const std::vector<ParameterDescription> IrmBernoulli::parameterDescriptions
{
    {   ParameterDescription("clustering","INFINITE_CLUSTERING").shortDescription("clustering parameter").longDescription("")    },
    {   ParameterDescription("alpha","REAL").shortDescription("concentration parameter").longDescription("")    },
    {   ParameterDescription("bp","REAL").shortDescription("link-count hyperparameter").longDescription("")    },
    {   ParameterDescription("bm","REAL").shortDescription("nonlink-count hyperparameter").longDescription("")    }
};

Creator<StatisticalModel, IrmBernoulli> IrmBernoulli::Create(IrmBernoulli::MODELNAME);


void IrmBernoulli::getNodeCounts(size_t nodeId, Data& data_, Clustering& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts)
{

    nodecounts.nodeLinks.clear();
    nodecounts.nodeLinks.resize(max);

    nodecounts.nodeNonLinks.clear();
    nodecounts.nodeNonLinks.resize(max);

    nodecounts.nodeMissingLinks.clear();
    nodecounts.nodeMissingLinks.resize(max);


    if(directed)
    {
        nodecounts.nodeLinks_transposed.resize(max);
        nodecounts.nodeLinks_transposed.clear();
        nodecounts.nodeNonLinks_transposed.resize(max);
        nodecounts.nodeNonLinks_transposed.clear();
        nodecounts.nodeMissingLinks_transposed.resize(max);
        nodecounts.nodeMissingLinks_transposed.clear();

        for(size_t c = 0 ; c< max; c++)
        {
            if(clustering_.exist(c))
            {
                nodecounts.nodeNonLinks[c] = numSubjects*clustering_.getSize(c);
                nodecounts.nodeNonLinks_transposed[c] = numSubjects*clustering_.getSize(c);
            }

        }
        nodecounts.nodeNonLinks[currentCluster]-=numSubjects;
        nodecounts.nodeNonLinks_transposed[currentCluster]-=numSubjects;
    }
    else
    {
        for(size_t c = 0 ; c< max; c++)
        {
            if(clustering_.exist(c))
                nodecounts.nodeNonLinks[c] = numSubjects*clustering_.getSize(c);

        }
        nodecounts.nodeNonLinks[currentCluster]-=numSubjects;
    }


    for(NetworkData<size_t>::iterator iter = data_.data.begin(nodeId) ; iter!=data_.data.end(nodeId) ; ++iter)
    {
        size_t itemId = iter.getTarget();
        size_t clusterId = clustering_.getClusterId(itemId);
        nodecounts.nodeLinks[clusterId]+=iter.getValue();
        nodecounts.nodeNonLinks[clusterId]-=iter.getValue();
    }


    if(directed)
    {

        for(NetworkData<size_t>::iterator iter = data_.data_transposed.begin(nodeId) ; iter!=data_.data_transposed.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.nodeLinks_transposed[clusterId]+=iter.getValue();
            nodecounts.nodeNonLinks_transposed[clusterId]-=iter.getValue();
        }
    }

    if(usemissing_)
    {
        for(NetworkData<size_t>::iterator iter = data_.missing.begin(nodeId) ; iter!=data_.missing.end(nodeId) ; ++iter)
        {
            size_t itemId = iter.getTarget();
            size_t clusterId = clustering_.getClusterId(itemId);
            nodecounts.nodeMissingLinks[clusterId]+=iter.getValue();
        }
        if(directed)
        {
            for(NetworkData<size_t>::iterator iter = data_.missing_transposed.begin(nodeId) ; iter!=data_.missing_transposed.end(nodeId) ; ++iter)
            {
                size_t itemId = iter.getTarget();
                size_t clusterId = clustering_.getClusterId(itemId);
                nodecounts.nodeMissingLinks_transposed[clusterId]+=iter.getValue();
            }
        }

    }

}



double IrmBernoulli::computeLogLikelihood()
{
    double likelihood = 0;
    for(size_t netID = 0 ;netID < networks.size(); netID++)
    {
        likelihood += computeLogLikelihood(data[netID],clusteringData);
    }
    return likelihood;
}


double IrmBernoulli::computeLogLikelihood(Data& data_, Clustering& clustering_)
{
    double& bp_ = param.bp_;
    double& bm_ = param.bm_;


    double value = 0;
    Clustering::iterator iter = clustering_.begin();
    Clustering::iterator iter_end = clustering_.end();

    if(!directed)
    {
        for( ; iter!=iter_end ; ++iter )
        {
            size_t clusterId = iter.index();
            Clustering::iterator iter2 = clustering_.begin();
            for( ; iter2!=iter_end ; iter2++ )
            {
                size_t clusterId2 = iter2.index();
                if(clusterId<=clusterId2)
                {
                    value+= betaln_table.betaln(data_.sufstats.getLinkCount(clusterId,clusterId2), bp_  , data_.sufstats.getNonLinkCount(clusterId,clusterId2) - data_.sufstats.getMissingLinkCount(clusterId,clusterId2), bm_ );
                    value+= - betaln_table.betaln(0,bp_, 0,bm_);
                }
            }
        }
    }
    else //if directed
    {
        for( ; iter!=iter_end ; ++iter )
        {
            size_t c1 = iter.index();
            Clustering::iterator iter2 = clustering_.begin();
            for( ; iter2!=iter_end ; iter2++ )
            {
                size_t c2 = iter2.index();
                value+=   betaln_table.betaln(data_.sufstats.getLinkCount(c1,c2), bp_  , data_.sufstats.getNonLinkCount(c1,c2) - data_.sufstats.getMissingLinkCount(c1,c2), bm_ );
                value+= - betaln_table.betaln(0,bp_, 0,bm_);
            }
        }
    }
    return value;
}

double IrmBernoulli::computeLogPrior()
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;


    const size_t noc = clustering_.getNumberOfClusters();
    const size_t J = clustering_.getNumberOfItems();

    double logprior = noc * logalpha_;
    logprior += lgamma(alpha_);
    logprior -= lgamma(J+alpha_);

    for(Clustering::iterator iter = clustering_.begin() ; iter!= clustering_.end(); ++iter )
    {
        logprior += lgamma(clustering_.getSize(iter.index()));
    }
    //logprior -= logalpha_;
    return logprior * networks.size();
}

double IrmBernoulli::computeLogPosterior()
{
    return computeLogPrior()+computeLogLikelihood();
}





partial_vector<double> IrmBernoulli::effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters)
{

    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.links.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    NodeCounts<size_t> nodecounts;

    partial_vector<double> logps;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];

        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        for(std::vector<size_t>::iterator itouter = restrictedClusters.begin() ; itouter!=restrictedClusters.end() ; ++itouter)
        {
            size_t cluster = *itouter;
            double dlikelihood  = 0;
            double dprior = 0;

            if(!clustering_.exist(cluster) || (cluster == currentCluster && currentClusterSize == 1) )
            {
                dlikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data_,clustering_,param,currentCluster,currentClusterSize,nodecounts);
                dprior = logPrior_effectiveChange_newCluster(nodeId,currentCluster,currentClusterSize,nodecounts);
            }
            else
            {
                dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
                dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);
            }
            if(logps.exist(cluster))
            {
               logps[cluster] += dprior+dlikelihood;
            }
            else
            {
                logps.set(cluster,dprior+dlikelihood);
            }
        }
    }
    return logps;
}


double IrmBernoulli::effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster,bool emptyCluster)
{
    std::vector<Data>& dataVector = *data_pointer;
    NodeCounts<size_t> nodecounts;
    double loglike = 0;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data = dataVector[netID];
        Clustering& clustering_ = clusteringData;
        size_t max = data.sufstats.links.max;
        size_t currentCluster = clustering_.getClusterId(nodeId);
        size_t currentClusterSize = clustering_.getSize(currentCluster);

        getNodeCounts(nodeId,dataVector[netID], clustering_, currentCluster,max,nodecounts);

        if(!emptyCluster)
        {
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            loglike += dlikelihood;
        }
        else
        {
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data,clustering_,param,currentCluster,currentClusterSize,nodecounts);

            loglike+=loglikelihood;
        }
    }
    return loglike;
}



partial_vector<double> IrmBernoulli::effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster)
{

    Clustering& clustering_ = clusteringData;

    size_t max = data[0].sufstats.links.max;
    size_t currentCluster = clustering_.getClusterId(nodeId);
    size_t currentClusterSize = clustering_.getSize(currentCluster);

    partial_vector<double> logps;

    NodeCounts<size_t> nodecounts;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        Data& data_ = data[netID];
        getNodeCounts(nodeId,data[netID], clustering_, currentCluster,max,nodecounts);
        //existing clusters
        Clustering::iterator outerIter;
        for(outerIter = begin ; outerIter!=end; ++outerIter)
        {
            size_t cluster = outerIter.index();
            double dlikelihood = logLikelihood_effectiveChange(nodeId,data_,clustering_,param,cluster,currentCluster,currentClusterSize,nodecounts);
            double dprior = logPrior_effectiveChange(nodeId,cluster,currentCluster,currentClusterSize,nodecounts);

            if(cluster != currentCluster || currentClusterSize>1)
            {
                if(logps.exist(cluster))
                {
                   logps[cluster] += dprior+dlikelihood;
                }
                else
                {
                    logps.set(cluster,dprior+dlikelihood);
                }
            }
        }
        //new cluster
        if(appendForNewCluster)
        {
            double logprior = logPrior_effectiveChange_newCluster(nodeId,currentCluster,currentClusterSize,nodecounts);
            double loglikelihood = logLikelihood_effectiveChange_newCluster(nodeId,data_,clustering_,param,currentCluster,currentClusterSize,nodecounts);
            if(logps.exist(max))
            {
               logps[max] += logprior+loglikelihood;
            }
            else
            {
                logps.set(max,logprior+loglikelihood);
            }
        }

    }
    return logps;
}





double IrmBernoulli::effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2)
{
    Clustering& clustering_ = clusteringData;
    double& logalpha_ = param.logalpha_;
    double& bp_ = param.bp_;
    double& bm_ = param.bm_;

    if(cluster1 == cluster2)
    {
        return 0;
    }
    else
    {
        //compute change in prior
        double dlogPrior = 0;
        dlogPrior -= clustering_.getNumberOfClusters()  * logalpha_;
        dlogPrior += (clustering_.getNumberOfClusters()-1 ) * logalpha_;
        dlogPrior -= lgamma(clustering_.getSize(cluster1));
        dlogPrior -= lgamma(clustering_.getSize(cluster2));
        dlogPrior += lgamma(clustering_.getSize(cluster1) + clustering_.getSize(cluster2) );

        dlogPrior = dlogPrior*networks.size();

        //add change in likelihood
        double dlogLikelihood = 0;

        for(size_t netID = 0; netID<networks.size(); netID++)
        {
            SufficientStatistics& sf = data[netID].sufstats;
            for(Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer)
            {
                const size_t clusterId = citer.index();
                if(clusterId == cluster1 || clusterId == cluster2)
                {
                    continue;
                }
                else
                {
                    const size_t Npci = sf.getLinkCount(clusterId,cluster1);
                    const size_t Nmci = sf.getNonLinkCount(clusterId,cluster1) - sf.getMissingLinkCount(clusterId,cluster1);
                    const size_t Npcj = sf.getLinkCount(clusterId,cluster2);
                    const size_t Nmcj = sf.getNonLinkCount(clusterId,cluster2) - sf.getMissingLinkCount(clusterId,cluster2);

                    dlogLikelihood -= ( betaln_table.betaln(Npci,bp_ , Nmci,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                    dlogLikelihood -= ( betaln_table.betaln(Npcj,bp_ , Nmcj,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                    dlogLikelihood += ( betaln_table.betaln(Npci+Npcj,bp_ , Nmci+Nmcj, bm_) - betaln_table.betaln(0,bp_,0,bm_));

                    if(directed)
                    {
                        const size_t Npci = sf.getLinkCount(cluster1,clusterId);
                        const size_t Nmci = sf.getNonLinkCount(cluster1,clusterId) - sf.getMissingLinkCount(cluster1,clusterId);
                        const size_t Npcj = sf.getLinkCount(cluster2,clusterId);
                        const size_t Nmcj = sf.getNonLinkCount(cluster2,clusterId) - sf.getMissingLinkCount(cluster2,clusterId);

                        dlogLikelihood -= ( betaln_table.betaln(Npci,bp_ , Nmci,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                        dlogLikelihood -= ( betaln_table.betaln(Npcj,bp_ , Nmcj,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                        dlogLikelihood += ( betaln_table.betaln(Npci+Npcj,bp_ , Nmci+Nmcj, bm_) - betaln_table.betaln(0,bp_,0,bm_));
                    }
                }
            }
            if(!directed)
            {
                const size_t Npii = sf.getLinkCount(cluster1,cluster1);
                const size_t Nmii = sf.getNonLinkCount(cluster1,cluster1) - sf.getMissingLinkCount(cluster1,cluster1);
                const size_t Npjj = sf.getLinkCount(cluster2,cluster2);
                const size_t Nmjj = sf.getNonLinkCount(cluster2,cluster2) - sf.getMissingLinkCount(cluster2,cluster2);
                const size_t Npij = sf.getLinkCount(cluster1,cluster2);
                const size_t Nmij = sf.getNonLinkCount(cluster1,cluster2) - sf.getMissingLinkCount(cluster1,cluster2);

                dlogLikelihood -= ( betaln_table.betaln(Npii,bp_ , Nmii,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npjj,bp_, Nmjj,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npij,bp_ , Nmij,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood += ( betaln_table.betaln(Npii+Npjj+Npij,bp_ , Nmii+Nmjj+Nmij,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
            }
            else
            {
                const size_t Npii = sf.getLinkCount(cluster1,cluster1);
                const size_t Nmii = sf.getNonLinkCount(cluster1,cluster1) - sf.getMissingLinkCount(cluster1,cluster1);
                const size_t Npjj = sf.getLinkCount(cluster2,cluster2);
                const size_t Nmjj = sf.getNonLinkCount(cluster2,cluster2) - sf.getMissingLinkCount(cluster2,cluster2);
                const size_t Npij = sf.getLinkCount(cluster1,cluster2);
                const size_t Nmij = sf.getNonLinkCount(cluster1,cluster2) - sf.getMissingLinkCount(cluster1,cluster2);
                const size_t Npji = sf.getLinkCount(cluster2,cluster1);
                const size_t Nmji = sf.getNonLinkCount(cluster2,cluster1) - sf.getMissingLinkCount(cluster2,cluster1);


                dlogLikelihood -= ( betaln_table.betaln(Npii,bp_ , Nmii,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npjj,bp_, Nmjj,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npij,bp_ , Nmij,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood -= ( betaln_table.betaln(Npji,bp_ , Nmji,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
                dlogLikelihood += ( betaln_table.betaln(Npii+Npjj+Npij+Npji,bp_ , Nmii+Nmjj+Nmij+Nmji,bm_) - betaln_table.betaln(0,bp_,0,bm_) );
            }

        }

//        std::cout << " merge dlogprior = " << dlogPrior << "  dloglike = " << dlogLikelihood << std::endl;
        return dlogPrior+dlogLikelihood;
    }
}

void IrmBernoulli::computeAllSufficientStatistics()
{
    for(size_t i = 0; i < data.size(); i++)
    {
        computeSufficientStatistics(data[i],clusteringData);
    }
}

void IrmBernoulli::computeSufficientStatistics(Data& data_,Clustering& clustering_)
{

    SquareMatrix<size_t>& links = data_.sufstats.links;
    SquareMatrix<size_t>& nonlinks = data_.sufstats.nonlinks;
    SquareMatrix<size_t>& missinglinks = data_.sufstats.missinglinks;

    UnipartiteNetwork<size_t>& network = data_.network;

    //resize
    links.clear();
    nonlinks.clear();
    missinglinks.clear();

    data_.sufstats.usemissing = usemissing_;

    size_t newMaxClusters = std::max(clustering_.getNumberOfClusters()*2,(size_t)20);
    links.setNewMax(newMaxClusters);
    nonlinks.setNewMax(newMaxClusters);
    missinglinks.setNewMax(newMaxClusters);

    //compute all links
    for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
    {

        if(!clustering_.assigned(sourceNode))
        {
            continue;
        }

        size_t sourceCluster = clustering_.getClusterId(sourceNode);

        if(sourceCluster>=links.max)
        {
            size_t newMaxClusters = std::max(sourceCluster+1,links.max*2);
            links.setNewMax(newMaxClusters);
            nonlinks.setNewMax(newMaxClusters);
            missinglinks.setNewMax(newMaxClusters);
        }
        for(typename NetworkData<size_t>::iterator iter = network.data.begin(sourceNode); iter!=network.data.end(sourceNode) ; iter++)
        {
            size_t targetNode = iter.getTarget();

            if(!clustering_.assigned(targetNode))
            {
                continue;
            }

            size_t weight = iter.getValue();
            size_t targetCluster = clustering_.getClusterId(targetNode);

            if(targetCluster>=links.max)
            {
                size_t newMaxClusters = std::max(targetCluster+1,links.max*2);
                links.setNewMax(newMaxClusters);
                nonlinks.setNewMax(newMaxClusters);
                missinglinks.setNewMax(newMaxClusters);
            }
            links.matrix[sourceCluster*links.max+targetCluster] += weight;
        }
    }

    if(!directed)
    {
        for(size_t i = 0 ; i < links.max; i++)
        {
            links.matrix[i*links.max+i]/=2;
        }
    }

    //compute all nonlink counts
    for( Clustering::iterator citer = clustering_.begin(); citer!=clustering_.end(); ++citer )
    {
        size_t clusterIdFrom = citer.index();

        for( Clustering::iterator iter2 = clustering_.begin() ; iter2!=clustering_.end() ; iter2++ )
        {
            size_t clusterIdTo = iter2.index();
            if(clusterIdFrom == clusterIdTo)
            {
                //within
                size_t nodesInCluster = clustering_.getSize(clusterIdTo);
                size_t nonlinks__;
                if(!directed)
                {
                    nonlinks__ = numSubjects * (nodesInCluster)* (nodesInCluster - 1) *.5 - links.matrix[clusterIdFrom*nonlinks.max+clusterIdTo];
                }
                else
                {
                    nonlinks__ = numSubjects * (nodesInCluster)* (nodesInCluster - 1) - links.matrix[clusterIdFrom*nonlinks.max+clusterIdTo];
                }
                nonlinks.matrix[clusterIdFrom*nonlinks.max+clusterIdTo] = nonlinks__;
            }
            else
            {
                //between
                size_t nodesInClusterFrom = clustering_.getSize(clusterIdFrom);
                size_t nodesInClusterTo = clustering_.getSize(clusterIdTo);
                size_t nonlinks__ = numSubjects * nodesInClusterFrom*nodesInClusterTo - links.matrix[clusterIdFrom*nonlinks.max+clusterIdTo];
                nonlinks.matrix[clusterIdFrom*nonlinks.max+clusterIdTo] = nonlinks__;
            }
        }
    }

    //compute missing links
    if(usemissing_)
    {
        for(size_t sourceNode = 0; sourceNode < network.getNumberOfNodes(); sourceNode++)
        {

            if(!clustering_.assigned(sourceNode))
            {
                continue;
            }

            size_t sourceCluster = clustering_.getClusterId(sourceNode);

            for(typename NetworkData<size_t>::iterator iter = network.missing.begin(sourceNode); iter!=network.missing.end(sourceNode) ; iter++)
            {
                size_t targetNode = iter.getTarget();

                if(!clustering_.assigned(targetNode))
                {
                    continue;
                }


                size_t targetCluster = clustering_.getClusterId(targetNode);
                missinglinks.matrix[sourceCluster*links.max+targetCluster] += iter.getValue();
            }
        }
        if(!directed)
        {
            for(size_t i = 0 ; i < links.max; i++)
            {
                missinglinks.matrix[i*links.max+i]/=2;
            }
        }
    }
}









void IrmBernoulli::moveItem_clustering(size_t itemId, size_t clusterId)
{

   Clustering& clustering_ = clusteringData;

    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.links;
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;


        size_t currentCluster = clustering_.getClusterId(itemId);
        size_t max = links.max;

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

        //remove node from sufficient statistics
        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] -= nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] -= nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                //if(c!=currentCluster)
                {
                    links.matrix[c*links.max+currentCluster]-=nodecounts.nodeLinks_transposed[c];
                    links.matrix[currentCluster*links.max+c]-=nodeLinks[c];

                    nonlinks.matrix[c*links.max+currentCluster]-=nodecounts.nodeNonLinks_transposed[c];
                    nonlinks.matrix[currentCluster*links.max+c]-=nodeNonLinks[c];

                    if(usemissing_)
                    {
                        missinglinks.matrix[c*missinglinks.max+currentCluster]-=nodecounts.nodeMissingLinks_transposed[c];
                        missinglinks.matrix[currentCluster*missinglinks.max+c]-=nodeMissingLinks[c];
                    }
                }
            }


        }

        //move node
        currentCluster = clusterId;

        //insert node in sufficient statistics

        if(!directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+currentCluster] += nodeNonLinks[c];
                if(c!=currentCluster)
                {
                    links.matrix[currentCluster*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[currentCluster*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+currentCluster] += nodeMissingLinks[c];
                    if(c!=currentCluster)
                    {
                        missinglinks.matrix[currentCluster*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+currentCluster]+=nodecounts.nodeLinks_transposed[c];
                links.matrix[currentCluster*links.max+c]+=nodeLinks[c];

                nonlinks.matrix[c*links.max+currentCluster]+=nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[currentCluster*links.max+c]+=nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+currentCluster]+=nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[currentCluster*missinglinks.max+c]+=nodeMissingLinks[c];
                }
            }

        }

    }

    //move the node in the datastructure
    clustering_.moveItem(itemId,clusterId);
}


void IrmBernoulli::moveItem_newCluster_clustering(size_t itemId)
{
    Clustering& clustering_ = clusteringData;

    //obtain new clusterId and move node
    size_t oldClusterId = clustering_.getClusterId(itemId);
    clustering_.removeItem(itemId);
    size_t newClusterId = clustering_.addItem(itemId);


    for(size_t netID = 0; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.links;
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;

        //resize sufficient statistics if necessary
        if(newClusterId>=links.max)
        {
            size_t newMaxClusters = std::max(newClusterId+1,links.max*2);
            links.setNewMax(newMaxClusters);
            nonlinks.setNewMax(newMaxClusters);
            missinglinks.setNewMax(newMaxClusters);
        }

        size_t max = links.max;
        size_t currentCluster = clustering_.getClusterId(itemId);

        NodeCounts<size_t> nodecounts;
        getNodeCounts(itemId,data[netID],clustering_,currentCluster,max,nodecounts);
        std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
        std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
        std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;


        if(!directed)
        {
            //remove node from sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodeNonLinks[c];
                if(c!=oldClusterId)
                {
                    links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                    nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+oldClusterId] -= nodeMissingLinks[c];
                    if(c!=oldClusterId)
                    {
                        missinglinks.matrix[oldClusterId*links.max+c] -= nodeMissingLinks[c];
                    }
                }
            }

            //add node to sufficient statistics
            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+newClusterId] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodeNonLinks[c];
                if(c!=newClusterId)
                {
                    links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                    nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];
                }
            }
            if(usemissing_)
            {
                for(size_t c = 0; c<missinglinks.max; c++)
                {
                    missinglinks.matrix[c*links.max+newClusterId] += nodeMissingLinks[c];
                    if(c!=newClusterId)
                    {
                        missinglinks.matrix[newClusterId*links.max+c] += nodeMissingLinks[c];
                    }
                }
            }
        }
        else //if(directed)
        {

            for(size_t c = 0; c<links.max; c++)
            {
                links.matrix[c*links.max+oldClusterId] -= nodecounts.nodeLinks_transposed[c];
                links.matrix[oldClusterId*links.max+c] -= nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+oldClusterId] -= nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[oldClusterId*nonlinks.max+c] -= nodeNonLinks[c];

                links.matrix[c*links.max+newClusterId] += nodecounts.nodeLinks_transposed[c];
                links.matrix[newClusterId*links.max+c] += nodeLinks[c];
                nonlinks.matrix[c*nonlinks.max+newClusterId] += nodecounts.nodeNonLinks_transposed[c];
                nonlinks.matrix[newClusterId*nonlinks.max+c] += nodeNonLinks[c];

                if(usemissing_)
                {
                    missinglinks.matrix[c*missinglinks.max+oldClusterId] -= nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[oldClusterId*missinglinks.max+c] -= nodeMissingLinks[c];
                    missinglinks.matrix[c*missinglinks.max+newClusterId] += nodecounts.nodeMissingLinks_transposed[c];
                    missinglinks.matrix[newClusterId*missinglinks.max+c] += nodeMissingLinks[c];
                }
            }

        }

    }
}

void IrmBernoulli::mergeClusters_clustering(size_t clusterId1,size_t clusterId2)
{


    Clustering& clustering_ = clusteringData;

    //move nodes
    Clustering::clusterIterator iter;
    for(iter = clustering_.begin(clusterId2) ; clustering_.exist(clusterId2) && iter!=clustering_.end(clusterId2) ; ++iter)
    {
        clustering_.moveItem(*iter,clusterId1);
    }

    for(size_t netID = 0 ; netID < networks.size(); netID++)
    {
        SquareMatrix<size_t>& links = data[netID].sufstats.links;
        SquareMatrix<size_t>& nonlinks = data[netID].sufstats.nonlinks;
        SquareMatrix<size_t>& missinglinks = data[netID].sufstats.missinglinks;


        //update sufstats
        if(!directed)
        {
            //merge clusters
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                links.matrix[clusterId1*links.max+iter.index()] += links.matrix[clusterId2*links.max+iter.index()];
                links.matrix[iter.index()*links.max+clusterId1] = links.matrix[clusterId1*links.max+iter.index()];

                nonlinks.matrix[clusterId1*nonlinks.max+iter.index()] += nonlinks.matrix[clusterId2*nonlinks.max+iter.index()];
                nonlinks.matrix[iter.index()*nonlinks.max+clusterId1] = nonlinks.matrix[clusterId1*nonlinks.max+iter.index()];
            }
            links.matrix[clusterId1*links.max+clusterId1] += links.matrix[clusterId2*links.max+clusterId2];
            nonlinks.matrix[clusterId1*nonlinks.max+clusterId1] += nonlinks.matrix[clusterId2*nonlinks.max+clusterId2];

            if(usemissing_)
            {
                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    missinglinks.matrix[clusterId1*links.max+iter.index()] += missinglinks.matrix[clusterId2*links.max+iter.index()];
                    missinglinks.matrix[iter.index()*links.max+clusterId1] = missinglinks.matrix[clusterId1*links.max+iter.index()];
                }
                missinglinks.matrix[clusterId1*links.max+clusterId1] += missinglinks.matrix[clusterId2*links.max+clusterId2];
            }

            //set empty row and column to zeros
            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();
                links.matrix[clusterId2*links.max+c] = 0;
                links.matrix[c*links.max+clusterId2] = 0;
                nonlinks.matrix[clusterId2*links.max+c] = 0;
                nonlinks.matrix[c*links.max+clusterId2] = 0;
                if(usemissing_)
                {
                    missinglinks.matrix[clusterId2*links.max+c] = 0;
                    missinglinks.matrix[c*links.max+clusterId2] = 0;
                }
            }
            links.matrix[clusterId2*links.max+clusterId2] = 0;
            nonlinks.matrix[clusterId2*links.max+clusterId2] = 0;
            if(usemissing_)
            {
                missinglinks.matrix[clusterId2*links.max+clusterId2] = 0;
            }


        }
        else // directed
        {
            size_t selflinks = links.matrix[clusterId1*links.max+clusterId1]
                             + links.matrix[clusterId2*links.max+clusterId2]
                             + links.matrix[clusterId2*links.max+clusterId1]
                             + links.matrix[clusterId1*links.max+clusterId2];

            size_t selfnonlinks = nonlinks.matrix[clusterId1*nonlinks.max+clusterId1]
                                + nonlinks.matrix[clusterId2*nonlinks.max+clusterId2]
                                + nonlinks.matrix[clusterId2*nonlinks.max+clusterId1]
                                + nonlinks.matrix[clusterId1*nonlinks.max+clusterId2];

            for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
            {
                size_t c = iter.index();

                //from c to c1 and c2
                links.matrix[clusterId1*links.max+c] += links.matrix[clusterId2*links.max+c];
                links.matrix[c*links.max+clusterId1] += links.matrix[c*links.max+clusterId2];
                links.matrix[clusterId2*links.max+c] = 0;
                links.matrix[c*links.max+clusterId2] = 0;

                nonlinks.matrix[clusterId1*nonlinks.max+c] += nonlinks.matrix[clusterId2*nonlinks.max+c];
                nonlinks.matrix[c*nonlinks.max+clusterId1] += nonlinks.matrix[c*nonlinks.max+clusterId2];
                nonlinks.matrix[clusterId2*nonlinks.max+c] = 0;
                nonlinks.matrix[c*nonlinks.max+clusterId2] = 0;
            }
            links.matrix[clusterId1*links.max+clusterId1] = selflinks;
            links.matrix[clusterId2*links.max+clusterId1] = 0;
            links.matrix[clusterId1*links.max+clusterId2] = 0;

            nonlinks.matrix[clusterId1*nonlinks.max+clusterId1] = selfnonlinks;
            nonlinks.matrix[clusterId2*nonlinks.max+clusterId1] = 0;
            nonlinks.matrix[clusterId1*nonlinks.max+clusterId2] = 0;

            if(usemissing_)
            {
                size_t selfmissinglinks = missinglinks.matrix[clusterId1*missinglinks.max+clusterId1]
                            + missinglinks.matrix[clusterId2*missinglinks.max+clusterId2]
                            + missinglinks.matrix[clusterId2*missinglinks.max+clusterId1]
                            + missinglinks.matrix[clusterId1*missinglinks.max+clusterId2];

                for(Clustering::iterator iter = clustering_.begin(); iter!=clustering_.end(); ++iter)
                {
                    size_t c = iter.index();

                    //from c to c1 and c2
                    missinglinks.matrix[clusterId1*missinglinks.max+c] += missinglinks.matrix[clusterId2*missinglinks.max+c];
                    missinglinks.matrix[c*missinglinks.max+clusterId1] += missinglinks.matrix[c*missinglinks.max+clusterId2];
                    missinglinks.matrix[clusterId2*missinglinks.max+c] = 0;
                    missinglinks.matrix[c*missinglinks.max+clusterId2] = 0;
                }
                missinglinks.matrix[clusterId1*missinglinks.max+clusterId1] = selfmissinglinks;
                missinglinks.matrix[clusterId2*missinglinks.max+clusterId1] = 0;
                missinglinks.matrix[clusterId1*missinglinks.max+clusterId2] = 0;
            }

        }
    }

};



Clustering* IrmBernoulli::getDataPointer_clustering()
{
    Clustering& clustering_ = clusteringData;
    return &clustering_;
};

size_t IrmBernoulli::getNumberOfItems_clustering()
{
    return networks[0].getNumberOfNodes();
}

ClusteringDocument IrmBernoulli::get_clustering()
{
    Clustering& clustering_ = clusteringData;
    ClusteringDocument cd( clustering_.getNumberOfClusters(), clustering_);
    return cd;
};

void IrmBernoulli::set_clustering(ClusteringDocument& cd)
{
    Clustering clustering(cd.clusteringVector);
    clusteringData = clustering;
    computeAllSufficientStatistics();
};

void IrmBernoulli::setFromString_clustering(std::string s)
{
    ClusteringDocument cd(s);
    set_clustering(cd);
};



//alpha functions
double IrmBernoulli::get_alpha()
{
    double& alpha_ = param.alpha_;
    return alpha_;
}
void IrmBernoulli::set_alpha(double val)
{
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    alpha_ = val;
    logalpha_ = log(val);
}
double IrmBernoulli::logPosteriorRatio_alpha(double new_alpha)
{
    Clustering& clustering_ = clusteringData;
    double& alpha_ = param.alpha_;
    double& logalpha_ = param.logalpha_;

    if (new_alpha <= 0) return -9999999999999999;
    int noc = clustering_.getNumberOfClusters();
    int J = networks[0].getNumberOfNodes();
    double logp = noc * log(new_alpha) + lgamma(new_alpha) - lgamma(J+new_alpha) - log(new_alpha);
    logp -= noc * logalpha_ + lgamma(alpha_) - lgamma(J+alpha_) - logalpha_;
    return logp;
}

//bp functions
double IrmBernoulli::get_bp()
{
    double& bp_ = param.bp_;
    return bp_;
}

void IrmBernoulli::set_bp(double val)
{
    double& bp_ = param.bp_;
    bp_ = val;
}

double IrmBernoulli::logPosteriorRatio_bp(double new_bp)
{
    if (new_bp <= 0) return -9999999999999999;
    double old_bp = bp.get();
    double L0 = computeLogLikelihood();
    bp.set(new_bp);
    double L1 = computeLogLikelihood();
    bp.set(old_bp);
    return L1-L0;
}

//bm functions
double IrmBernoulli::get_bm()
{
    double& bm_ = param.bm_;
    return bm_;
}

void IrmBernoulli::set_bm(double val)
{
    double& bm_ = param.bm_;
    bm_ = val;
}

double IrmBernoulli::logPosteriorRatio_bm(double new_bm)
{
    if (new_bm <= 0) return -9999999999999999;
    double old_bm = bm.get();
    double L0 = computeLogLikelihood();
    bm.set(new_bm);
    double L1 = computeLogLikelihood();
    bm.set(old_bm);
    return L1-L0;
}



/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmBernoulli::logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    Clustering& clustering_ = clusteringData;

    double dp = 0;
    if(cluster != currentCluster)
    {
        dp = log(clustering_.getSize(cluster));
    }
    else
    {
        if(currentClusterSize>1)
            dp = log(currentClusterSize-1);
    }
    return dp;
}

/**
*** compute the effective change for the log_prior when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmBernoulli::logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    const double alpha_ = param.alpha_;
    return log(alpha_);
}



/**
*** compute the effective change for the log_likelihood when moving node nodeId from currentCluster to a new cluster
**/
inline double IrmBernoulli::logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts)
{
    double& bp_ = param.bp_;
    double& bm_ = param.bm_;

    std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
    std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

    std::vector<size_t>& nodeLinks_t = nodecounts.nodeLinks_transposed;
    std::vector<size_t>& nodeNonLinks_t = nodecounts.nodeNonLinks_transposed;
    std::vector<size_t>& nodeMissingLinks_t = nodecounts.nodeMissingLinks_transposed;


    if(!directed)
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();

            if( l !=  currentCluster)
            {
                double val = 0;
                val += betaln_table.betaln( nodeLinks[l], bp_, nodeNonLinks[l] - nodeMissingLinks[l] , bm_);
                val -= betaln_table.betaln( 0, bp_, 0, bm_);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    loglik += betaln_table.betaln( nodeLinks[l],bp_ , nodeNonLinks[l] - nodeMissingLinks[l] ,bm_ );
                    loglik -= betaln_table.betaln( 0, bp_ , 0 , bm_ );
                }
            }
        }

        return loglik;
    }
    else // directed
    {
        double loglik = 0;
        for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end() ; ++iter)
        {
            size_t l = iter.index();
            if( l != currentCluster)
            {
                double val = 0;
                val += betaln_table.betaln( nodeLinks[l], bp_, nodeNonLinks[l] - nodeMissingLinks[l] , bm_);
                val -= betaln_table.betaln( 0, bp_, 0, bm_);
                val += betaln_table.betaln( nodeLinks_t[l], bp_, nodeNonLinks_t[l] - nodeMissingLinks_t[l] , bm_);
                val -= betaln_table.betaln( 0, bp_, 0, bm_);
                loglik += val;
            }
            else
            {
                if(currentClusterSize>1)
                {
                    double val = 0;
                    val += betaln_table.betaln( nodeLinks[l], bp_, nodeNonLinks[l] - nodeMissingLinks[l] , bm_);
                    val -= betaln_table.betaln( 0, bp_, 0, bm_);
                    val += betaln_table.betaln( nodeLinks_t[l], bp_, nodeNonLinks_t[l] - nodeMissingLinks_t[l] , bm_);
                    val -= betaln_table.betaln( 0, bp_, 0, bm_);
                    loglik += val;
                }
            }

        }
        return loglik;
    }
}





/**
*** compute the change in log_loglikelihood when moving node nodeId from currentCluster to existing cluster (cluster)
**/
inline double IrmBernoulli::logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts)
{
    double& bm_ = param.bm_;
    double& bp_ = param.bp_;

    SufficientStatistics& sf = data_.sufstats;

    std::vector<size_t>& nodeLinks = nodecounts.nodeLinks;
    std::vector<size_t>& nodeNonLinks = nodecounts.nodeNonLinks;
    std::vector<size_t>& nodeMissingLinks = nodecounts.nodeMissingLinks;

    std::vector<size_t>& nodeLinks_t = nodecounts.nodeLinks_transposed;
    std::vector<size_t>& nodeNonLinks_t = nodecounts.nodeNonLinks_transposed;
    std::vector<size_t>& nodeMissingLinks_t = nodecounts.nodeMissingLinks_transposed;

    if(!directed)
    {
        double sum = 0;
        if(cluster != currentCluster)
        {
            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                if(l!=currentCluster)
                {
                    const double linkcount = sf.getLinkCount(cluster,l);
                    const double nonlinkcount = sf.getNonLinkCount(cluster,l) - sf.getMissingLinkCount(cluster,l);
                    sum += betaln_table.betaln( linkcount + nodeLinks[l], bp_ , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                    sum -= betaln_table.betaln( linkcount , bp_ , nonlinkcount , bm_ );
                }
                else
                {
                    if(currentClusterSize>1)
                    {
                        const double linkcount = sf.getLinkCount(cluster,l) - nodeLinks[cluster];
                        const double nonlinkcount = sf.getNonLinkCount(cluster,l) - nodeNonLinks[cluster] - ( sf.getMissingLinkCount(cluster,l) - nodeMissingLinks[cluster] );
                        sum += betaln_table.betaln( linkcount + nodeLinks[l] , bp_ , nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                        sum -= betaln_table.betaln( linkcount, bp_ , nonlinkcount , bm_ );
                    }
                }
            }
        }
        else
        {
            if(currentClusterSize>1)
            {
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {
                    size_t l = iter.index();
                    const double linkcount = sf.getLinkCount(cluster,l) - nodeLinks[l];
                    const double nonlinkcount = sf.getNonLinkCount(cluster,l) - nodeNonLinks[l] - ( sf.getMissingLinkCount(cluster,l) - nodeMissingLinks[l] );
                    sum += betaln_table.betaln( linkcount + nodeLinks[l], bp_, nonlinkcount + nodeNonLinks[l] - nodeMissingLinks[l] , bm_ );
                    sum -= betaln_table.betaln( linkcount, bp_, nonlinkcount, bm_ );
                }
            }
            else
            {
                //node is alone in cluster
            }
        }
        return sum;
    }
    else/**if directed*/
    {

        const size_t c = cluster;
        const double a = bp_;
        const double b = bm_;


        if(c!=currentCluster)
        {
            double d_loglikelihood = 0;

            for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
            {
                size_t l = iter.index();

                const size_t r_nl = nodeLinks[l];               //links from node to cluster l
                const size_t rn_nl = nodeNonLinks[l];
                const size_t rm_nl = nodeMissingLinks[l];

                const double r_ln = nodeLinks_t[l];             //links from cluster l to node
                const double rn_ln = nodeNonLinks_t[l];
                const double rm_ln = nodeMissingLinks_t[l];

                if(l!=currentCluster )
                {
                    const double m_lc = sf.getLinkCount(l,c);          //links from cluster l to cluster c
                    const double mn_lc = sf.getNonLinkCount(l,c);
                    const double mm_lc = sf.getMissingLinkCount(l,c);

                    const double m_cl = sf.getLinkCount(c,l);          //links from cluster c to cluster l
                    const double mn_cl = sf.getNonLinkCount(c,l);
                    const double mm_cl = sf.getMissingLinkCount(c,l);

                    if(l!=c)
                    {
                        //std::cout << ":::(1) (v): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;
                        d_loglikelihood += betaln_table.betaln( m_cl + r_nl, a, mn_cl + rn_nl - (mm_cl + rm_nl) , b );
                        d_loglikelihood -= betaln_table.betaln( m_cl, a , mn_cl - mm_cl, b );

                        d_loglikelihood += betaln_table.betaln( m_lc + r_ln, a, mn_lc + rn_ln - (mm_lc + rm_ln), b );
                        d_loglikelihood -= betaln_table.betaln( m_lc, a , mn_lc - mm_lc, b);
                    }
                    else // l == c
                    {
                        //std::cout << ":::(2) (v): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;
                        d_loglikelihood += betaln_table.betaln( m_cl + r_nl + r_ln, a, mn_cl + rn_nl + rn_ln - (mm_cl + rm_nl + rm_ln), b );
                        d_loglikelihood -= betaln_table.betaln( m_cl, a , mn_cl - mm_cl, b );
                    }

                }
                else //l==currentCluster
                {
                    const double r_nc = nodeLinks[c];               //links from node to cluster c
                    const double rn_nc = nodeNonLinks[c];
                    const double rm_nc = nodeMissingLinks[c];

                    const double r_cn = nodeLinks_t[c];             //links from cluster c to node
                    const double rn_cn = nodeNonLinks_t[c];
                    const double rm_cn = nodeMissingLinks_t[c];

                    if(l!=c) // l = q
                    {
                        //std::cout << ":::(3)(v2): l = " << l << " , c = " << c << "  q = " << currentCluster << std::endl;

                        const double m_cl = sf.getLinkCount(c,l) - r_cn;          //links from cluster c to cluster l
                        const double mn_cl = sf.getNonLinkCount(c,l) - rn_cn;
                        const double mm_cl = sf.getMissingLinkCount(c,l) - rm_cn;


                        const double m_lc = sf.getLinkCount(l,c) - r_nc;          //links from cluster l to cluster c
                        const double mn_lc = sf.getNonLinkCount(l,c) - rn_nc;
                        const double mm_lc = sf.getMissingLinkCount(l,c) - rm_nc;

                        d_loglikelihood += betaln_table.betaln( m_cl + r_nl, a, mn_cl + rn_nl - (mm_cl + rm_nl), b );
                        d_loglikelihood -= betaln_table.betaln( m_cl, a , mn_cl - mm_cl, b );

                        d_loglikelihood += betaln_table.betaln( m_lc + r_ln, a, mn_lc + rn_ln - (mm_lc + rm_ln), b );
                        d_loglikelihood -= betaln_table.betaln( m_lc, a , mn_lc - mm_lc, b);
                    }
                    else // l == c == currentcluster
                    {
                        //std::cout << ":::(4) (v0): " << l << " , " << c << "  q = " << currentCluster << std::endl;

                        const double m_ll = sf.getLinkCount(c,l) - r_nl - r_ln;
                        const double mn_ll = sf.getNonLinkCount(c,l) - rn_nl - rn_ln;
                        const double mm_ll = sf.getMissingLinkCount(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l) , a , sf.getNonLinkCount(c,l) - sf.getMissingLinkCount(c,l) , b);
                        d_loglikelihood -= betaln_table.betaln( m_ll , a , mn_ll - mm_ll, b);

                    }

                }


            }
            return d_loglikelihood;
        }
        else //c==currentCluster
        {
            if(currentClusterSize>1)
            {
                double d_loglikelihood = 0;
                for(Clustering::iterator iter = clustering_.begin() ; iter!=clustering_.end(); ++iter)
                {
                    size_t l = iter.index();

                    const size_t r_nl = nodeLinks[l];               //links from node to cluster l
                    const size_t rn_nl = nodeNonLinks[l];
                    //const double rm_nl = nodeMissingLinks[l];

                    const double r_ln = nodeLinks_t[l];             //links from cluster l to node
                    const double rn_ln = nodeNonLinks_t[l];
                    //const double rm_ln = nodeMissingLinks_t[l];

                    //const double r_nc = nodeLinks[c];               //links from node to cluster c
                    //const double rn_nc = nodeNonLinks[c];
                    //const double rm_nc = nodeMissingLinks[c];

                    //const double r_cn = nodeLinks_t[c];             //links from cluster c to node
                    //const double rn_cn = nodeNonLinks_t[c];
                    //const double rm_cn = nodeMissingLinks_t[c];

                    if(l!=c)
                    {
                        d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l), a, sf.getNonLinkCount(c,l) - sf.getMissingLinkCount(c,l), b);
                        d_loglikelihood -= betaln_table.betaln( sf.getLinkCount(c,l) - nodeLinks[l] , a, sf.getNonLinkCount(c,l)- nodeNonLinks[l] - (sf.getMissingLinkCount(c,l) - nodeMissingLinks[l]) , b );

                        d_loglikelihood += betaln_table.betaln( sf.getLinkCount(l,c), a, sf.getNonLinkCount(l,c) - sf.getMissingLinkCount(l,c), b);
                        d_loglikelihood -= betaln_table.betaln( sf.getLinkCount(l,c) - nodeLinks_t[l] , a, sf.getNonLinkCount(l,c)- nodeNonLinks_t[l] - (sf.getMissingLinkCount(l,c) - nodeMissingLinks_t[l]) , b );
                    }
                    else // l == c == currentcluster
                    {
                        const double m_ll = sf.getLinkCount(c,l) - r_nl - r_ln;
                        const double mn_ll = sf.getNonLinkCount(c,l) - rn_nl - rn_ln;
                        const double mm_ll = sf.getMissingLinkCount(c,l) - nodeMissingLinks[l] - nodeMissingLinks_t[l];

                        d_loglikelihood += betaln_table.betaln( sf.getLinkCount(c,l) , a , sf.getNonLinkCount(c,l)-sf.getMissingLinkCount(c,l) , b);
                        d_loglikelihood -= betaln_table.betaln( m_ll , a , mn_ll - mm_ll, b);


                    }
                }
                return d_loglikelihood;

            }
            else
            {
                return 0;
            }
        }
    }
}
