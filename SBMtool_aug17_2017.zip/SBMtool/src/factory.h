/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
This code is provided as is without any warranty!
-----------------------
Generic Factory class for generating objects of class D derived from a base class B.
The Factory is implemented using a singleton.

To register an object in the factory, instantiate an object of class Creator<B, D>
where B is a base class and D is a class derived from B.
  Creator<B, D> myCreator(std::string id);
When myCreator goes out of scope, the object is unregistered from the factory.

The derived class must have a constructor that takes an argument of class Options.

To instantiate an object, call the create function in the factory class
  std::unique_ptr<B> myObject = Factory<B>::create(std::string id, Options options)

------------------------
This design is utilized to allow the application to define and expose all available models,
samplers and schedulers to the user and generically create objects of these types.
------------------------
*/


#ifndef FACTORY_H_INCLUDED
#define FACTORY_H_INCLUDED

#include "Options.h"
#include "settings.h"

#include <string>
#include <map>
#include <memory>
#include <boost/units/detail/utility.hpp>
#include <typeinfo>


// Forward declaration


template <class B> class BaseCreator;

template <class B>
class Factory
{
    template <class B_, class D> friend class Creator;

private:
    // Private constructor and destructor
    Factory<B>();
    ~Factory<B>();
    // Ensure objects can not be copied
    Factory<B>(Factory<B> const&);
    void operator=(Factory<B> const&);

    // Map from string to
public:
    std::map<std::string, BaseCreator<B>*> registerMap;
    // Return reference to singleton factory instance
    static Factory<B>& instance();
private:
    // Register/unregister a Creator object in the factory
    static void registerCreator(std::string, BaseCreator<B>*);
    static void unregisterCreator(std::string);

public:
    // Create an object from the factory
    static std::unique_ptr<B> create(std::string, Options);
    static std::unique_ptr<B> create(std::string);


};

template <class B>
class BaseCreator
{
public:
    BaseCreator();
    virtual ~BaseCreator();
    virtual B* create(Options o) = 0;
    virtual B* create() = 0;
};

template <class B, class D>
class Creator : public BaseCreator<B>
{
private:
    std::string creatorId;

public:
    Creator(std::string);
    ~Creator();
    B* create(Options o);
    B* create();
};

// ---------------------------------------------------------------------------------------------------------
// Factory implementation

template <class B>
Factory<B>::Factory()
{
//    std::clog << "Creating Factory<" << boost::units::detail::demangle(typeid(B).name()) << ">" << std::endl;
}

template <class B>
Factory<B>::~Factory()
{
//    std::clog << "Destroying factory<" << boost::units::detail::demangle(typeid(B).name()) << ">" << std::endl;
}

// Return reference to singleton factory instance
template <class B>
Factory<B>& Factory<B>::instance()
{
    static Factory<B> factory;
    return factory;
}

// Register a Creator object in the factory
template <class B>
void Factory<B>::registerCreator(std::string id, BaseCreator<B>* fun)
{
    // Check if object is already registered
    if (instance().registerMap.find(id) == instance().registerMap.end())
    {
        instance().registerMap[id] = fun;
//        std::clog << "Registered Creator '" << id << "'" << std::endl;
    }
    else
    {
        throw("Tried to register same id twice.");
    }
    return;
}

// Unregister a Creator object in the factory
template <class B>
void Factory<B>::unregisterCreator(std::string id)
{
    // Check if object is already registered
    if (instance().registerMap.find(id) != instance().registerMap.end())
    {
        instance().registerMap.erase(id);
//        std::clog << "Unregistered Creator '" << id << "'" << std::endl;
    }
    else
    {
        throw("Tried to unregister an id that was not registered.");
    }
}

// Create an object from the factory
template <class B>
std::unique_ptr<B> Factory<B>::create(std::string id, Options o)
{
    // Check if object is registered
    if (instance().registerMap.find(id) != instance().registerMap.end())
    {
        return std::unique_ptr<B>(instance().registerMap[id]->create(o));
    }
    else
    {
        throw("Tried to produce object from id not registered.");
    }
}
template <class B>
std::unique_ptr<B> Factory<B>::create(std::string id)
{
    // Check if object is registered
    if (instance().registerMap.find(id) != instance().registerMap.end())
    {
        return std::unique_ptr<B>(instance().registerMap[id]->create());
    }
    else
    {
        throw("Tried to produce object from id not registered.");
    }
}

// ---------------------------------------------------------------------------------------------------------
// BaseCreator implementation

template <class B>
BaseCreator<B>::BaseCreator()
{
//    std::clog << "Creating BaseCreator<" << boost::units::detail::demangle(typeid(B).name()) << ">" << std::endl;
}

template <class B>
BaseCreator<B>::~BaseCreator()
{
//    std::clog << "Destroying BaseCreator<" << boost::units::detail::demangle(typeid(B).name()) << ">" << std::endl;
}

// ---------------------------------------------------------------------------------------------------------
// Creator implementation

template <class B, class D>
Creator<B, D>::Creator(std::string id)
{
//    std::clog << "Creating Creator<" << boost::units::detail::demangle(typeid(B).name()) << ", " << boost::units::detail::demangle(typeid(D).name()) << ">" << std::endl;
    Factory<B>::registerCreator(id, this);
    creatorId = id;
}

template <class B, class D>
Creator<B, D>::~Creator()
{
//    std::clog << "Destroying Creator<" << boost::units::detail::demangle(typeid(B).name()) << ", " << boost::units::detail::demangle(typeid(D).name()) << ">" << std::endl;
    Factory<B>::unregisterCreator(creatorId);
}

template <class B, class D>
B* Creator<B, D>::create(Options o)
{
    return new D(o);
}

template <class B, class D>
B* Creator<B, D>::create()
{
    return new D();
}


#endif // FACTORY_H_INCLUDED
