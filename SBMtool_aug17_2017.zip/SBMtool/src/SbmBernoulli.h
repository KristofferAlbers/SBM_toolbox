/*
Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SBMBERNOULLI_H_INCLUDED
#define SBMBERNOULLI_H_INCLUDED

#include "StatisticalModel.h"
#include "Options.h"
#include "settings.h"
#include "factory.h"
#include "LinkCount.h"
#include "Network.h"
#include "Clustering_final.h"
#include "ClusteringDocument.h"

#include "tableApproximations.h"

#include <vector>
#include <boost/assign.hpp>
#include <boost/tuple/tuple.hpp>
#include <omp.h>

using namespace std::placeholders;

class SbmBernoulli : public StatisticalModel
{

    const static std::string MODELNAME;

    const std::string PARAMETER_CLUSTERING = "clustering";
    const std::string PARAMETER_ALPHA = "alpha";
    const std::string PARAMETER_BP = "bp";
    const std::string PARAMETER_BM = "bm";

    const std::string OPT_NETWORK_LINKS = "network.links";
    const std::string OPT_NETWORK_MISSINGLINKS = "network.missinglinks";
    const std::string OPT_CLUSTERING_CRP = "clustering.init_crp";
    const std::string OPT_CLUSTERING_RANDOM = "clustering.init_random";

    const std::string OPT_TABLEMAX_A = "tablemax_a";
    const std::string OPT_TABLEMAX_B = "tablemax_b";
    const std::string OPT_TABLEMAX_C = "tablemax_c";
    const std::string OPT_ITEMS = "items";
    const std::string OPT_SUBJECTS = "subjects";
    const std::string OPT_COMPONENTS = "components";

    const std::string OPT_INIT_ALPHA = "alpha.init";
    const std::string OPT_INIT_BP = "bp.init";
    const std::string OPT_INIT_BM = "bm.init";
    const std::string OPT_DIRECTED = "directed";
    const std::string OPT_USEMISSING = "withmissing";

    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;

template <typename T> class NodeCounts
{
public:
    std::vector<T> nodeLinks;
    std::vector<T> nodeNonLinks;
    std::vector<T> nodeMissingLinks;
    std::vector<T> nodeLinks_transposed;
    std::vector<T> nodeNonLinks_transposed;
    std::vector<T> nodeMissingLinks_transposed;

    void print()
    {
        std::cout << "cluster:\t links \t non \t miss \t links' \t non'" << std::endl;
        for(int i = 0; i < nodeLinks.size(); i++)
        {
            std::cout << "(i = " << i << " ) \t "<< nodeLinks[i] << " \t " << nodeNonLinks[i] << "\t / \t";// << nodeLinks_transposed[i] << "\t"<<nodeNonLinks_transposed[i]; // << " \t " << nodeMissingLinks[i];
           // std::cout << "\t\t" << nodeLinks_transposed[i] << " \t " << nodeNonLinks_transposed[i] << " \t " << nodeMissingLinks_transposed[i] << std::endl;
           std::cout << std::endl;
        }
        std::cout << std::endl;
    }
};

struct SufficientStatistics
{
    SquareMatrix<size_t> links;
    SquareMatrix<size_t> nonlinks;
    SquareMatrix<size_t> missinglinks;

    bool usemissing = false;

    size_t getLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        return links.matrix[sourceCluster*links.max+targetCluster];
    }

    size_t getNonLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        return nonlinks.matrix[sourceCluster*nonlinks.max+targetCluster];
    }
    size_t getMissingLinkCount(size_t sourceCluster, size_t targetCluster)
    {
        if(usemissing)
            return missinglinks.matrix[sourceCluster*missinglinks.max+targetCluster];
        else
            return 0;
    }
};
struct HyperParameters_bernoulli
{
    double alpha_;
    double logalpha_;
    double bp_;
    double bm_;
};
struct Data
{
    UnipartiteNetwork<size_t>& network;
    NetworkData<size_t>& data;
    NetworkData<size_t>& data_transposed;
    NetworkData<size_t>& missing;
    NetworkData<size_t>& missing_transposed;
    SufficientStatistics& sufstats;
};

public:

    //clustering data
    Clustering_finite clusteringData;

    //parameters
    ClusteringFinite_Parameter clustering;
    Real alpha;
    Real bp;
    Real bm;

    size_t items;
    size_t numSubjects;
    size_t K;

    bool usemissing_;
    bool directed;
    bool network_weighted;
    std::string missinglinksfile_;
    std::string linksfile_;

    //hyperparameters data
    HyperParameters_bernoulli param;
    //sufficient statistics
    std::vector<SufficientStatistics> sufstats;

    //network data
    std::vector<UnipartiteNetwork<size_t>> networks;

    std::vector<Data> data;

    Betaln betaln_table;

public:

    SbmBernoulli() : StatisticalModel(),
            clustering(this,PARAMETER_CLUSTERING), alpha(this,PARAMETER_ALPHA), bp(this,PARAMETER_BP), bm(this,PARAMETER_BM),
            betaln_table(1,1,1)
    {
    }

    SbmBernoulli(Options o) : StatisticalModel(MODELNAME, o),
            clustering(this,PARAMETER_CLUSTERING), alpha(this,PARAMETER_ALPHA), bp(this,PARAMETER_BP), bm(this,PARAMETER_BM),
            betaln_table(getOption<int>(o,OPT_TABLEMAX_A,10000),getOption<int>(o,OPT_TABLEMAX_B,60000),getOption<int>(o,OPT_TABLEMAX_C,70000))
    {
        //bind parameter functions
        clustering.effectiveLogPosteriorRatio = std::bind(&SbmBernoulli::effectiveLogPosteriorRatio_clustering,this,_1,_2,_3,_4);
        clustering.effectiveLogPosteriorRatio_restricted = std::bind(&SbmBernoulli::effectiveLogPosteriorRatio_restricted_clustering, this, _1, _2);
        clustering.moveItem = std::bind(&SbmBernoulli::moveItem_clustering, this, _1, _2);
        clustering.getDataPointer = std::bind(&SbmBernoulli::getDataPointer_clustering,this);
        clustering.getNumberOfItems = std::bind(&SbmBernoulli::getNumberOfItems_clustering,this);
        clustering.get = std::bind(&SbmBernoulli::get_clustering,this);
        clustering.set = std::bind(&SbmBernoulli::set_clustering,this,_1);
        clustering.setFromString_implement = std::bind(&SbmBernoulli::setFromString_clustering,this,_1);
        alpha.get = std::bind(&SbmBernoulli::get_alpha,this);
        alpha.set = std::bind(&SbmBernoulli::set_alpha,this,_1);
        alpha.logPosteriorRatio = std::bind(&SbmBernoulli::logPosteriorRatio_alpha, this, _1);
        bp.get = std::bind(&SbmBernoulli::get_bp,this);
        bp.set = std::bind(&SbmBernoulli::set_bp,this,_1);
        bp.logPosteriorRatio = std::bind(&SbmBernoulli::logPosteriorRatio_bp, this, _1);
        bm.get = std::bind(&SbmBernoulli::get_bm,this);
        bm.set = std::bind(&SbmBernoulli::set_bm,this,_1);
        bm.logPosteriorRatio = std::bind(&SbmBernoulli::logPosteriorRatio_bm, this, _1);

        items = parseSetting<int>(OPT_ITEMS,settingDescriptions,o);
        numSubjects = parseSetting<int>(OPT_SUBJECTS,settingDescriptions,o);
        K = parseSetting<int>(OPT_COMPONENTS,settingDescriptions,o);

        param.alpha_ = parseSetting<double>(OPT_INIT_ALPHA,settingDescriptions,o);
        param.logalpha_ = log(param.alpha_);
        param.bp_ = parseSetting<double>(OPT_INIT_BP,settingDescriptions,o);
        param.bm_ = parseSetting<double>(OPT_INIT_BM,settingDescriptions,o);

        directed = parseSetting<bool>(OPT_DIRECTED,settingDescriptions,o);
        usemissing_ = parseSetting<bool>(OPT_USEMISSING,settingDescriptions,o);
        linksfile_ = parseSetting<std::string>(OPT_NETWORK_LINKS,settingDescriptions,o);

        //load network
        if(numSubjects>1){   network_weighted = true;   } else { network_weighted = false; }
        bool zeroindexed = false;
        bool missingweighted = network_weighted;
        bool missingToZero = false;
        if(usemissing_)
        {
            missinglinksfile_ = parseSetting<std::string>(OPT_NETWORK_MISSINGLINKS,settingDescriptions,o);
            UnipartiteNetwork<size_t> network(items,linksfile_, missinglinksfile_, zeroindexed, missingweighted, missingToZero, network_weighted, directed);
            networks.push_back(network);
        }
        else
        {
            UnipartiteNetwork<size_t> network(items,linksfile_, zeroindexed, network_weighted, directed);
            networks.push_back(network);
        }

        //initialize clustering
        ClusteringDocument cd;
        int clust_random = parseSetting<int>(OPT_CLUSTERING_RANDOM,settingDescriptions,o);
        cd.init_uniform(items,clust_random);
        clusteringData = Clustering_finite(items,K,cd.clusteringVector);

        //initialize sufficient statistics
        sufstats.resize(networks.size());
        for(size_t i = 0; i<networks.size(); i++)
        {
            SufficientStatistics sf;
            sufstats[i] = sf;

            data.push_back({networks[i],networks[i].data,networks[i].data_transposed,networks[i].missing,networks[i].missing_transposed,sufstats[i]});
        }
        computeAllSufficientStatistics();

        //report, model setup suceeded.
        reportInfo("model setup completed",.5);

    }

    double computeLogPrior();
    double computeLogLikelihood();
    double computeLogPosterior();
    double computeLogLikelihood(Data& data_, Clustering_finite& clustering_);

    //assist functions
    void computeAllSufficientStatistics();
    void computeSufficientStatistics(Data& data_, Clustering_finite& clustering_);

    void getNodeCounts(size_t nodeId, Data& data_, Clustering_finite& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts);

    inline double logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);
    inline double logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);


    inline double logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering_finite& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts);
    inline double logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering_finite& clustering, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);

    //clustering functions
    partial_vector<double> effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering_finite::iterator begin, Clustering_finite::iterator end, bool appendForNewCluster);
    partial_vector<double> effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters);
    double effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2);

    void moveItem_clustering(size_t itemId, size_t clusterId);
    void moveItem_newCluster_clustering(size_t itemId);
    void mergeClusters_clustering(size_t cluster1,size_t cluster2);

    Clustering_finite* getDataPointer_clustering();
    size_t getNumberOfItems_clustering();
    ClusteringDocument get_clustering();
    void set_clustering(ClusteringDocument& cd);
    void setFromString_clustering(std::string str);



    //alpha functions
    double get_alpha();
    void set_alpha(double val);
    double logPosteriorRatio_alpha(double new_alpha);

    //bp functions
    double get_bp();
    void set_bp(double val);
    double logPosteriorRatio_bp(double new_bp);

    //bm functions
    double get_bm();
    void set_bm(double val);
    double logPosteriorRatio_bm(double new_bm);



    double effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster);

    static Creator<StatisticalModel, SbmBernoulli> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};

#endif // SBMBERNOULLI_H_INCLUDED
