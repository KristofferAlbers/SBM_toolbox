/**
This code is provided as is without any warranty!

Defines classes used to represent sufficient statistics as matrices
The size of the matrices can be changed generically.
The transpose flag will treat a matrix as transposed without modifying the stored data
A matrix can be resized using the setNewMaxSize() function
Data can be modified by setting, adding, subtracting.
The function mergeRows(row1,row2) merges row2 into row1 and sets all values in row2 to zero
The shadow function allows one matrix object ms to effectively share data with another
matrix object, yet allowing ms to be transposed independently.
*/


#ifndef LINKCOUNT_H_INCLUDED
#define LINKCOUNT_H_INCLUDED


#include <vector>


template <typename T> class SquareMatrix
{
public:
    size_t max = 0;
    std::vector<T> matrix;

    inline void clear()
    {
        matrix.clear();
        max = 0;
    }
    inline T get(size_t row, size_t column)
    {
        return matrix[row*max+column];
    }
    inline void set(T value,size_t row, size_t column)
    {
        matrix[row*max+column] = value;
    }
    void setNewMax(size_t newMax)
    {
        if(newMax<max)
            return;
        if(newMax<max*2)newMax = max*2;
        matrix.resize(newMax*newMax);
        for(int i=max-1; i>=0; i--)
        {
            memcpy(&matrix[newMax*i],&matrix[max*i], max*sizeof(T));
            memset(&matrix[newMax*i+max], 0, sizeof(T) * (newMax-max));
        }
        max = newMax;
    }

    void setToCopy(SquareMatrix<T>& copyFrom)
    {
        matrix.clear();
        max = copyFrom.max;
        matrix.reserve(copyFrom.matrix.size());
        matrix = copyFrom.matrix;
    }


    void print(int max_)
    {
        for(int r = 0; r<max_ && r<max; r++){
            for(int c = 0; c<max_ && c<max ; c++){
                std::cout << "\t" << matrix[r*max+c];
            }
            std::cout<<std::endl;
        }
    }

    /**
        test if the values stored in two squarematrices are the same
        @param dataOnly - false: the two matrices must have equal allocated size
    */
    bool equals(SquareMatrix<T>& other,bool dataOnly)
    {
        size_t myMaxSize = max;
        size_t otherMaxSize = other.max;

        if(!dataOnly)
        {
            if(myMaxSize!=otherMaxSize) return false;
        }

        int maxSize = std::max(myMaxSize,otherMaxSize);

        for(int r = 0; r<myMaxSize; r++)
        {
            for(int c = 0; c<myMaxSize; c++)
            {
                if((r>=otherMaxSize || c>=otherMaxSize))
                {
                    if(get(r,c)!=0) return false;
                }
                else
                {
                    if(get(r,c)!=other.get(r,c)) return false;
                }
            }
        }

       for(int r = 0; r<otherMaxSize; r++)
        {
            for(int c = 0; c<otherMaxSize; c++)
            {
                if((r>=myMaxSize|| c>=myMaxSize))
                {
                    if(other.get(r,c)!=0) return false;
                }
                else
                {
                    if(get(r,c)!=other.get(r,c)) return false;
                }
            }
        }
        return true;
    }

};


template <typename T> class RectMatrix
{
public:
    size_t rows = 0;
    size_t columns = 0;
    std::vector<T> matrix;
    bool transposed = false;
public:
    inline size_t getRows()
    {
        if(transposed)
            return columns;
        return rows;
    }
    inline size_t getColumns()
    {
        if(transposed)
            return rows;
        return columns;
    }

    inline void clear()
    {
        matrix.clear();
        rows = 0;
        columns = 0;
    }

    inline T get(size_t row, size_t column)
    {
        if(transposed)
            return matrix[column*columns+row];
        else
            return matrix[row*columns+column];
    }
    inline void set(T value,size_t row, size_t column)
    {
        if(transposed)
            matrix[column*columns+row] = value;
        else
            matrix[row*columns+column] = value;
    }
    void setNewMaxSize(size_t numRows, size_t numColumns)
    {
        if(transposed)
        {
            size_t c = numRows;
            numRows = numColumns;
            numColumns = c;
        }

        if(numRows<=rows && numColumns<=columns)
            return;
        numRows = std::max(rows, numRows);
        numColumns = std::max(columns,numColumns);

        if(numRows<rows*2) numRows = rows*2;
        if(numColumns<columns*2) numColumns = columns*2;

        matrix.resize(numRows*numColumns);

        for(int i=rows-1; i>=0; i--)
        {

            memcpy(&matrix[numColumns*i],&matrix[columns*i], columns*sizeof(T));
            memset(&matrix[numColumns*i+columns], 0, sizeof(T) * (numColumns-columns));

           // memcpy(&matrix[newMax*i],&matrix[max*i], max*sizeof(T));
           // memset(&matrix[newMax*i+max], 0, sizeof(T) * (newMax-max));
        }
        rows = numRows;
        columns = numColumns;
    }

    void print(size_t max_rows, size_t max_columns)
    {
        if(transposed)
        {
            max_rows = std::min(max_rows,columns);
            max_columns = std::min(max_columns,rows);


            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << get(r,c);
                }
                std::cout<<std::endl;
            }
        }
        else
        {
            max_rows = std::min(max_rows,rows);
            max_columns = std::min(max_columns,columns);

            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << get(r,c);
                }
                std::cout<<std::endl;
            }
        }

    }

    void setToCopy(RectMatrix<T>& copyFrom)
    {
        matrix.clear();
        rows = copyFrom.rows;
        columns = copyFrom.columns;
        transposed = copyFrom.transposed;

        matrix.reserve(copyFrom.matrix.size());
        matrix = copyFrom.matrix;
    }

    void transpose()
    {
        if(transposed)
            transposed = false;
        else
            transposed = true;
    }



    bool equals(RectMatrix<T>& other,bool dataOnly)
    {
        size_t myRows = rows;
        size_t myColumns = columns;
        size_t otherRows = other.rows;
        size_t otherColumns = other.columns;

        if(!dataOnly)
        {
            if(myRows!=otherRows) return false;
            if(myColumns!=otherColumns) return false;
            if(transposed!=other.transposed) return false;
        }

        int maxRows = std::max(myRows,otherRows);
        int maxColumns = std::max(myColumns,otherColumns);

        for(int r = 0; r<myRows; r++)
        {
            for(int c = 0; c<myColumns; c++)
            {
                if( (r>=otherRows || c>=otherColumns))
                {
                    if(get(r,c)!=0) return false;
                }
                else
                {
                    if(get(r,c)!=other.get(r,c)) return false;
                }
            }
        }
        for(int r = 0; r<otherRows; r++)
        {
            for(int c = 0; c<otherColumns; c++)
            {
                if( (r>=myRows || c>=myColumns))
                {
                    if(other.get(r,c)!=0) return false;
                }
                else
                {
                    if(get(r,c)!=other.get(r,c)) return false;
                }
            }
        }


        return true;
    }


};


template <typename T> class Matrix
{
    public:
    class matrixData
    {
        public:
            size_t rows = 0;
            size_t columns = 0;
            std::vector<T> data;
            int pointees = 0;
    };

    matrixData* matrix;
    bool transposed = false;
public:
    Matrix(size_t rows, size_t columns)
    {
        matrix = new matrixData;
        matrix->pointees = 1;
        matrix->data.resize(rows*columns);
        matrix->rows = rows;
        matrix->columns = columns;
    }
    /*
    Matrix( Matrix& other )//copyconstructor
    {
        matrix = other.matrix;
        transposed = other.transposed;
        matrix->pointees++;

    }
    */
    ~Matrix()
    {
        matrix->pointees -- ;
        if(matrix->pointees < 1)
        {
            delete matrix;
        }
    }
    void shadow(Matrix<T>& toShadow)
    {
        if(matrix->pointees == 1)
        {
            delete matrix;
        }
        matrix = toShadow.matrix;
        transposed = toShadow.transposed;
        matrix->pointees++;
    }



    void transpose()
    {
        if(transposed)
        {
            transposed = false;
        }
        else
        {
            transposed = true;
        }
    }

    inline size_t getRows()
    {
        if(transposed)
            return matrix->columns;
        else
            return matrix->rows;
    }
    inline size_t getColumns()
    {
        if(transposed)
            return matrix->rows;
        else
            return matrix->columns;
    }
    inline void clear()
    {
        matrix->data.clear();
        matrix->columns = 0;
        matrix->rows = 0;
    }

    void setNewMaxSize(size_t numRows, size_t numColumns)
    {
        const size_t rows = matrix->rows;
        const size_t columns = matrix->columns;

        if(transposed)
        {
            size_t c = numRows;
            numRows = numColumns;
            numColumns = c;
        }

        if(numRows<=rows && numColumns<=columns)
            return;
        numRows = std::max(rows, numRows);
        numColumns = std::max(columns,numColumns);

        if(numRows<rows*2) numRows = rows*2;
        if(numColumns<columns*2) numColumns = columns*2;

        matrix->data.resize(numRows*numColumns);
        for(int i=rows-1; i>=0; i--)
        {
            memcpy(&matrix->data[numColumns*i],&matrix->data[columns*i], columns*sizeof(T));
            memset(&matrix->data[numColumns*i+columns], 0, sizeof(T) * (numColumns-columns));
        }
        matrix->rows = numRows;
        matrix->columns = numColumns;
    }

    inline T get(size_t row, size_t column)
    {
        const size_t columns = matrix->columns;
        if(transposed)
            return matrix->data[column*columns+row];
        else
            return matrix->data[row*columns+column];
    }
    inline T set(T value, size_t row, size_t column)
    {
        const size_t columns = matrix->columns;
        if(transposed)
            matrix->data[column*columns+row] = value;
        else
            matrix->data[row*columns+column] = value;
    }
    inline void add(T value,size_t row, size_t column)
    {
        const size_t columns = matrix->columns;
        if(transposed)
            matrix->data[column*columns+row] += value;
        else
            matrix->data[row*columns+column] += value;
    }
    inline void subtract(T value,size_t row, size_t column)
    {
        const size_t columns = matrix->columns;
        if(transposed)
            matrix->data[column*columns+row] -= value;
        else
            matrix->data[row*columns+column] -= value;
    }

    void mergeRows(size_t row1, size_t row2)
    {
       for(size_t c = 0; c<getRows(); c++)
        {
            add(get(row2,c),row1,c);
            set(0,row2,c);
        }
    }


    void print(size_t max_rows, size_t max_columns)
    {
        const size_t columns = matrix->columns;
        const size_t rows = matrix->rows;

        if(transposed)
        {
            max_rows = std::min(max_rows,columns);
            max_columns = std::min(max_columns,rows);


            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << get(r,c);
                }
                std::cout<<std::endl;
            }
        }
        else
        {
            max_rows = std::min(max_rows,rows);
            max_columns = std::min(max_columns,columns);

            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << matrix->data[r*matrix->columns+c];
                }
                std::cout<<std::endl;
            }
        }

        //for(int i = 0;i<matrix->data.size();i++)
        //    std::cout << "   " << matrix->data[i];
        //std::cout << std::endl;

    }

};




template <typename T> class Matrix2
{

public:
    class matrixData
    {
        public:
            size_t rows = 0;
            size_t columns = 0;
            std::vector<T> matrix;
    };
    matrixData* matrixData_pointer;
    matrixData& matrix;
    bool transposed = false;

public:

    Matrix2() : matrix(*(new matrixData))
    {
        matrix.rows = 0;
        matrix.columns = 0;
        matrix.matrix.resize(matrix.rows*matrix.columns);
        matrixData_pointer = &matrix;
    }
    Matrix2(int rows, int columns) : matrix(*(new matrixData))
    {
        matrixData_pointer = &matrix;
        matrix.matrix.resize(rows*columns);
        matrix.rows = rows;
        matrix.columns = columns;
    };
    Matrix2(Matrix2<T>& shadow) : matrix(shadow.matrix)
    {
        transposed = shadow.transposed;
    };
    ~Matrix2()
    {
        delete matrixData_pointer;
    }

    inline void clear()
    {
        matrix.matrix.clear();
        matrix.columns = 0;
        matrix.rows = 0;
    }
    inline size_t getRows()
    {
        if(transposed)
            return matrix->columns;
        else
            return matrix->rows;
    }
    inline size_t getColumns()
    {
        if(transposed)
            return matrix->rows;
        else
            return matrix->columns;
    }
    void setNewMaxSize(size_t numRows, size_t numColumns)
    {
        if(transposed)
        {
            size_t c = numRows;
            numRows = numColumns;
            numColumns = c;
        }

        if(numRows<=matrix.rows && numColumns<=matrix.columns)
            return;
        numRows = std::max(matrix.rows, numRows);
        numColumns = std::max(matrix.columns,numColumns);

        matrix.matrix.resize(numRows*numColumns);
        for(int i=matrix.rows-1; i>=0; i--)
        {
            memcpy(&matrix.matrix[numColumns*i],&matrix.matrix[matrix.columns*i], matrix.columns*sizeof(T));
            memset(&matrix.matrix[numColumns*i+matrix.columns], 0, sizeof(T) * (numColumns-matrix.columns));
        }
        matrix.rows = numRows;
        matrix.columns = numColumns;
    }

    inline T get(size_t row, size_t column)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
            return matrix.matrix[column*columns+row];
        else
            return matrix.matrix[row*columns+column];
    }


    inline void add(T value,size_t row, size_t column)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
            matrix.matrix[column*columns+row] += value;
        else
            matrix.matrix[row*columns+column] += value;
    }

    inline void subtract(T value,size_t row, size_t column)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
            matrix.matrix[column*columns+row] -= value;
        else
            matrix.matrix[row*columns+column] -= value;
    }


    inline void set(T value,size_t row, size_t column)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
            matrix.matrix[column*columns+row] = value;
        else
            matrix.matrix[row*columns+column] = value;
    }


    inline void set2(T value,size_t row, size_t column)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
            matrix.matrix[column*columns+row] = value;
        else
            matrix.matrix[row*columns+column] = value;
    }
    void print(size_t max_rows, size_t max_columns)
    {
        const size_t columns = matrix.columns;
        const size_t rows = matrix.rows;

        if(transposed)
        {
            max_rows = std::min(max_rows,columns);
            max_columns = std::min(max_columns,rows);


            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << get(r,c);
                }
                std::cout<<std::endl;
            }
        }
        else
        {
            max_rows = std::min(max_rows,rows);
            max_columns = std::min(max_columns,columns);

            for(int r = 0; r<max_rows ; r++){
                for(int c = 0; c<max_columns ; c++){
                    std::cout << "\t" << matrix.matrix[r*max_columns+c];
                }
                std::cout<<std::endl;
            }
        }


    }


    void transpose()
    {
        if(transposed)
        {
            transposed = false;
        }
        else
        {
            transposed = true;
        }
    }


};


#endif // LINKCOUNT_H_INCLUDED
