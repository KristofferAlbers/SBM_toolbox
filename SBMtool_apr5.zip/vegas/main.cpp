/**
Defines the main function of the application

and implements global functions defined in main.h
*/

#include "main.h"

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iomanip>
#include <omp.h>

#include "NetworkDocument.h"
#include "ClusteringDocument.h"

#include "Network.h"
#include "Clustering.h"
#include "Clustering_final.h"

#include "Sampler.h"

//#include "IrmBernoulli_collapsed.h"
//#include "IrmBernoulli_collapsed_bipartite.h"
//#include "IrmBernoulli_collapsed_finite.h"
//#include "IrmBernoulli_collapsed_finite_bipartite.h"



#include "Options.h"
#include "settings.h"

#include "LinkCount.h"

#include "Scheduler.h"
#include "ConfigFileParser.h"

#include "FunctionelTest.h"


using namespace std;

std::string _version("1");
std::string _executename("vegas");

//print information about available schedulers, models and samplers\
as requested by the user.
int main_printinfo(int argc, char *argv[])
{
    if(argc == 1)
    {
        std::cout << "usage:" << std::endl;
        std::cout << " \tinput: info scheduler" << std::endl;
        std::cout << " \t\tdispaly names for all available schedulers" << std::endl;
        std::cout << " \tinput: info scheduler [schedulername]" << std::endl;
        std::cout << " \t\tdispaly settings for scheduler [schedulername]" << std::endl;
        std::cout << " \tinput: info model" << std::endl;
        std::cout << " \t\tdispaly names for all available models" << std::endl;
        std::cout << " \tinput: info model [modelname]" << std::endl;
        std::cout << " \t\tdispaly parameters and settings of model [modelname]" << std::endl;
        std::cout << " \tinput: info mcmcsampler" << std::endl;
        std::cout << " \t\tdispaly names for all available samplers" << std::endl;
        std::cout << " \tinput: info mcmcsampler [samplername]" << std::endl;
        std::cout << " \t\tdispaly settings for sampler [samplername]" << std::endl;
        std::cout << " \tinput: info mapsampler [samplername]" << std::endl;
        std::cout << " \t\tdispaly settings for mapsampler [samplername]" << std::endl;

        exit(0);
    }
    if(argc>1)
    {
        std::string arg1(argv[1]);
        if(argc > 2)
        {
            std::string arg2(argv[2]);
            if(arg1 == "info" && arg2 == "version")
            {
                std::cout << _executename << " ver: " << _version << std::endl;
            }
            else if(arg1 == "info" && (arg2 == "scheduler" || arg2 == "schedulers") )
            {
                if(argc > 3 )
                {
                    std::string arg3(argv[3]);
                        std::unique_ptr<Scheduler> scheduler = Factory<Scheduler>::create(arg3);
                        std::vector<SettingDescription> sds = scheduler->getSettingDescriptions();
                        for(SettingDescription sd : sds)
                        {
                            std::string settingName(sd.name_);
                            std::string settingType(sd.type_);
                            std::string settingDescription(sd.shortDescription_);
                            bool critical = sd.critical_;
                            std::cout << "setting:" << std::endl;
                            std::cout << "\tname: " << settingName << std::endl;
                            std::cout << "\ttype: "<< settingType << std::endl;
                            std::cout << "\tdescription: "<< settingDescription<< std::endl;
                            std::cout << "\tcritical: "<< critical << std::endl;
                            if(sd.hasInitialBool)
                                std::cout << "\tinitial_bool: " << sd.initial_bool << std::endl;
                            if(sd.hasInitialString)
                                std::cout << "\tinitial_string: " << sd.initial_string << std::endl;
                            if(sd.hasInitialFloat)
                                std::cout << "\tinitial_float: " << sd.initial_float << std::endl;
                            if(sd.hasInitialInt)
                                std::cout << "\tinitial_int: " << sd.initial_int << std::endl;
                            if(sd.hasMutualExclusiveGroup)
                                std::cout << "\tmutual_exclusive_group: " << sd.mutualExclusiveGroup_<< std::endl;
                            std::string settingLongDescription(sd.longDescription_);
                            if(sd.hasLongDescription)
                            {
                                std::cout << "\tlongdescription: "<< settingLongDescription<< std::endl;
                            }
                        }

                }
                else
                {
                        std::map<std::string, BaseCreator<Scheduler>*> schedulerMap = Factory<Scheduler>::instance().registerMap;
                        for(auto i : schedulerMap)
                        {
                            std::string schedulerName(i.first);
                            std::cout << "\t"<< schedulerName << std::endl;
                        }
                }

            }
            else if(arg1 == "info" && (arg2 == "model" || arg2 == "models") )
            {
                if(argc > 3)
                {
                    std::string arg3(argv[3]);
                        std::unique_ptr<StatisticalModel> model = Factory<StatisticalModel>::create(arg3);
                        std::vector<ParameterDescription> pds = model->getParameterDescriptions();
                        for(ParameterDescription pd : pds)
                        {
                            std::string parameterName(pd.name_);
                            std::string parameterType(pd.type_);
                            std::string parameterDescription(pd.shortDescription_);
                            std::cout << "parameter:"<< std::endl;
                            std::cout << "\tname: "<< parameterName << std::endl;
                            std::cout << "\ttype: "<< parameterType << std::endl;
                            std::cout << "\tdescription: "<< parameterDescription<< std::endl;
                            std::string parameterLongDescription(pd.longDescription_);
                            if(pd.hasLongDescription)
                            {
                                std::cout << "\tlongdescription: "<< parameterLongDescription<< std::endl;
                            }
                        }
                        std::vector<SettingDescription> sds = model->getSettingDescriptions();
                        for(SettingDescription sd : sds)
                        {
                            std::string settingName(sd.name_);
                            std::string settingType(sd.type_);
                            std::string settingDescription(sd.shortDescription_);
                            bool critical = sd.critical_;
                            std::cout << "setting:" << std::endl;
                            std::cout << "\tname: " << settingName << std::endl;
                            std::cout << "\ttype: "<< settingType << std::endl;
                            std::cout << "\tdescription: "<< settingDescription<< std::endl;
                            std::cout << "\tcritical: "<< critical << std::endl;
                            if(sd.hasInitialBool)
                                std::cout << "\tinitial_bool: " << sd.initial_bool << std::endl;
                            if(sd.hasInitialString)
                                std::cout << "\tinitial_string: " << sd.initial_string << std::endl;
                            if(sd.hasInitialFloat)
                                std::cout << "\tinitial_float: " << sd.initial_float << std::endl;
                            if(sd.hasInitialInt)
                                std::cout << "\tinitial_int: " << sd.initial_int << std::endl;
                            if(sd.hasMutualExclusiveGroup)
                                std::cout << "\tmutual_exclusive_group: " << sd.mutualExclusiveGroup_<< std::endl;
                            std::string settingLongDescription(sd.longDescription_);
                            if(sd.hasLongDescription)
                            {
                                std::cout << "\tlongdescription: "<< settingLongDescription<< std::endl;
                            }
                        }
                }
                else
                {
                        std::map<std::string, BaseCreator<StatisticalModel>*> modelMap = Factory<StatisticalModel>::instance().registerMap;
                        for(auto i : modelMap)
                        {
                            std::string modelName(i.first);
                            std::cout << "\t"<< modelName << std::endl;
                        }
                }
            }
            else if(arg1 == "info" && (arg2 == "mcmcsampler" || arg2 == "mcmcsamplers" || arg2 == "mcmc") )
            {
                if(argc>3)
                {
                    std::string arg3(argv[3]);
                    std::unique_ptr<MCMC_sampler> sampler = Factory<MCMC_sampler>::create(arg3);
                    std::vector<SettingDescription> sds = sampler->getSettingDescriptions();
                    for(SettingDescription sd : sds)
                    {
                        std::string settingName(sd.name_);
                        std::string settingType(sd.type_);
                        std::string settingDescription(sd.shortDescription_);
                        bool critical = sd.critical_;
                        std::cout << "setting:" << std::endl;
                        std::cout << "\tname: " << settingName << std::endl;
                        std::cout << "\ttype: "<< settingType << std::endl;
                        std::cout << "\tdescription: "<< settingDescription<< std::endl;
                        std::cout << "\tcritical: "<< critical << std::endl;
                        if(sd.hasInitialBool)
                            std::cout << "\tinitial_bool: " << sd.initial_bool << std::endl;
                        if(sd.hasInitialString)
                            std::cout << "\tinitial_string: " << sd.initial_string << std::endl;
                        if(sd.hasInitialFloat)
                            std::cout << "\tinitial_float: " << sd.initial_float << std::endl;
                        if(sd.hasInitialInt)
                            std::cout << "\tinitial_int: " << sd.initial_int << std::endl;
                    }
                }
                else
                {
                    std::map<std::string, BaseCreator<MCMC_sampler>*> samplerMap = Factory<MCMC_sampler>::instance().registerMap;
                    for(auto i : samplerMap)
                    {
                        std::string samplerName(i.first);
                        std::cout << ""<< samplerName << std::endl;
                    }
                }
            }
             else if(arg1 == "info" && (arg2 == "maxsamplers" || arg2 == "max" || arg2 == "map" || arg2 == "mapsamplers") )
            {
                if(argc>3)
                {
                    std::string arg3(argv[3]);
                    std::unique_ptr<Max_sampler> sampler = Factory<Max_sampler>::create(arg3);
                    std::vector<SettingDescription> sds = sampler->getSettingDescriptions();
                    for(SettingDescription sd : sds)
                    {
                        std::string settingName(sd.name_);
                        std::string settingType(sd.type_);
                        std::string settingDescription(sd.shortDescription_);
                        bool critical = sd.critical_;
                        std::cout << "setting:" << std::endl;
                        std::cout << "\tname: " << settingName << std::endl;
                        std::cout << "\ttype: "<< settingType << std::endl;
                        std::cout << "\tdescription: "<< settingDescription<< std::endl;
                        std::cout << "\tcritical: "<< critical << std::endl;
                        if(sd.hasInitialBool)
                            std::cout << "\tinitial_bool: " << sd.initial_bool << std::endl;
                        if(sd.hasInitialString)
                            std::cout << "\tinitial_string: " << sd.initial_string << std::endl;
                        if(sd.hasInitialFloat)
                            std::cout << "\tinitial_float: " << sd.initial_float << std::endl;
                        if(sd.hasInitialInt)
                            std::cout << "\tinitial_int: " << sd.initial_int << std::endl;
                    }
                }
                else
                {
                    std::map<std::string, BaseCreator<Max_sampler>*> samplerMap = Factory<Max_sampler>::instance().registerMap;
                    for(auto i : samplerMap)
                    {
                        std::string samplerName(i.first);
                        std::cout << ""<< samplerName << std::endl;
                    }
                }
            }
        }
        exit(0);
    }
}

void saveString(std::string filename, int sweep, std::string content)
{
        FILE* file = fopen(filename.c_str(), "a");
        fprintf (file, "%d\t%s\n",sweep,content.c_str());
        fclose(file);
}

void saveModel(std::string filename, int sweep, double loglikelihood, double logprior, double logposterior)
{
        FILE* file = fopen(filename.c_str(), "a");
        fprintf (file, "%d\t%f %f %f \n",sweep,loglikelihood,logprior,logposterior);
        fclose(file);
}

void saveParameters(std::string savepath, int sweep, StatisticalModel* model_p, std::vector<ParameterDescription> model_parameters)
{

    for(ParameterDescription pd : model_parameters)
    {
        std::string parameterName(pd.name_);
        std::string filename = savepath + parameterName + ".txt";
        Parameter* parameter = model_p->getParameter(parameterName);
        std::string content = parameter->toString();
        saveString(filename,sweep,content);
    }

}


int main(int argc, char *argv[])
{
    if(argc == 1 || std::string(argv[1]) == "info")
    {
        main_printinfo(argc,argv);
    }
    //load and parse configuration file
    std::string cf(argv[1]);
    ConfigFileParser cfp(cf);

    std::cout << ">>configuration file parsed" << std::endl;

    Options modelOptions;
    for(size_t i = 0; i<cfp.model.optionNames.size(); i++)
    {
        modelOptions.insert( std::pair<std::string,std::string>(cfp.model.optionNames[i], cfp.model.optionValues[i]) );
    }
    std::unique_ptr<StatisticalModel> model = Factory<StatisticalModel>::create(cfp.model.type,modelOptions);


    std::vector<std::unique_ptr<MCMC_sampler>> mcmcsamplers;
    for(ConfigFileParser::configsettings cf:cfp.mcmcsamplers)
    {
        Options samplerOptions;
        for(size_t i = 0; i<cf.optionNames.size(); i++)
        {
            samplerOptions.insert( std::pair<std::string,std::string>(cf.optionNames[i], cf.optionValues[i]) );
        }
        Parameter* pp = model->getParameter(cf.parameter);
        samplerOptions.insert( std::pair<std::string,Parameter*>("parameter", pp) );

        std::unique_ptr<MCMC_sampler> sampler = Factory<MCMC_sampler>::create(cf.type,samplerOptions);

        mcmcsamplers.push_back(std::move(sampler));
    }

    std::vector<std::unique_ptr<Max_sampler>> maxsamplers;
    for(ConfigFileParser::configsettings cf:cfp.maxsamplers)
    {
        Options samplerOptions;
        for(size_t i = 0; i<cf.optionNames.size(); i++)
        {
            samplerOptions.insert( std::pair<std::string,std::string>(cf.optionNames[i], cf.optionValues[i]) );
        }
        Parameter* pp = model->getParameter(cf.parameter);
        samplerOptions.insert( std::pair<std::string,Parameter*>("parameter", pp) );

        std::unique_ptr<Max_sampler> sampler = Factory<Max_sampler>::create(cf.type,samplerOptions);
        maxsamplers.push_back(std::move(sampler));
    }


    Options scheduleOptions;
    for(size_t i = 0; i<cfp.scheduler.optionNames.size(); i++)
    {
        scheduleOptions.insert( std::pair<std::string,std::string>(cfp.scheduler.optionNames[i], cfp.scheduler.optionValues[i]) );
    }


    std::cout << ">>scheduler type = " << cfp.scheduler.type << std::endl;
    std::unique_ptr<Scheduler> scheduler = Factory<Scheduler>::create(cfp.scheduler.type,scheduleOptions);

    //run sampling schedule
    scheduler->runSchedule(model.get(),mcmcsamplers,maxsamplers);

    //execution done
    std::cout << ">>execution done" << std::endl;
    exit(0);
}

int reportError(std::string error_string,double criticality)
{
    std::cout << "ERROR: " << error_string << std::endl;
    exit(0);
};
int reportError(std::string error_title,std::string error_string,double criticality)
{
    std::cout << error_title <<" " << error_string << std::endl;
    exit(0);
};
int reportWarning(std::string warning_string,double criticality)
{
    std::cout << warning_string << std::endl;
};
int reportWarning(std::string warning_title,std::string warning_string,double criticality)
{
    std::cout << warning_title <<" " << warning_string << std::endl;
};
int reportInfo(std::string info_string)
{
    std::cout << info_string << std::endl;
}
int reportInfo(std::string info_string,double criticality)
{
    std::cout << info_string << std::endl;
}
int reportInfo(std::string info_title,std::string info_string,double criticality)
{
    std::cout << info_title <<" " << info_string << std::endl;
}
