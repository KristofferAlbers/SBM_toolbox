#ifndef PARAMETER_H_INCLUDED
#define PARAMETER_H_INCLUDED


#include "Clustering.h"
#include "Clustering_final.h"
#include "ClusteringDocument.h"
#include "StatisticalModel.h"

#include <string>

class StatisticalModel;

class Parameter
{
public:
    StatisticalModel* model_;   //pointer to the model, the parameter belongs to
    Options options_;
    std::string name_;          //name of the parameter
    std::string type_;          //type of parameter
    std::string description_;   //description of parameter

public:
    Parameter(StatisticalModel* m, std::string n);

    Parameter(StatisticalModel* m, std::string n,Options o);
    virtual ~Parameter() {}

    std::string getModelName();
    std::string getName();
    std::string getType();
    std::string getDescription();

    virtual std::string toString() = 0;
    virtual void setFromString(std::string str) = 0;

};




class Real : public Parameter
{
public:
    const std::string TYPENAME = "REAL";
    Real(StatisticalModel* m, std::string n) : Parameter(m, n) { type_ = TYPENAME; }

    std::function<double()> computeLogPosterior;
    std::function<double(double)> logPosteriorRatio;
    std::function<double()> get;
    std::function<void(double)>set;

    std::string toString()
    {
        double val = get();
        return std::string(std::to_string(val));
    }
    void setFromString(std::string str)
    {
        double val = std::stod(str);
        set(val);
    }

};

class Integer : public Parameter
{
public:
    const std::string TYPENAME = "INT";
    Integer(StatisticalModel* m, std::string n) : Parameter(m, n) { type_ = TYPENAME; }

    std::function<double()> computeLogPosterior;
    std::function<double(int)> logPosteriorRatio;
    std::function<int()> get;
    std::function<void(int)>set;

    std::string toString()
    {
        double val = get();
        return std::string(std::to_string(val));
    }
    void setFromString(std::string str)
    {
        double val = std::stoi(str);
        set(val);
    }

};

class Clustering_Parameter : public Parameter
{
    public:
        Clustering_Parameter(StatisticalModel *m,std::string n) : Parameter(m,n) { };

    std::function<double()> computeLogPosterior;
    std::function<double(int)> logPosteriorRatio;
    std::function<size_t()> getNumberOfItems;
    std::function<ClusteringDocument()> get;
    std::function<void(ClusteringDocument&)>set;

    std::string toString(){ return "";};
    void setFromString(std::string str){ std::cout << "???" << std::endl;};
    //virtual void setFromString(std::string str) = 0;

};

class ClusteringInfinite_Parameter : public Clustering_Parameter
{
public:
    const std::string TYPENAME = "ClusteringInfinite";
    ClusteringInfinite_Parameter(StatisticalModel *m,std::string n) : Clustering_Parameter(m,n) { type_ = TYPENAME; };
    std::function<Clustering*()> getDataPointer;
    std::function<partial_vector<double>(size_t,Clustering::iterator,Clustering::iterator,bool)> effectiveLogPosteriorRatio;
    std::function<partial_vector<double>(size_t,std::vector<size_t>&)> effectiveLogPosteriorRatio_restricted;
    std::function<double(size_t, size_t)> logPosteriorRatio_mergeClusters;
    std::function<void(size_t,size_t)> moveItem;
    std::function<void(size_t)> moveItem_newCluster;
    std::function<void(size_t,size_t)> mergeClusters;

    std::string toString()
    {
        Clustering& clust = *getDataPointer();
        ClusteringDocument cd(clust);
        return cd.toString();
    };

    std::function<void(std::string)> setFromString_implement;
    void setFromString(std::string str){setFromString_implement(str); };

};

class ClusteringFinite_Parameter : public Clustering_Parameter
{
public:
    const std::string TYPENAME = "ClusteringFinite";
    ClusteringFinite_Parameter(StatisticalModel *m,std::string n) : Clustering_Parameter(m,n) {type_ = TYPENAME; };

    std::function<Clustering_finite*()> getDataPointer;
    std::function<partial_vector<double>(size_t,Clustering_finite::iterator,Clustering_finite::iterator,bool)> effectiveLogPosteriorRatio;
    std::function<partial_vector<double>(size_t,std::vector<size_t>&)> effectiveLogPosteriorRatio_restricted;
    std::function<void(size_t,size_t)> moveItem;


    std::string toString()
    {
        Clustering_finite& clust = *getDataPointer();
        ClusteringDocument cd(clust);
        return cd.toString();
    };

    std::function<void(std::string)> setFromString_implement;
    void setFromString(std::string str){setFromString_implement(str);};

};


#endif // PARAMETER_H_INCLUDED
