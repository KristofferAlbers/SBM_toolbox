/**
This code is provided as is without any warranty!

    This file contains simple utility functions
        - for manipulating vectors
        - obtaining random values
    ideally, these functions should be generilized in order to
    utilize standard matrix manipulation libraries.
*/

#ifndef FOUNDATION_H_INCLUDED
#define FOUNDATION_H_INCLUDED

#include <vector>

const int ORDER_RANDOM_UNIFORM = 1;
const int ORDER_DESCENDING = 2;
const int ORDER_ASCENDING = 3;

inline int randui(int from_including, int to_including){
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(from_including, to_including);
    return dis(gen);
}


template<class T,class V>
inline void sortVectorPair(std::vector<T>* v1,std::vector<V>* v2, int order){

      assert(v1->size() == v2->size());
      std::vector<T>& sources = *v1;
      std::vector<V>& targets = *v2;

      int comparisons = 0;
      switch ( order )
      {
         case ORDER_RANDOM_UNIFORM:
            for(int i = 0 ; i < sources.size() ; i++ )
            {
                int swappos = randui(0,i);
                std::swap( sources[i], sources[swappos] );
                std::swap( targets[i], targets[swappos] );
            }
            break;
         case ORDER_ASCENDING:
            for(int i=1; i<sources.size(); i++)
            {
                if(sources[i]< sources[i-1])
                {
                    int ii = i;
                    T s = sources[i];
                    V t = targets[i];
                    do
                    {
                        sources[ii] = sources[ii - 1];
                        targets[ii] = targets[ii - 1];
                        ii--;
                        comparisons++;
                    }
                    while(ii > 0 && sources[ii - 1] > s);
                    sources[ii] = s;
                    targets[ii] = t;
                }
            }
            break;
         case ORDER_DESCENDING:
            std::cout << "ORDER_DESCENDING not implemented" << std::endl;
            exit(0);
            break;
         default:
            break;
      }

}



#endif // FOUNDATION_H_INCLUDED
