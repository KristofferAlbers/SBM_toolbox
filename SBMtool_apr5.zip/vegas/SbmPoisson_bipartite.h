#ifndef SbmPoisson_bipartite_H_INCLUDED
#define SbmPoisson_bipartite_H_INCLUDED


#include "StatisticalModel.h"
#include "Options.h"
#include "settings.h"
#include "factory.h"
#include "LinkCount.h"
#include "Network.h"
#include "Clustering.h"
#include "ClusteringDocument.h"

#include "tableApproximations.h"

#include <vector>
#include <boost/assign.hpp>
#include <boost/tuple/tuple.hpp>
#include <omp.h>

using namespace std::placeholders;

class SbmPoisson_bipartite : public StatisticalModel
{
    friend class FunctionelTests; //allow functionel test access to private fields


    const static std::string MODELNAME;
    const std::string PARAMETER_CLUSTERING1 = "clustering1";
    const std::string PARAMETER_CLUSTERING2 = "clustering2";
    const std::string PARAMETER_ALPHA1 = "alpha1";
    const std::string PARAMETER_ALPHA2 = "alpha2";
    const std::string PARAMETER_BP = "bp";
    const std::string PARAMETER_BM = "bm";

    const std::string OPT_NETWORK_LINKS = "network.links";
    const std::string OPT_NETWORK_MISSINGLINKS = "network.missinglinks";
    const std::string OPT_CLUSTERING1_CRP = "clustering1.init_crp";
    const std::string OPT_CLUSTERING1_RANDOM = "clustering1.init_random";
    const std::string OPT_CLUSTERING2_CRP = "clustering2.init_crp";
    const std::string OPT_CLUSTERING2_RANDOM = "clustering2.init_random";

    const std::string OPT_TABLEMAX_A = "tablemax_a";
    const std::string OPT_TABLEMAX_B = "tablemax_b";
    const std::string OPT_TABLEMAX_C = "tablemax_c";
    const std::string OPT_ITEMS1 = "items1";
    const std::string OPT_ITEMS2 = "items2";
    const std::string OPT_COMPONENTS1 = "components1";
    const std::string OPT_COMPONENTS2 = "components2";
    const std::string OPT_SUBJECTS = "subjects";

    const std::string OPT_INIT_ALPHA1 = "alpha1.init";
    const std::string OPT_INIT_ALPHA2 = "alpha2.init";
    const std::string OPT_INIT_A = "a.init";
    const std::string OPT_INIT_B = "b.init";
    const std::string OPT_USEMISSING = "withmissing";

    const std::string OPT_USEINDEPENDENTHYPERPARAMETERS = "useindependenthyperparameters";
    const std::string OPT_USECLASSAONLY = "useclass1only";


    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;

template <typename T> class NodeCounts
{
public:
    std::vector<T> nodePairs;
    std::vector<T> linkSum;
    std::vector<T> missingNodePairs;

    void print()
    {
        std::cout << "cluster:\t links \t non \t miss \t links' \t non'" << std::endl;
        for(int i = 0; i < linkSum.size(); i++)
        {
            std::cout << "(i = " << i << " ) \t "<< linkSum[i] << " \t " << nodePairs[i] << " \t " << missingNodePairs[i];
           // std::cout << "\t\t" << nodeLinks_transposed[i] << " \t " << nodeNonLinks_transposed[i] << " \t " << nodeMissingLinks_transposed[i] << std::endl;
           std::cout << std::endl;
        }
        std::cout << std::endl;
    }
};

class SufficientStatistics
{
public:
    Matrix<size_t> linkSum;
    Matrix<size_t> nodePairs;
    Matrix<size_t> missingNodePairs;

    bool usemissing = false;

//    SufficientStatistics(): links(2,2),nonlinks(2,2),missinglinks(2,2){}

    SufficientStatistics(size_t init_rows, size_t init_columns,bool usemissing_) : linkSum(init_rows,init_columns),nodePairs(init_rows,init_columns),missingNodePairs(init_rows,init_columns)
    {
        usemissing = usemissing_;
    }
    SufficientStatistics(SufficientStatistics& shadow, bool transpose) :
        linkSum(shadow.linkSum),nodePairs(shadow.nodePairs),missingNodePairs(shadow.missingNodePairs)
    {
        linkSum.matrix->pointees++;
        nodePairs.matrix->pointees++;
        missingNodePairs.matrix->pointees++;

        usemissing = shadow.usemissing;
        if(transpose)
        {
            linkSum.transpose();
            nodePairs.transpose();
            missingNodePairs.transpose();
        }
    }

    size_t getLinkSum(size_t sourceCluster, size_t targetCluster)
    {
        return linkSum.get(sourceCluster,targetCluster);
        //return links.matrix[sourceCluster*links.columns+targetCluster];
    }

    size_t getNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        return nodePairs.get(sourceCluster,targetCluster);
        //return nonlinks.matrix[sourceCluster*nonlinks.columns+targetCluster];
    }
    size_t getMissingNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        if(usemissing)
        {
            return missingNodePairs.get(sourceCluster,targetCluster);
        }
        else
            return 0;
    }

};

struct HyperParameters_bernoulli
{
    double alphaA_;
    double logalphaA_;
    double alphaB_;
    double logalphaB_;

    double a_;
    double b_;

    std::vector<double> a_values;
    std::vector<double> b_values;


    Clustering_finite* clustA;
    Clustering_finite* clustB;
    double getAlpha(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == clustA)
            return alphaA_;
        else
            return alphaB_;
    }
    double getLogAlpha(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == clustA)
            return logalphaA_;
        else
            return logalphaB_;
    }
    void setAlphaValues(Clustering_finite* clustering_pointer, double newAlpha)
    {
        if(clustering_pointer == clustA)
        {
            alphaA_ = newAlpha;
            logalphaA_ = log(newAlpha);
        }
        else
        {
            alphaB_ = newAlpha;
            logalphaB_ = log(newAlpha);
        }
    }

    double getA(size_t clusterId_classB)
    {
        return a_values[clusterId_classB];
    }
    double getB(size_t clusterId_classB)
    {
        return b_values[clusterId_classB];
    }

};

struct Data
{
    NetworkData<size_t>& data;
    NetworkData<size_t>& missing;
    SufficientStatistics& sufstats;
    Clustering_finite& clustering;
    Clustering_finite& targetClustering;
    size_t K_clustering;
    size_t K_targetClustering;
};

public:

    //clustering data
    Clustering_finite clusteringDataA;
    Clustering_finite clusteringDataB;

    //parameters
    ClusteringFinite_Parameter clusteringA;
    ClusteringFinite_Parameter clusteringB;
    Real alphaA;
    Real alphaB;
    Real a;
    Real b;
    std::vector<Real> a_vector;
    std::vector<Real> b_vector;

    //hyperparameters data
    HyperParameters_bernoulli param;
    //sufficient statistics
    std::vector<SufficientStatistics> sufstatsA;
    std::vector<SufficientStatistics> sufstatsB;
    //options
    size_t K_classA;
    size_t K_classB;

    size_t itemsA;
    size_t itemsB;
    bool usemissing_;
    bool directed;
    bool network_weighted;

    bool bernMixtureOnly;
    bool independentAB;

    std::string missinglinksfile_;
    std::string linksfile_;

    //network data
    std::vector<BipartiteNetwork<size_t>> networks;

    std::vector<Data> dataA;
    std::vector<Data> dataB;

    size_t numSubjects; //number of graphs

    Factorialln factln_table;
    Gammaln gammaln_table;


public:
    SbmPoisson_bipartite() : StatisticalModel(),
        clusteringA(this,PARAMETER_CLUSTERING1), clusteringB(this,PARAMETER_CLUSTERING2),
        alphaA(this,PARAMETER_ALPHA1),alphaB(this,PARAMETER_ALPHA2), a(this,PARAMETER_BP), b(this,PARAMETER_BM),
        gammaln_table(1), factln_table(1)
    {
    }

    SbmPoisson_bipartite(Options o) : StatisticalModel(MODELNAME, o),
        clusteringA(this,PARAMETER_CLUSTERING1), clusteringB(this,PARAMETER_CLUSTERING2),
        alphaA(this,PARAMETER_ALPHA1),alphaB(this,PARAMETER_ALPHA2), a(this,PARAMETER_BP), b(this,PARAMETER_BM),
        gammaln_table(getOption<int>(o,OPT_TABLEMAX_B,10000)),
        factln_table(getOption<int>(o,OPT_TABLEMAX_B,10000))
    {
        //bind parameter functions
        clusteringA.effectiveLogPosteriorRatio = std::bind(&SbmPoisson_bipartite::effectiveLogPosteriorRatio_clustering,this, &dataA, _1,_2,_3,_4);
        clusteringA.effectiveLogPosteriorRatio_restricted = std::bind(&SbmPoisson_bipartite::effectiveLogPosteriorRatio_restricted_clustering, this, &dataA , _1, _2);

        clusteringB.effectiveLogPosteriorRatio = std::bind(&SbmPoisson_bipartite::effectiveLogPosteriorRatio_clustering,this,&dataB,_1,_2,_3,_4);
        clusteringB.effectiveLogPosteriorRatio_restricted = std::bind(&SbmPoisson_bipartite::effectiveLogPosteriorRatio_restricted_clustering, this,&dataB, _1, _2);

        clusteringA.moveItem = std::bind(&SbmPoisson_bipartite::moveItem_clustering, this,  &dataA, _1, _2);

        clusteringB.moveItem = std::bind(&SbmPoisson_bipartite::moveItem_clustering, this,  &dataB, _1, _2);

        clusteringA.getDataPointer = std::bind(&SbmPoisson_bipartite::getDataPointer_clustering,this, &clusteringDataA);
        clusteringA.getNumberOfItems = std::bind(&SbmPoisson_bipartite::getNumberOfItems_clustering,this, &clusteringDataA);
        clusteringA.get = std::bind(&SbmPoisson_bipartite::get_clustering,this, &clusteringDataA);
        clusteringA.set = std::bind(&SbmPoisson_bipartite::set_clustering,this, &clusteringDataA, _1);
        clusteringA.setFromString_implement = std::bind(&SbmPoisson_bipartite::setFromString_clustering,this, &clusteringDataA, _1);

        clusteringB.getDataPointer = std::bind(&SbmPoisson_bipartite::getDataPointer_clustering,this, &clusteringDataB);
        clusteringB.getNumberOfItems = std::bind(&SbmPoisson_bipartite::getNumberOfItems_clustering,this, &clusteringDataB);
        clusteringB.get = std::bind(&SbmPoisson_bipartite::get_clustering,this, &clusteringDataB);
        clusteringB.set = std::bind(&SbmPoisson_bipartite::set_clustering,this, &clusteringDataB, _1);
        clusteringB.setFromString_implement = std::bind(&SbmPoisson_bipartite::setFromString_clustering,this, &clusteringDataB, _1);

        alphaA.get = std::bind(&SbmPoisson_bipartite::get_alpha,this,&clusteringDataA);
        alphaA.set = std::bind(&SbmPoisson_bipartite::set_alpha,this,&clusteringDataA,_1);
        alphaA.logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_alpha, this,&clusteringDataA, _1);

        alphaB.get = std::bind(&SbmPoisson_bipartite::get_alpha,this,&clusteringDataB);
        alphaB.set = std::bind(&SbmPoisson_bipartite::set_alpha,this,&clusteringDataB,_1);
        alphaB.logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_alpha, this,&clusteringDataB, _1);

        a.get = std::bind(&SbmPoisson_bipartite::get_a,this);
        a.set = std::bind(&SbmPoisson_bipartite::set_a,this,_1);
        a.logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_a, this, _1);

        b.get = std::bind(&SbmPoisson_bipartite::get_b,this);
        b.set = std::bind(&SbmPoisson_bipartite::set_b,this,_1);
        b.logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_b, this, _1);

        //parse options
        independentAB = (getOption<bool>(o,OPT_USEINDEPENDENTHYPERPARAMETERS,false));
        bernMixtureOnly = (getOption<bool>(o,OPT_USECLASSAONLY,false));

        itemsA = parseSetting<int>(OPT_ITEMS1,settingDescriptions,o);
        itemsB = parseSetting<int>(OPT_ITEMS2,settingDescriptions,o);
        K_classA = parseSetting<int>(OPT_COMPONENTS1,settingDescriptions,o);
        K_classB = parseSetting<int>(OPT_COMPONENTS2,settingDescriptions,o);
        numSubjects = parseSetting<int>(OPT_SUBJECTS,settingDescriptions,o);

        param.alphaA_ = parseSetting<double>(OPT_INIT_ALPHA1,settingDescriptions,o);
        param.logalphaA_ = log(param.alphaA_);
        param.alphaB_ = parseSetting<double>(OPT_INIT_ALPHA2,settingDescriptions,o);
        param.logalphaB_ = log(param.alphaB_);
        param.a_ = parseSetting<double>(OPT_INIT_A,settingDescriptions,o);
        param.b_ = parseSetting<double>(OPT_INIT_B,settingDescriptions,o);

        usemissing_ = parseSetting<bool>(OPT_USEMISSING,settingDescriptions,o);
        linksfile_ = parseSetting<std::string>(OPT_NETWORK_LINKS,settingDescriptions,o);



        //load network
        network_weighted = true;
        bool zeroindexed = false;
        bool missingweighted = network_weighted;
        bool missingToZero = false;
        if(usemissing_)
        {
            missinglinksfile_ = parseSetting<std::string>(OPT_NETWORK_MISSINGLINKS,settingDescriptions,o);

            BipartiteNetwork<size_t> network(itemsA, itemsB, linksfile_, missinglinksfile_, zeroindexed, missingweighted, missingToZero, network_weighted);
            networks.push_back(network);
        }
        else
        {
            BipartiteNetwork<size_t> network(itemsA, itemsB, linksfile_, zeroindexed, network_weighted);
            networks.push_back(network);
        }


          //initialize clustering
        ClusteringDocument cd1;
        int clust_random1 = parseSetting<int>(OPT_CLUSTERING1_RANDOM,settingDescriptions,o);
        cd1.init_uniform(itemsA,clust_random1);
        ClusteringDocument cd2;
        int clust_random2 = parseSetting<int>(OPT_CLUSTERING2_RANDOM,settingDescriptions,o);
        cd2.init_uniform(itemsB,clust_random2);

        clusteringDataA = Clustering_finite(itemsA,K_classA,cd1.clusteringVector);
        clusteringDataB = Clustering_finite(itemsB,K_classB,cd2.clusteringVector);


        param.clustA = &clusteringDataA;
        param.clustB = &clusteringDataB;

        for(size_t i = 0; i<networks.size(); i++)
        {
            sufstatsA.emplace_back(10,10,usemissing_);
            sufstatsB.emplace_back(sufstatsA[i],true);
            dataA.push_back({networks[i].data_classA,networks[i].missing_classA,sufstatsA[i],clusteringDataA,clusteringDataB,K_classA,K_classB});
            dataB.push_back({networks[i].data_classB,networks[i].missing_classB,sufstatsB[i],clusteringDataB,clusteringDataA,K_classB,K_classA});
        }

        if(independentAB)
        {
            size_t numClusters_classB = K_classB;
            for(size_t clusterId_classB = 0; clusterId_classB< numClusters_classB; clusterId_classB++)
            {
                param.a_values.push_back(param.a_);
                std::string a_name = "a";
                Real a_(this,a_name);
                a_vector.push_back(a_);
                a_vector[clusterId_classB].get = std::bind(&SbmPoisson_bipartite::get_a_vector,this,clusterId_classB);
                a_vector[clusterId_classB].set = std::bind(&SbmPoisson_bipartite::set_a_vector,this,clusterId_classB,_1);
                a_vector[clusterId_classB].logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_a_vector,this,clusterId_classB,_1);

                param.b_values.push_back(param.b_);
                std::string b_name = "b";
                Real b_(this,b_name);
                b_vector.push_back(b_);
                b_vector[clusterId_classB].get = std::bind(&SbmPoisson_bipartite::get_b_vector,this,clusterId_classB);
                b_vector[clusterId_classB].set = std::bind(&SbmPoisson_bipartite::set_b_vector,this,clusterId_classB,_1);
                b_vector[clusterId_classB].logPosteriorRatio = std::bind(&SbmPoisson_bipartite::logPosteriorRatio_b_vector,this,clusterId_classB,_1);
            }
        }

        computeAllSufficientStatistics();

        reportInfo("model setup completed",.5);
    }


      double computeLogPrior();
    double computeLogLikelihood();
    double computeLogPosterior();
    double computeLogLikelihood(Data& data_, Clustering_finite& clustering_);

    //assist functions
    void computeAllSufficientStatistics();
    void computeSufficientStatistics(Data& dataA_,Data& dataB_,Clustering_finite& clusteringA_, Clustering_finite& clusteringB_);


    void getNodeCounts(size_t nodeId, Data& data_, Clustering_finite& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts);

    inline double logPrior_effectiveChange(Clustering_finite& clustering, size_t cluster, size_t currentCluster, size_t currentClusterSize);
    inline double logPrior_effectiveChange_newCluster(Clustering_finite& clustering);


    inline double logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering_finite& clustering_, HyperParameters_bernoulli& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts);
    inline double logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, HyperParameters_bernoulli& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);

    //clustering functions
    partial_vector<double> effectiveLogPosteriorRatio_clustering(std::vector<Data>* data_pointer, size_t nodeId, Clustering_finite::iterator begin, Clustering_finite::iterator end, bool appendForNewCluster);
    partial_vector<double> effectiveLogPosteriorRatio_restricted_clustering(std::vector<Data>* data_pointer, size_t nodeId,std::vector<size_t>& restrictedClusters);
    //double effectiveLogPosteriorRatio_mergeClusters_clustering(std::vector<Data>* data_pointer, size_t cluster1, size_t cluster2);

    void moveItem_clustering(std::vector<Data>* data_pointer, size_t itemId, size_t clusterId);
    //void moveItem_newCluster_clustering(std::vector<Data>* data_pointer, size_t itemId);
    //void mergeClusters_clustering(std::vector<Data>* data_pointer, size_t cluster1,size_t cluster2);

    size_t getMaxNumberOfClusters(Clustering_finite* clustering_pointer);

    Clustering_finite* getDataPointer_clustering(Clustering_finite* clustering_pointer);
    size_t getNumberOfItems_clustering(Clustering_finite* clustering_pointer);


    ClusteringDocument get_clustering(Clustering_finite* clustering_pointer);
    void set_clustering(Clustering_finite* clustering_pointer, ClusteringDocument& cd);
    void setFromString_clustering(Clustering_finite* clustering_pointer, std::string str);


    //alpha functions
    double get_alpha(Clustering_finite* clustering_pointer);
    void set_alpha(Clustering_finite* clustering_pointer,double val);
    double logPosteriorRatio_alpha(Clustering_finite* clustering_pointer,double new_alpha);

    //bp functions
    double get_a();
    void set_a(double val);
    double logPosteriorRatio_a(double new_a);
    double get_a_vector(size_t clusterId_classB);
    void set_a_vector(size_t clusterId_classB, double val);
    double logPosteriorRatio_a_vector(size_t clusterId_classB, double new_a);

    //bm functions
    double get_b();
    void set_b(double val);
    double logPosteriorRatio_b(double new_b);
    double get_b_vector(size_t clusterId_classB);
    void set_b_vector(size_t clusterId_classB, double val);
    double logPosteriorRatio_b_vector(size_t clusterId_classB, double new_b);

    double effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t clusterId);

    static Creator<StatisticalModel, SbmPoisson_bipartite> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

    size_t getK(Clustering_finite* clustering_pointer)
    {
        if(clustering_pointer == param.clustA)
            return K_classA;
        else
            return K_classB;
    }


    double FUNC(size_t ai, double ad, size_t bi, double bd)
    {
        //return betaln_table.betaln(ai,ad,bi,bd);
        return gammaln_table.gammaln(ai,ad) - (ai+ad)*LOG(bi,bd);
    }
    inline double LOG(size_t bi, double bd)
    {
        return log(bi+bd);
    }

};

class MixturePoisson_collapsed_finite : public SbmPoisson_bipartite
{
public:
    const static std::string MODELNAME;
    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;


    MixturePoisson_collapsed_finite() : SbmPoisson_bipartite()
    {
    }

    MixturePoisson_collapsed_finite(Options o) : SbmPoisson_bipartite(o)
    {
        bernMixtureOnly = true;
        ClusteringDocument cd2;
        cd2.init_uniform(itemsB,itemsB);
        computeAllSufficientStatistics();
    }

    static Creator<StatisticalModel, MixturePoisson_collapsed_finite> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

};




#endif // SbmPoisson_bipartite_H_INCLUDED
