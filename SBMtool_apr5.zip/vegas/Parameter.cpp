/**
This code is provided as is without any warranty!

Implementation of the parameter base class.
By a StatisticalModel pointer, the parameter is added to the model when constructed.
*/

#ifndef PARAMETER_CPP_INCLUDED
#define PARAMETER_CPP_INCLUDED

#include "Parameter.h"

Parameter::Parameter(StatisticalModel* m, std::string n) : model_(m), name_(n), options_(m->getParameterOptions(n))
{
    m->addParameter(this);
}

std::string Parameter::getModelName()
{
    return model_->getName();
}
std::string Parameter::getName()
{
    return name_;
}
std::string Parameter::getType()
{
    return type_;
}
std::string Parameter::getDescription()
{
    return description_;
}

#endif // PARAMETER_CPP_INCLUDED
