/**
This code is provided as is without any warranty!

Defines global functions, (implemented in the main.cpp file).
These are used to report errors, warnings and infomation while
running the application. According to the reported level of
criticality of the information, the application can act
appropriately.
*/

#ifndef MY_FOO_HEADER_
#define MY_FOO_HEADER_

#include <iostream>
#include <string>

    int reportError(std::string error_string,double criticality);
    int reportError(std::string error_title,std::string error_string,double criticality);

    int reportWarning(std::string warning_string,double criticality);
    int reportWarning(std::string warning_title,std::string warning_string,double criticality);

    int reportInfo(std::string info_string);
    int reportInfo(std::string info_string,double criticality);
    int reportInfo(std::string info_title,std::string info_string,double criticality);



#endif
