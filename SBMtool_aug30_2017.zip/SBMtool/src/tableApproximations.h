/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This file defines classes used to store and compute table lookups various functions
- logarithm of the gamma function.
- logarithm of the beta function.
- logarithm of the factorial function.
*/

#ifndef TABLEAPPROXIMATIONS_H_INCLUDED
#define TABLEAPPROXIMATIONS_H_INCLUDED


#include <math.h>   //defines the library functions

/**
    An object of class Gammaln represents a lookup table of
    log-gamma values. Lookups in the table are given by two
    valuse, an integer i and a real d (to request lgamma(i+d),
    expecting d to be the same for consequtive lookups.
    The table is generically recomputed when d is changes
*/
class Gammaln{

    double* table;
    double d_;
    double tablesize_;

    double last_d;
    double repeatToCache = 10;      //number of repeated requests before the table is recomputed
    double timesRepeted = 0;        //current count for number of repeated requests
public:
    /**
        constructor for table of size @param tablesize
    */
    Gammaln(int tablesize)
    {
        tablesize_ = tablesize;
    	table = new double[tablesize];
    }
    ~Gammaln()
    {
        delete table;
    }

    /**
        computes all values in the lookup table according to @param d
        such that the i'th stored value is lgamma(i+d).
    */
    void setTable(double d)
    {
        d_ = d;
        table[0] = lgamma(d);
        double olda = 1+d;
        double old = lgamma(olda);
        table[1] = old;

        for(int i=2;i<tablesize_;i++)
        {
            old = old+log(olda);
            table[i] = old;
            olda = i+d;
        }

    }

    /**
        Obtain the logarithm of the gamma function
        @param i - integer value
        @param d - real value
        @return lgamma(i+d)
        returns the logarithm of the gamma function for the input values.
        If the value is stored in the lookup table (table is currently
        set to store values for the input value d)i t is returned from the
        table, otherwise the library function lgamma(i+d) is returned
    */
    inline double gammaln(size_t i, double d)
    {

        if(d == d_) //if table is currently storing values based on d
        {
            if(i>=tablesize_)
            {
                return lgamma(i+d);
            }
            else
            {
                return table[i];
            }
        }
        else
        {
            if(last_d == d) //notice that the same d is requested as in last request
            {
            	timesRepeted++;
                	if(timesRepeted == repeatToCache)   //recompute lookup table according to d
					{
                		setTable(d);
                		timesRepeted = 0;
					}
            }
            else
            {
                last_d = d;
                timesRepeted = 0;
            }
            return lgamma(i+d);
        }

    }
};

/**
An object of this class represents a lookup table for log-beta values.
as betaln(a,b) = gammaln(a)+gammaln(b)-gammaln(a+b) the object relies
on three Gammaln lookup tables.
*/
class Betaln{
    Gammaln A;
    Gammaln B;
    Gammaln AB;
public:
    /**
        @param tablesizeA - size of lookup table for 'gammaln(a)'
        @param tablesizeB - size of lookup table for 'gammaln(b)'
        @param tablesizeAB - size of lookup table for 'gammaln(a+b)'

    */
    Betaln(int tablesizeA, int tablesizeB, int tablesizeAB) : A(tablesizeA), B(tablesizeB), AB(tablesizeAB)
    {
        A.setTable(0);
        B.setTable(0);
        AB.setTable(0);
    }

    /**
        returns the logaritm of the beta function, based on four
        arguments, computed as betaln( ia+da , ib+db )
        @param ia
        @param da
        @param ib
        @param db
        @return betaln( ia+da , ib+db )
    */
    inline double betaln(size_t ia, double da, size_t ib, double db)
    {
        //return lgamma(ia+da) + lgamma(ib+db) - lgamma(ia+ib+da+db);         /*library function */
        return A.gammaln(ia,da) + B.gammaln(ib,db) - AB.gammaln(ia+ib,da+db); /*table lookup*/


    }

};

/**
An object of this class utilizes a Gammaln lookup table to
efficiently compute the logarithm of the factorial function
*/
class Factorialln
{
    Gammaln gammaln;
public:
    Factorialln(int tablesize) : gammaln(tablesize)
    {

    }
    /**
        Computes the logarithm of the factorial function
        @param value
        @return factorialln(value)
    */
    inline double logfactorial(size_t value)
    {
        return gammaln.gammaln(value,1);
    }

};

#endif // TABLEAPPROXIMATIONS_H_INCLUDED
