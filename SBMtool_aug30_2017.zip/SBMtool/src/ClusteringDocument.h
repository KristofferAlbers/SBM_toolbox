/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This code is provided as is without any warranty!

    An object of class ClusteringDocument generically represent a
    clustering vector. It can be used to generate a clustering given
    various options (such as by the number of nodes and clusters)
    The ClusteringDocument describes an intermediate format for
    representing clustering data, which can be parsed between
    performance-optimized clustering implementations, as well
    as for i/o formatting of clustering data.

    Furthermore, the class contains functions for generating
    clusterings uniformnly and according to the Chineese Restaurant
    Process (CRP)

*/

#ifndef CLUSTERINGDOCUMENT_H_INCLUDED
#define CLUSTERINGDOCUMENT_H_INCLUDED

#include "Clustering.h"
#include "Clustering_final.h"
#include "Options.h"
#include "main.h"

#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

class ClusteringDocument
{

public:
    const static std::string OPT_ITEMS;
    const static std::string OPT_COMPONENTS;
    const static std::string OPT_INIT;
    const static std::string OPT_INIT_STRING;
    const static std::string OPT_INIT_FILE;
    const static std::string OPT_INIT_RANDOM;
    const static std::string OPT_INIT_CRP;
friend class Clustering;
public:

    std::vector<size_t> clusteringVector;
    size_t numberOfItems = 0;
    size_t fixedNumberOfComponents = 0;

    ClusteringDocument(){}

    ClusteringDocument(Options options, bool b)
    {
        bool numberOfComponents_set = hasOption<int>(options,OPT_COMPONENTS);
        bool init = hasOption<int>(options,OPT_INIT);

        size_t numitems = getOption<int>(options,OPT_ITEMS,1);
        size_t numcomponents = getOption<int>(options,OPT_COMPONENTS,1);

        if(init)
        {
            subOption init = getOption<subOption>(options,OPT_INIT);
            std::string initType = init.getName();


            if( initType == OPT_INIT_CRP )
            {
                double alpha = init.getDouble();
                init_crp(numitems,alpha);
            }

            else if( initType == OPT_INIT_RANDOM )
            {
                size_t initialcomponents = init.getInt();
                init_uniform(numitems,initialcomponents );
                if(numberOfComponents_set)
                {
                    if(numcomponents < initialcomponents)
                    {
                        std::stringstream ss;
                        ss << "number of initial components set to more than number of components in option " << OPT_INIT_RANDOM;
                        reportError( ss.str(),.8);
                    }
                    fixedNumberOfComponents = numcomponents;
                }
                else
                {
                    fixedNumberOfComponents = initialcomponents;
                }
            }
            else if( initType == OPT_INIT_STRING )
            {
                std::string clusteringString = init.getString();
                std::istringstream isstream(clusteringString);
                size_t maxclusterid = 0;
                std::string s;
                while(getline(isstream,s,' '))
                {
                    size_t clusterid = std::stoi(s);
                    if(clusterid>maxclusterid){  maxclusterid = clusterid; }
                    clusteringVector.push_back(std::stoi(s));
                }
                if(numberOfComponents_set)
                {
                    if(numcomponents < maxclusterid)
                    {
                        std::stringstream ss;
                        ss << "number of clusters set to " << numcomponents << " components, while cluster with id " << maxclusterid << " found in option " << OPT_INIT_STRING;
                        reportError( ss.str(),.8);
                    }
                    else
                    {
                        fixedNumberOfComponents = numcomponents;
                    }
                }
                else
                {
                    fixedNumberOfComponents = maxclusterid;
                }
            }
        }
    };

    ClusteringDocument(size_t numberOfClusters, std::string clusterString)
    {
          std::istringstream isstream(clusterString);
          std::string s;
          while(getline(isstream, s,' '))
          {
            size_t clusterId = std::stoi(s);
            clusteringVector.push_back(clusterId);
          }
          fixedNumberOfComponents = numberOfClusters;
          numberOfItems = clusteringVector.size();
    }

    ClusteringDocument(std::string clusterString)
    {
          size_t maxClusterId = 0;
          std::istringstream isstream(clusterString);
          std::string s;
          while(getline(isstream, s,' '))
          {
            size_t clusterId = std::stoi(s);
            if(clusterId>maxClusterId)
            {
                maxClusterId = clusterId;
            }
            clusteringVector.push_back(clusterId);
          }
          fixedNumberOfComponents = maxClusterId;
          numberOfItems = clusteringVector.size();
    }

    ClusteringDocument(Clustering& clustering)
    {
        for (size_t i = 0; i != clustering.items.size(); ++i)
        {
            clusteringVector.push_back(clustering.items[i].clusterId);
        }
    }
    ClusteringDocument(size_t numberOfClusters, Clustering& clustering)
    {
        for (size_t i = 0; i != clustering.items.size(); ++i)
        {
            clusteringVector.push_back(clustering.items[i].clusterId);
        }
        fixedNumberOfComponents = numberOfClusters;
    }

    ClusteringDocument(Clustering_finite& clustering)
    {
        for (size_t i = 0; i != clustering.items.size(); ++i)
        {
            clusteringVector.push_back(clustering.items[i].clusterId);
        }
        numberOfItems = clusteringVector.size();
    }

    ClusteringDocument(size_t numberOfClusters, Clustering_finite& clustering)
    {
        for (size_t i = 0; i != clustering.items.size(); ++i)
        {
            clusteringVector.push_back(clustering.items[i].clusterId);
        }
        fixedNumberOfComponents = numberOfClusters;
        numberOfItems = clusteringVector.size();
    }





    virtual ~ClusteringDocument(){ };


    std::string toString()
    {
        std::stringstream s;
        for (size_t i = 0; i != clusteringVector.size(); ++i)
        {
            s << clusteringVector[i] << " ";
        }
        return s.str();
    }

    /** Generate clustering uniformly random*/
    void init_uniform(int numItems, int numComponents)
    {
        fixedNumberOfComponents = numComponents;
        numberOfItems = numItems;

        clusteringVector.clear();
        clusteringVector.resize(numItems);

        if(numComponents == 1)
        {
            for( int item = 1 ; item<numItems ; item++ )
            {
                clusteringVector[item] = 0;
            }
        }
        else
        {
            bool randomize = true;
            int items[numItems];
            for (int i = 0; i < numItems; ++i)
            {
                items[i] = i;
            }

            if(randomize)
            {
                std::random_shuffle(items, items+numItems);
            }

            int maxClusters = -1;
            for( int itt = 0 ; itt<numItems ; itt++ )
            {
                int item = items[itt];
                int clusterId;
                if(itt<numComponents)
                {

                    clusterId = itt;
                }
                else
                {
                    clusterId = rand()%numComponents;
                }
                if(clusterId>maxClusters)
                {
                    clusteringVector[item] = maxClusters+1;
                    maxClusters++;
                }
                else
                {
                    clusteringVector[item] = clusterId;
                }
            }
        }
    }

    /** Generate clustering according to the CRP */
    void init_crp(int numItems,double alpha)
    {
        numberOfItems = numItems;

        clusteringVector.clear();
        clusteringVector.resize(numItems);

        std::vector<size_t> assignments;
        assignments.resize(numItems);

        std::vector<size_t> clusterSizes;
        clusterSizes.resize(numItems);

        int numClusters = 1;

        assignments[0] = 0;
        clusterSizes[0] = 1;


        for(int n = 1; n<numItems; n++)
        {
            std::vector<double> probabilities;
            probabilities.resize(numClusters+1);

            for(int c = 0; c<numClusters; c++)
            {
                probabilities[c] = clusterSizes[c]*1.0/(n+alpha);
            }
            probabilities[numClusters] = alpha*1.0/(n+alpha);


            std::vector<double> probabilities_cumsum;
            probabilities_cumsum.resize(numClusters+1);

            std::partial_sum(probabilities.begin(), probabilities.end(), probabilities_cumsum.begin(), std::plus<double>());

            double randomval = ((double) rand() / (RAND_MAX));
            int chosenCluster = std::upper_bound(probabilities_cumsum.begin(), probabilities_cumsum.end(), randomval)-probabilities_cumsum.begin();

            clusteringVector[n] = chosenCluster;
            clusterSizes[chosenCluster] ++ ;

            if(chosenCluster == numClusters)
                numClusters++;
        }
        fixedNumberOfComponents = numClusters;
    }

    void sort()
    {
        std::vector<size_t> translatedClusterId( clusteringVector.size() );
        size_t nextUnusedClusterId = 0;
        std::vector<bool> clustertranslated( clusteringVector.size() );
        std::vector<size_t> translatedClusterAssignments( clusteringVector.size() );
        //get new cluster assignments
        for(size_t i = 0 ; i < clusteringVector.size() ; i++ )
        {
            size_t assignment = clusteringVector[i];
            if(!clustertranslated[assignment])
            {
                clustertranslated[assignment] = true;
                translatedClusterId[assignment] = nextUnusedClusterId;
                nextUnusedClusterId++;
            }
            translatedClusterAssignments[i] = translatedClusterId[assignment];
        }
        clusteringVector = translatedClusterAssignments;
    }
};

#endif // CLUSTERINGDOCUMENT_H_INCLUDED
