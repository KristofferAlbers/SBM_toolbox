/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
Implementation of the sampler for gibbs sampling, restricted to two clusters
(alternative to split-merge sampling for a finite clustering parameter)
*/

#include "Sampler.h"

#include "foundation.h"
#include <time.h>
#include <chrono>


const std::string ShuffleSampler_finiteClustering::SAMPLERNAME = "ShuffleSampler_finiteClustering";

Creator<MCMC_sampler, ShuffleSampler_finiteClustering> ShuffleSampler_finiteClustering::Create(ShuffleSampler_finiteClustering::SAMPLERNAME);

const std::vector<SettingDescription> ShuffleSampler_finiteClustering::settingDescriptions
{
    {   SettingDescription("parameter","PARAMETER",true).shortDescription("The clustering parameter to sample") },
    {   SettingDescription("proposals","INT",false).initialInt(1).min(1).shortDescription("Number of shuffle proposals")},
    {   SettingDescription("gibbssweeps","INT",false).initialInt(3).min(1).shortDescription("Number of restricted gibbs sweeps performed for each proposal")}

};


void ShuffleSampler_finiteClustering::sample()
{
    StatisticalModel& model = *(parameter->model_);
    int numberOfClusters = parameter->getDataPointer()->getNumberOfClusters();

    int accepts = 0;
    int rejects = 0;

    std::vector<double> Likelihoods;
    std::vector<size_t> Clusters;


    for(size_t sweep = 0; sweep<proposals; sweep++)
    {
        size_t cluster_i ;
        size_t cluster_j ;
        do
        {
            cluster_i = 0 + (rand() % (int)(numberOfClusters-1 - 0 + 1));
            cluster_j = 0 + (rand() % (int)(numberOfClusters-1 - 0 + 1));
        }
        while(cluster_i == cluster_j );

        std::vector<size_t> clusterIds;
        clusterIds.push_back(cluster_i);
        clusterIds.push_back(cluster_j);

        //remember the original clustering
        double logLikelihood_before = model.computeLogLikelihood();
        double logPrior_before = model.computeLogPrior();

        //get all nodes clustered in i or j
        std::vector<size_t> S;
        std::vector<size_t> originalClusterIds;
        Clustering_finite::clusterIterator it;
        for( it = parameter->getDataPointer()->begin(cluster_i); it!=parameter->getDataPointer()->end(cluster_i); ++it)
        {
            S.push_back(*it);
            originalClusterIds.push_back(parameter->getDataPointer()->getClusterId(*it));
        }
        for( it = parameter->getDataPointer()->begin(cluster_j); it!=parameter->getDataPointer()->end(cluster_j); ++it)
        {
            S.push_back(*it);
            originalClusterIds.push_back(parameter->getDataPointer()->getClusterId(*it));
        }

        sortVectorPair(&S,&originalClusterIds,ORDER_RANDOM_UNIFORM);
        assignRandomly(S,cluster_i,cluster_j);

        intermediateGibbsSweeps(restrictedSweeps,S,clusterIds);

        std::vector<size_t> launchStateClusterIds;
        for(size_t i = 0; i<S.size(); i++)
        {
            launchStateClusterIds.push_back(parameter->getDataPointer()->getClusterId(S[i]));
        }

        //compute transition probability from launch to final
        std::vector<double> logtransitionprobabilities = intermediateGibbsSweeps(1,S,clusterIds);
        double logQtrans_final = logtransitionprobabilities[logtransitionprobabilities.size()-1];
        double logPrior_final = model.computeLogPrior();
        double logLikelihood_final = model.computeLogLikelihood();

        //save final clustering and reset to launch:
        std::vector<size_t> finalClusterIds;
        for(size_t i = 0; i<S.size(); i++)
        {
            //TODO secure cluster exists
            finalClusterIds.push_back(parameter->getDataPointer()->getClusterId(S[i]));
            parameter->moveItem(S[i],launchStateClusterIds[i]);
        }

        //compute transition probability from launch to original
        std::vector<double> logtransitionprobabilities_toStart = intermediateGibbsSweeps(1,S,clusterIds,originalClusterIds);
        double logQtrans_start = logtransitionprobabilities_toStart[logtransitionprobabilities_toStart.size()-1];

        double MH_logProb = logLikelihood_final+logPrior_final+logQtrans_start-logLikelihood_before-logPrior_before-logQtrans_final;

        double acceptanceProbability = 1;
        if(MH_logProb<1)
        {
            acceptanceProbability = exp(MH_logProb);
        }

        double randomval = ((double) rand() / (RAND_MAX));

        if(randomval>=acceptanceProbability)
        {
            //reject proposal
            rejects ++;
        }
        else
        {
            //accept proposal
            for(size_t i = 0; i<S.size(); i++)
            {
                parameter->moveItem(S[i],finalClusterIds[i]);
            }
            accepts ++;
        }
    }
    if(print)
    {
        std::cout << "shuffle sampler done, acceps = " << accepts << " rejects = "<< rejects << std::endl;
    }

}

inline void ShuffleSampler_finiteClustering::assignRandomly(std::vector<size_t>& nodeIds, size_t cluster_a, size_t cluster_b){
    for(size_t n:nodeIds)
    {
        double randomval = ((double) rand() / (RAND_MAX));
        if(randomval<0.5)
            parameter->moveItem(n,cluster_a);
        else
            parameter->moveItem(n,cluster_b);
    }
}


//Restricted gibbs sweeps (forced)
inline std::vector<double> ShuffleSampler_finiteClustering::intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds,std::vector<size_t>& forced)
{
    //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j
    Options o
    {
        {"name", "Gibbs sampler for the clustering"},
        {"parameter", parameter}
    };
    Gibbs_finiteClustering sampler(o);

    return sampler.sample_restricted(numberOfSweeps,nodeIds,clusterIds,forced);
}
//Restricted gibbs sweeps
inline std::vector<double> ShuffleSampler_finiteClustering::intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds)
{
    //restricted intermediate gibbs on nodes in S on cluster_i and cluster_j
    Options o
    {
        {"name", "Gibbs sampler for the clustering"},
        {"parameter", parameter}
    };
    Gibbs_finiteClustering sampler(o);

    return sampler.sample_restricted(numberOfSweeps,nodeIds,clusterIds);
}

