/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This file defines classes for the different sampler implementations.
It contains two base classes; MCMC_sampler and MAX_sampler, to
separate between MCMC samplers and samplers for map solutions.
All sampler implementations contain a list of options/settings, that
are defined by the programmer, exposed to the user and used to parse
user settings.
*/

#ifndef SAMPLER_H_INCLUDED
#define SAMPLER_H_INCLUDED

#include "Options.h"
#include "settings.h"
#include "Parameter.h"
#include "factory.h"

class MCMC_sampler
{
public:
    std::string name = "";
protected:
    Options options;
public:
    MCMC_sampler() {}
    MCMC_sampler(std::string name_, Options o) : name(name_), options(o) {}
    virtual ~MCMC_sampler() {}
    virtual void sample() = 0;

    virtual std::vector<SettingDescription> getSettingDescriptions() = 0;
};


class Max_sampler
{
public:
    std::string name = "";
protected:
    Options options;
public:
    Max_sampler() {}
    Max_sampler(std::string name_, Options o) : name(name_), options(o) {}
    virtual ~Max_sampler() {}

    virtual bool sample() = 0;

    virtual std::vector<SettingDescription> getSettingDescriptions() = 0;
};






/**
    Gibbs sampling for a clustering in an infinite model
*/
class Gibbs_infiniteClustering : public MCMC_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    //settings
    ClusteringInfinite_Parameter* parameter;
    size_t sweeps;
    bool print;

    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    Gibbs_infiniteClustering() : MCMC_sampler() {}
    Gibbs_infiniteClustering(Options o) : MCMC_sampler(SAMPLERNAME,o)
    {
        parameter = (dynamic_cast<ClusteringInfinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        sweeps = getOption<int>(o,"sweeps",1);
        print = getOption<bool>(o,"print",false);
    }

    void sample();

    //restricted gibbs sampling:
        //restrict sampling to a vector of nodes over a vector of clusters
        std::vector<double> sample_restricted(size_t numberOfSweeps, std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds);
        //restrict sampling to a vector of nodes over a vector of clusters. On last sweep, the nodes are forcefully assigned into a given configuration.
        std::vector<double> sample_restricted(size_t numberOfSweeps, std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds,std::vector<size_t>& forcedIntoFinalClusterIds);
        std::vector<double>  sample_(size_t numberOfSweeps,std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds, std::vector<size_t>* forcedIntoClusterIds);

    static Creator<MCMC_sampler, Gibbs_infiniteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};



/**
    Gibbs sampling for a clustering in a finite model
*/
class Gibbs_finiteClustering : public MCMC_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    //settings
    ClusteringFinite_Parameter* parameter;
    size_t sweeps;
    bool print;

    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    Gibbs_finiteClustering() : MCMC_sampler() {}
    Gibbs_finiteClustering(Options o) : MCMC_sampler(SAMPLERNAME,o)
    {
        parameter = (dynamic_cast<ClusteringFinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        sweeps = getOption<int>(o,"sweeps",1);
        print = getOption<bool>(o,"print",false);
    }

    void sample();

    //restricted gibbs sampling:
    //restrict sampling to a vector of nodes over a vector of clusters
        std::vector<double> sample_restricted(size_t numberOfSweeps, std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds);
    //restrict sampling to a vector of nodes over a vector of clusters. On last sweep, the nodes are forcefully assigned into a given configuration.
        std::vector<double> sample_restricted(size_t numberOfSweeps, std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds,std::vector<size_t>& forcedIntoFinalClusterIds);
        std::vector<double>  sample_(size_t numberOfSweeps,std::vector<size_t>& nodeIds,std::vector<size_t>& clusterIds, std::vector<size_t>* forcedIntoClusterIds);

    static Creator<MCMC_sampler, Gibbs_finiteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};


/**
    Split merge sampling for a clustering in an infinite model
*/
class SplitMerge_infiniteClustering : public MCMC_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

    //settings
    ClusteringInfinite_Parameter* parameter;
    size_t proposals;
    size_t restrictedSweeps;
    bool print;


    // Random number generator
    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    struct results
    {
        size_t numSplitProposed = 0;
        size_t numMergeProposed = 0;
        size_t numSplitAccepted = 0;
        size_t numMergeAccepted = 0;
    };
    results results;

public:
    SplitMerge_infiniteClustering():MCMC_sampler(){}

    SplitMerge_infiniteClustering(Options o):MCMC_sampler(SAMPLERNAME,o)
    {

        parameter = (dynamic_cast<ClusteringInfinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        restrictedSweeps = (getOption<int>(o, "gibbssweeps", 3));
        proposals = (getOption<int>(o, "proposals", 1));
        print = getOption<bool>(o,"print",false);

    }

    void sample();
private:
    inline void assignRandomly(std::vector<size_t>& nodeIds, size_t cluster_a, size_t cluster_b);
    inline std::vector<double> intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds);
    inline std::vector<double> intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds,std::vector<size_t>& forced);

public:
    static Creator<MCMC_sampler, SplitMerge_infiniteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

};



/**
    Restricted Gibbs sampling over two clusters, (used as alternative to split-merge
    sampling for a clustering in a finite model)
*/
class ShuffleSampler_finiteClustering : public MCMC_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    ClusteringFinite_Parameter* parameter;    // clustering parameter
    size_t proposals;                         // number of proposals
    size_t restrictedSweeps;
    bool print;

    // Random number generator
    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    struct results
    {
        size_t numSplitProposed = 0;
        size_t numMergeProposed = 0;
        size_t numSplitAccepted = 0;
        size_t numMergeAccepted = 0;
    };
    results results;

public:

    ShuffleSampler_finiteClustering() : MCMC_sampler() {}

    ShuffleSampler_finiteClustering(Options o) : MCMC_sampler(SAMPLERNAME,o)
    {
        parameter = (dynamic_cast<ClusteringFinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        restrictedSweeps = (getOption<int>(o, "restrictedSweeps", 3));
        proposals = (getOption<int>(o, "sweeps", 1));
        print = getOption<bool>(o,"print",false);

    }

    //performs a number of split merge proposals
    void sample();

private:
    inline void assignRandomly(std::vector<size_t>& nodeIds, size_t cluster_a, size_t cluster_b);
    inline std::vector<double> intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds);
    inline std::vector<double> intermediateGibbsSweeps(size_t numberOfSweeps,std::vector<size_t>& nodeIds, std::vector<size_t>& clusterIds,std::vector<size_t>& forced);

public:
    static Creator<MCMC_sampler, ShuffleSampler_finiteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

};





/**
    MetropolistHastings random walker for a parameter
    represented by a real value.
*/
class MetropolisHastings_real : public MCMC_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    Real* parameter_;
    size_t sweeps;
    // Random number generator
    std::random_device rd;
    std::default_random_engine generator;
    std::normal_distribution<double> proposal;
    std::uniform_real_distribution<double> uniform;

    bool compinlog;
public:

    MetropolisHastings_real() : MCMC_sampler() {}
    MetropolisHastings_real(Options o) : MCMC_sampler(SAMPLERNAME,o), generator(rd()), proposal(0, getOption<double>(o, "stddev", 1.0))
    {
        sweeps = getOption<int>(o, "sweeps", 1);
        compinlog = getOption<bool>(o,"logdomain",false);
        parameter_ =  dynamic_cast<Real*>(getOption<Parameter*>(o, "parameter", 0));
//        if (!parameter_->computeLogPosterior) throw("Function posteriorRatio not defined");
    }
    ~MetropolisHastings_real() {}

    int proposals,accepts;
    std::string tostring();

    void sample();

    static Creator<MCMC_sampler, MetropolisHastings_real> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};

};








/**
    MAP sampler for clustering in an infinite model
*/
class MaxSampler_infiniteClustering : public Max_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    //settings
    ClusteringInfinite_Parameter* parameter;
    size_t sweeps;
    bool print;

    //internal datastructures
    size_t sweepsPerformed = 0;
    bool localOptimumReached = false;
    std::vector<size_t> numberOfChanges;
    std::vector<double> dlogPosteriors;


    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    MaxSampler_infiniteClustering() : Max_sampler() {}
    MaxSampler_infiniteClustering(Options o) : Max_sampler(SAMPLERNAME,o)
    {
        parameter = (dynamic_cast<ClusteringInfinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        sweeps = getOption<int>(o,"sweeps",2);
        print = getOption<bool>(o,"print",false);
    }

    bool sample();

    static Creator<Max_sampler, MaxSampler_infiniteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};



/**
    MAP sampler for clustering in a finite model
*/
class MaxSampler_finiteClustering : public Max_sampler
{
    const static std::string SAMPLERNAME;
    const static std::vector<SettingDescription> settingDescriptions;

public:
    //settings
    ClusteringFinite_Parameter* parameter;
    size_t sweeps;
    bool print;

    //internal datastructures
    size_t sweepsPerformed = 0;
    bool localOptimumReached = false;
    std::vector<size_t> numberOfChanges;
    std::vector<double> dlogPosteriors;


    std::random_device rd;
    std::default_random_engine generator;
    std::uniform_real_distribution<double> uniform;

    MaxSampler_finiteClustering() : Max_sampler() {}
    MaxSampler_finiteClustering(Options o) : Max_sampler(SAMPLERNAME,o)
    {
        parameter = (dynamic_cast<ClusteringFinite_Parameter*>(getOption<Parameter*>(o, "parameter", 0)));
        sweeps = getOption<int>(o,"sweeps",2);
        print = getOption<bool>(o,"print",false);
    }

    bool sample();

    static Creator<Max_sampler, MaxSampler_finiteClustering> Create;
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};
};

#endif // SAMPLER_H_INCLUDED
