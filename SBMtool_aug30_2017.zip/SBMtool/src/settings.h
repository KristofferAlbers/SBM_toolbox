/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This file defines classes for define and describe the various settings/options
that the user can parse to the program.
The settings objects are instantiated within the schedular, model and sampler
implementations, through which they are exposed to the user, and user arguments
can be efficiently parsed to the program modules.
*/



#ifndef SETTINGS_H_INCLUDED
#define SETTINGS_H_INCLUDED

#include <iostream>
#include <map>
#include <string>
#include "Options.h"


/**
An object of the SettingDescription class defines a particular setting/option
that can be set by the user. The object defines the various fields that the
programmer can set to define the setting/option. This includes strings such
as name, type as well as strings to describe the use of the setting/option.
Further, various predefined fields can be set to describe default values of
the setting/option as well as limit the range the setting/option should be within.
A boolean field can further be set to define whether the setting/option is
essential for the user to set, for the application to operate properly.
*/
class SettingDescription
{
public:
    std::string name_;
    std::string type_;
    std::string shortDescription_;
    std::string longDescription_;

    std::string mutualExclusiveGroup_;

    bool critical_;
    std::string initial_;
    std::string initial_string;
    int initial_int;
    double initial_float;
    bool initial_bool;

    double min_;
    double max_;

    bool hasCritical = false;
    bool hasMin = false;
    bool hasMax = false;

    bool hasShortDescription = false;
    bool hasLongDescription = false;
    bool hasMutualExclusiveGroup = false;

    bool hasInitialString = false;
    bool hasInitialInt = false;
    bool hasInitialFloat = false;
    bool hasInitialBool = false;
    bool hasInitial = false;

public:
    SettingDescription(std::string name,std::string type,bool critical) :
        name_(name),  type_(type), critical_(critical)
    {
        hasCritical = critical;
    }

    SettingDescription& min(double min)
    {
        min_ = min;
        hasMin = true;
        return *this;
    }
    SettingDescription& max(double min)
    {
        max_ = min;
        hasMax = true;
        return *this;
    }
    SettingDescription& shortDescription(std::string description)
    {
        shortDescription_ = description;
        hasShortDescription = true;
        return *this;
    }
    SettingDescription& longDescription(std::string description)
    {
        longDescription_ = description;
        hasLongDescription = true;
        return *this;
    }


    SettingDescription& mutualExclusiveGroup(std::string group)
    {
        mutualExclusiveGroup_ = group;
        hasMutualExclusiveGroup = true;
        return *this;
    }
    SettingDescription& initialString(std::string initial)
    {
        initial_string = initial;
        hasInitialString = true;
        return *this;
    }
    SettingDescription& initialInt(int initial)
    {
        initial_int = initial;
        hasInitialInt = true;
        return *this;
    }
    SettingDescription& initialFloat(double initial)
    {
        initial_float = initial;
        hasInitialFloat = true;
        return *this;
    }
    SettingDescription& initialBool(bool initial)
    {
        initial_bool = initial;
        hasInitialBool = true;
        return *this;
    }

    /**
        Parse the particular setting as an int from the userdefined
        arguments given in an Options container
    */
    int parseInt(Options o) const
    {
        int val;
        if(critical_)
            val = getOption<int>(o,name_.c_str());
        else
            val = getOption<int>(o,name_.c_str(),initial_int);
        if(  (hasMin && val<min_) || (hasMax && val>max_) )
        {
            std::cout << "value of option " << name_ << " is outside legal bound"<< std::endl;
            exit(0);
        }
        return val;
        return val;
    }

    /**
        Parse the particular setting as a double from the userdefined
        arguments given in an Options container
    */
    double parseDouble(Options o) const
    {
        double val;
        if(critical_)
            val = getOption<double>(o,name_.c_str());
        else
            val = getOption<double>(o,name_.c_str(),initial_float);

        if(  (hasMin && val<min_) || (hasMax && val>max_) )
        {
            std::cout << "value of option " << name_ << " is outside legal bound"<< std::endl;
            exit(0);
        }
        return val;
    }

    /**
        Parse the particular setting as a boolean value from the userdefined
        arguments given in an Options container
    */
    bool parseBool(Options o) const
    {
        bool val;
        if(critical_)
            val = getOption<bool>(o,name_.c_str());
        else
            val = getOption<bool>(o,name_.c_str(),initial_bool);
        return val;
    }

    /**
        Parse the particular setting as a string from the userdefined
        arguments given in an Options container
    */
    std::string parseString(Options o) const
    {
        std::string val;
        if(critical_)
            val = getOption<std::string>(o,name_.c_str());
        else
            val = getOption<std::string>(o,name_.c_str(),initial_string);

        return val;
    }



};


/**
An object of the ParameterDescription class defines a particular parameter.
The descriptions are given by the programmer, instantiated within a particular
model object, through which they are exposed to the user.
*/
class ParameterDescription
{
public:
    std::string name_;
    std::string type_;
    std::string shortDescription_;
    std::string longDescription_;

    bool hasShortDescription = false;
    bool hasLongDescription = false;

    ParameterDescription(std::string name,std::string type) : name_(name), type_(type)
    {
    }
    ParameterDescription& shortDescription(std::string description)
    {
        hasShortDescription = true;
        shortDescription_ = description;
        return *this;
    }
    ParameterDescription& longDescription(std::string description)
    {
        hasLongDescription = true;
        longDescription_ = description;
        return *this;
    }

};

/**
An object of the ModelDescription class defines a particular statistical model.
The descriptions are given by the programmer, instantiated within the particular
model object, through which they are exposed to the user.
*/
class ModelDescription
{
public:
    std::string name_;
    std::string type_;
    std::string description_;

    ModelDescription(std::string name, std::string type, std::string description) : name_(name), type_(type), description_(description)
    {

    }
};


/**
An object of the SamplerDescription class describes a particular sampler.
The descriptions are given by the programmer, within the sampler implementation,
through which they are exposed to the user.
*/
class SamplerDescription
{
public:
    std::string name_;
    std::string parameter_type_;
    std::string description_;

    SamplerDescription(std::string name, std::string parameter_type, std::string description) : name_(name), parameter_type_(parameter_type), description_(description)
    {

    }
};


/**
    Templated function to parse a setting/option given by its name - @param name,
    given by a user through an Options object - @param o, according to a vector of
    SettingDescription objects - @param settings
*/
template<class T>
T parseSetting(std::string name, const std::vector<SettingDescription>& settings, Options& o)
{
    for(int i = 0 ; i<settings.size(); i++)
    {
        if(settings[i].name_.compare(name) == 0)
        {
            if(typeid(T)==typeid(bool))
            {
                bool val = settings[i].parseBool(o);
                T* tp = (T*)(&val);
                return *tp;
            }
            if(typeid(T)==typeid(int))
            {
                int val = settings[i].parseInt(o);
                T* tp = (T*)(&val);
                return *tp;
            }
            if(typeid(T)==typeid(double))
            {
                double val = settings[i].parseDouble(o);
                T* tp = (T*)(&val);
                return *tp;
            }
            if(typeid(T)==typeid(std::string))
            {
                std::string val = settings[i].parseString(o);
                T* tp = (T*)(&val);
                return *tp;
            }
            std::cout << "error: unknown parsing type!" << std::endl;
            exit(0);
        }
    }
    std::cout << "error: setting " << name << " not found!" << std::endl;
    exit(0);

}




#endif // SETTINGS_H_INCLUDED

