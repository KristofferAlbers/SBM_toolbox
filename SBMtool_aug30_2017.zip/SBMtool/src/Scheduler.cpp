/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
CPP file for scheduler implementations. Defines the descriptions for user settings.
*/

#include "Scheduler.h"

const std::string DefaultScheduler::SCHEDULERNAME = "default";
const std::vector<SettingDescription> DefaultScheduler::settingDescriptions
{
    {   SettingDescription("random_seed","INT",false).shortDescription("Set random generator seed.") },
    {   SettingDescription("init_seed_random","BOOL",false).initialBool(true).shortDescription("Random seed the random generator.") },
    {   SettingDescription("savepath","FILEPATH",true).shortDescription("File path to save output.")    },
    {   SettingDescription("burnin_sweeps","INT",true).min(0).shortDescription("Number of burnin sweeps of the mcmc sampling procedure.") },
    {   SettingDescription("sample_sweeps","INT",true).min(0).shortDescription("Number of sweeps of the mcmc sampling procedure after the burnin.") },
    {   SettingDescription("optimize_sweeps","INT",true).min(0).shortDescription("Maximal number of sweeps of the optimizing procedure to reach map solution.") },
    {   SettingDescription("save_parameter_rate","INT",true).initialInt(1).shortDescription("The number of sweeps between saving parameter values to output file.") },
    {   SettingDescription("save_modeloutput_rate","INT",true).initialInt(1).shortDescription("The number of sweeps between saving model values to output file.") },
    {   SettingDescription("sub_sample_rate","INT",true).initialInt(1).shortDescription("The number of sweeps between saving state as candidate for optimizing.") },
    {   SettingDescription("save_initial_state","BOOL",true).initialBool(true).shortDescription("Save model values and parameters before burnin.") },
    {   SettingDescription("save_burnin_state","BOOL",true).initialBool(true).shortDescription("Save model values and parameters after burnin.") },
    {   SettingDescription("save_best_state","BOOL",true).initialBool(true).shortDescription("Save model values and parameters with highest posterior, found during mcmc sampling.") },
    {   SettingDescription("save_final_state","BOOL",true).initialBool(true).shortDescription("Save model values and parameters after optimizing 'best state' for map solution.") }
};
Creator<Scheduler, DefaultScheduler> DefaultScheduler::Create(DefaultScheduler::SCHEDULERNAME);

const std::string PosteriorLandscapeScheduler::SCHEDULERNAME = "posterior_landscape";
const std::vector<SettingDescription> PosteriorLandscapeScheduler::settingDescriptions
{
    {   SettingDescription("random_seed","INT",false).shortDescription("Set random generator seed.") },
    {   SettingDescription("init_seed_random","BOOL",false).initialBool(true).shortDescription("Random seed the random generator.") },
    {   SettingDescription("savepath","FILEPATH",true).shortDescription("File path to save output.")    },
    {   SettingDescription("burnin_sweeps","INT",true).min(0).shortDescription("Number of burnin sweeps of the mcmc sampling procedure.") },
    {   SettingDescription("sample_sweeps","INT",true).min(0).shortDescription("Number of sweeps of the mcmc sampling procedure after the burnin.") },
    {   SettingDescription("optimize_sweeps","INT",true).min(0).shortDescription("Maximal number of sweeps of the optimizing procedure to reach map solution.") },
    {   SettingDescription("save_burnin_state","BOOL",true).initialBool(true).shortDescription("Save model values and parameters after burnin.") }
};
Creator<Scheduler, PosteriorLandscapeScheduler> PosteriorLandscapeScheduler::Create(PosteriorLandscapeScheduler::SCHEDULERNAME);

const std::string DebugScheduler::SCHEDULERNAME = "debug";
const std::vector<SettingDescription> DebugScheduler::settingDescriptions
{
    {   SettingDescription("testnumber","INT",true).shortDescription("test number.") }
};
Creator<Scheduler, DebugScheduler> DebugScheduler::Create(DebugScheduler::SCHEDULERNAME);
