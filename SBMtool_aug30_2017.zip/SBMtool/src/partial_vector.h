/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
This file contains the implementation of the partial_vector
container. This container stores data sequentially, but
allows 'holes' in the sequence, such that elements can
be deleted and inserted in constant time.
To efficiently iterate the data, the partial_vector class
implements an iterator.
*/

#ifndef PARTIAL_VECTOR_H_INCLUDED
#define PARTIAL_VECTOR_H_INCLUDED

#include <iostream>

#include <vector>
#include <deque>
#include <cassert>


template <class T>
class partial_vector
{
private:
    struct DataStore_
    {
        bool unused_ = true;
        bool inUnusedQueue_ = false;
        T data_;
    };


    std::vector<DataStore_> dataStore_;
public:
    std::deque<size_t> unused_; //hack
private:
    size_t size_;
    size_t newIndex();

public:
    partial_vector() : dataStore_(), unused_(), size_(0) {};

    void erase(size_t);
    void set(size_t, T);

    T& operator[](size_t);
    size_t push(const T&);
    size_t push_back(const T&);
    size_t size();
    void clear();
    bool exist(size_t);

    void print();

    class iterator;
    iterator begin();
    iterator end();

    template <class U> friend std::ostream& operator<<(std::ostream&, const partial_vector<U>&);
};

// pvector<T> implementation

template <class T>
inline void partial_vector<T>::erase(size_t id)
{
    assert(exist(id));

    --size_;
    dataStore_[id].unused_ = true;

    if(dataStore_[id].inUnusedQueue_ == false)
    {
        dataStore_[id].inUnusedQueue_ = true;
        unused_.push_back(id);
    }
}

template <class T>
inline void partial_vector<T>::set(size_t id, T val)
{
    // Allocate more space if index is out of bounds
    if (id >= dataStore_.size())
    {
        double currentSize = dataStore_.size();

        // Allocate space
        dataStore_.resize(id+1);

        // Add new indices to unused_
        for (size_t i = currentSize; i != id; ++i)
        {
            unused_.push_back(i);
            dataStore_[i].inUnusedQueue_ = true;
        }
    }
    dataStore_[id].data_ = val;
    if (dataStore_[id].unused_) ++size_;
    dataStore_[id].unused_ = false;
}

template <class T>
inline size_t partial_vector<T>::newIndex()
{
    size_t id;
    if (unused_.empty())
    {
        id = dataStore_.size();
    }
    else
    {
        id = unused_.front();
        unused_.pop_front();
        dataStore_[id].inUnusedQueue_ = false;

        while(unused_.empty() == false  &&  dataStore_[id].unused_ == false)
        {
            id = unused_.front();
            unused_.pop_front();
            dataStore_[id].inUnusedQueue_ = false;
        }

    }
    return id;
}

template <class T>
inline size_t partial_vector<T>::push(const T& val)
{
    size_t id = newIndex();
    set(id, val);
    return id;
}

template <class T>
inline size_t partial_vector<T>::push_back(const T& val)
{
    set(dataStore_.size()+1 , val);
}

template <class T>
size_t partial_vector<T>::size()
{
    return size_;
}

template <class T>
void partial_vector<T>::clear()
{
    dataStore_.clear();
    unused_.clear();
    size_ = 0;
}

template <class T>
bool partial_vector<T>::exist(size_t id)
{
    return id < dataStore_.size() && !dataStore_[id].unused_;
}

template <class T>
inline T& partial_vector<T>::operator[](size_t id)
{
    return dataStore_[id].data_;
}

template <class T>
typename partial_vector<T>::iterator partial_vector<T>::begin()
{
    typename std::vector<DataStore_>::iterator itFirst;
    for (itFirst = dataStore_.begin(); itFirst != dataStore_.end() && itFirst->unused_; ++itFirst);
    return iterator(dataStore_, itFirst);
};

template <class T>
typename partial_vector<T>::iterator partial_vector<T>::end()
{
    typename std::vector<DataStore_>::iterator itLast = dataStore_.end();
    return iterator(dataStore_, itLast);
};


template <class T>
void partial_vector<T>::print(){
    std::cout << "partial_vector" << std::endl;
    std::cout << "  Data:" << std::endl;
    for (auto i = this.dataStore_.begin(); i != this.dataStore_.end(); ++i)
    {
        std::cout << "  " << i-this.dataStore_.begin() << ":\t" << i->data_ << "\t" << (i->unused_ ? " Ø" : "") << std::endl;
    }
    std::cout << "  Unused: ";
    for (auto i = this.unused_.begin(); i != this.unused_.end(); ++i)
    {
        std::cout << *i;
        if (i != this.unused_.end()-1) std::cout << ", ";
    }
    std::cout << std::endl;

}

//-----------------------------------------------------------------------------
// ostream friend function

template <class T>
std::ostream& operator<<(std::ostream& os, const partial_vector<T>& v)
{
    os << "(partial_vector)" << std::endl;
    for (auto i = v.dataStore_.begin(); i != v.dataStore_.end(); ++i)
    {
        os << "  " << i-v.dataStore_.begin() << ":\t" << i->data_ << "\t" << (i->unused_ ? " Ø" : "") << std::endl;
    }

    return os;
}

//-----------------------------------------------------------------------------
// pvector<T>::iterator implementation

template <class T>
class partial_vector<T>::iterator : public std::iterator<std::forward_iterator_tag, T>
{
private:
    std::vector<DataStore_>* dataStore_;
    typename std::vector<DataStore_>::iterator it_;

public:
    iterator() {};
    iterator(const iterator& other) : dataStore_(other.dataStore_), it_(other.it_) {};
    iterator(std::vector<DataStore_>& dataStore) : dataStore_(&dataStore) {};
    iterator(std::vector<DataStore_>& dataStore, typename std::vector<DataStore_>::iterator it) : dataStore_(&dataStore), it_(it) {};
    inline iterator& operator=(const iterator& other)
    {
        it_ = other.it_;
        dataStore_ = other.dataStore_;
        return *this;
    }
    inline iterator& operator++()
    {
        ++it_;
        while (it_->unused_ && it_ != dataStore_->end()) ++it_;
        return *this;
    };
    inline iterator operator++(int)
    {
        iterator temp(*this);
        operator++();
        return temp;
    }
    inline bool operator!=(const iterator other)
    {
        return it_ != other.it_;
    };
    inline bool operator==(const iterator other)
    {
        return it_ == other.it_;
    }
    inline T& operator*()
    {
        return it_->data_;
    };
    inline T* operator->()
    {
        return &it_->data_;
    }
    inline size_t index()
    {
        return it_ - dataStore_->begin();
    }
};


#endif // PARTIAL_VECTOR_H_INCLUDED
