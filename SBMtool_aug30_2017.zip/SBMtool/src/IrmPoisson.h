/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef IrmPoisson_H_INCLUDED
#define IrmPoisson_H_INCLUDED

#include "StatisticalModel.h"
#include "Options.h"
#include "settings.h"
#include "factory.h"
#include "LinkCount.h"
#include "Network.h"
#include "Clustering.h"
#include "ClusteringDocument.h"

#include "tableApproximations.h"

#include <vector>
#include <boost/assign.hpp>
#include <boost/tuple/tuple.hpp>
#include <omp.h>

using namespace std::placeholders;

class IrmPoisson : public StatisticalModel
{
    const static std::string MODELNAME;
    const std::string PARAMETER_CLUSTERING = "clustering";
    const std::string PARAMETER_ALPHA = "alpha";
    const std::string PARAMETER_A = "a";
    const std::string PARAMETER_B = "b";

    const std::string OPT_NETWORK_LINKS = "network.links";
    const std::string OPT_NETWORK_MISSINGLINKS = "network.missinglinks";
    const std::string OPT_CLUSTERING_CRP = "clustering.init_crp";
    const std::string OPT_CLUSTERING_RANDOM = "clustering.init_random";

    const std::string OPT_TABLEMAX_A = "tablemax_a";
    const std::string OPT_TABLEMAX_B = "tablemax_b";
    const std::string OPT_TABLEMAX_C = "tablemax_c";
    const std::string OPT_ITEMS = "items";
    const std::string OPT_SUBJECTS = "subjects";

    const std::string OPT_INIT_ALPHA = "alpha.init";
    const std::string OPT_INIT_A = "a.init";
    const std::string OPT_INIT_B = "b.init";
    const std::string OPT_DIRECTED = "directed";
    const std::string OPT_USEMISSING = "withmissing";

    const static ModelDescription modelDescription;
    const static std::vector<SettingDescription> settingDescriptions;
    const static std::vector<ParameterDescription> parameterDescriptions;



template <typename T> class NodeCounts
{
public:
    size_t nodeId;
    size_t currentClusterId;
    size_t currentClusterSize;

    std::vector<T> nodePair;
    std::vector<T> linkSum;
    std::vector<T> missingNodePair;

    std::vector<T> nodePair_transposed;
    std::vector<T> linkSum_transposed;
    std::vector<T> missingNodePair_transposed;

    void print()
    {
        std::cout << "cluster:\t links \t non \t missing" << std::endl;
        for(int i = 0; i < linkSum.size(); i++)
        {
            std::cout << "(i = " << i << " ) \t "<< linkSum[i] << " \t " << nodePair[i]; // << " \t " << nodeMissingLinks[i];
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }
};


struct SufficientStatistics
{
    SquareMatrix<size_t> nodePairs;
    SquareMatrix<size_t> linkSum;
    SquareMatrix<size_t> missingNodePairs;

    bool directed;
    bool withmissing;

    size_t getNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        return nodePairs.matrix[sourceCluster*nodePairs.max+targetCluster];
    }
    size_t getLinkSum(size_t sourceCluster, size_t targetCluster)
    {
        return linkSum.matrix[sourceCluster*linkSum.max+targetCluster];
    }
    size_t getMissingNodePairs(size_t sourceCluster, size_t targetCluster)
    {
        if(withmissing)
            return missingNodePairs.matrix[sourceCluster*missingNodePairs.max+targetCluster];
        else
            return 0;
    }
    void setNewMax(size_t newMax)
    {
        nodePairs.setNewMax(newMax);
        linkSum.setNewMax(newMax);
        if(withmissing)
            missingNodePairs.setNewMax(newMax);
    }
    void setToCopy(SufficientStatistics& copyFrom)
    {
        nodePairs.setToCopy(copyFrom.nodePairs);
        linkSum.setToCopy(copyFrom.linkSum);
        missingNodePairs.setToCopy(copyFrom.missingNodePairs);
        directed = copyFrom.directed;
        withmissing = copyFrom.withmissing;
    }

};

struct HyperParameters
{
    double alpha_;
    double logalpha_;
    double a_;
    double b_;
};
struct Data
{
    UnipartiteNetwork<size_t>& network;
    NetworkData<size_t>& data;
    NetworkData<size_t>& data_transposed;
    NetworkData<size_t>& missing;
    NetworkData<size_t>& missing_transposed;
    SufficientStatistics& sufstats;
};

public:
    //clustering data
    Clustering clusteringData;
    //parameters
    ClusteringInfinite_Parameter clustering;
    Real alpha;
    Real a;
    Real b;



    //hyperparameters data
    HyperParameters param;
    //sufficient statistics
    std::vector<SufficientStatistics> sufstats;
    //options

    int items;
    size_t numSubjects;
    bool usemissing_;
    bool directed;
    bool network_weighted;

    std::string missinglinksfile_;
    std::string linksfile_;

    //network data
    std::vector<UnipartiteNetwork<size_t>> networks;

    std::vector<Data> data;

    Factorialln factln_table;
    Gammaln gammaln_table;

public:

    IrmPoisson() : StatisticalModel(),
            clustering(this,PARAMETER_CLUSTERING), alpha(this,PARAMETER_ALPHA), a(this,PARAMETER_A), b(this,PARAMETER_B),
            gammaln_table(1), factln_table(1)
    {
    }

    IrmPoisson(Options o) : StatisticalModel(MODELNAME, o),
            clustering(this,PARAMETER_CLUSTERING), alpha(this,PARAMETER_ALPHA), a(this,PARAMETER_A), b(this,PARAMETER_B),
            gammaln_table(getOption<int>(o,OPT_TABLEMAX_B,10000)),
            factln_table(getOption<int>(o,OPT_TABLEMAX_B,10000))
    {
        //bind parameter functions
        clustering.effectiveLogPosteriorRatio = std::bind(&IrmPoisson::effectiveLogPosteriorRatio_clustering,this,_1,_2,_3,_4);
        clustering.effectiveLogPosteriorRatio_restricted = std::bind(&IrmPoisson::effectiveLogPosteriorRatio_restricted_clustering, this, _1, _2);
        clustering.logPosteriorRatio_mergeClusters = std::bind(&IrmPoisson::effectiveLogPosteriorRatio_mergeClusters_clustering,this,_1,_2);
        clustering.moveItem = std::bind(&IrmPoisson::moveItem_clustering, this, _1, _2);
        clustering.moveItem_newCluster = std::bind(&IrmPoisson::moveItem_newCluster_clustering, this, _1);
        clustering.mergeClusters = std::bind(&IrmPoisson::mergeClusters_clustering, this, _1, _2);
        clustering.getDataPointer = std::bind(&IrmPoisson::getDataPointer_clustering,this);
        clustering.getNumberOfItems = std::bind(&IrmPoisson::getNumberOfItems_clustering,this);
        clustering.get = std::bind(&IrmPoisson::get_clustering,this);
        clustering.set = std::bind(&IrmPoisson::set_clustering,this,_1);
        clustering.setFromString_implement = std::bind(&IrmPoisson::setFromString_clustering,this,_1);

        alpha.get = std::bind(&IrmPoisson::get_alpha,this);
        alpha.set = std::bind(&IrmPoisson::set_alpha,this,_1);
        alpha.logPosteriorRatio = std::bind(&IrmPoisson::logPosteriorRatio_alpha, this, _1);
        a.get = std::bind(&IrmPoisson::get_a,this);
        a.set = std::bind(&IrmPoisson::set_a,this,_1);
        a.logPosteriorRatio = std::bind(&IrmPoisson::logPosteriorRatio_a, this, _1);
        b.get = std::bind(&IrmPoisson::get_b,this);
        b.set = std::bind(&IrmPoisson::set_b,this,_1);
        b.logPosteriorRatio = std::bind(&IrmPoisson::logPosteriorRatio_b, this, _1);


        //parse options
        items = parseSetting<int>(OPT_ITEMS,settingDescriptions,o);
        numSubjects = parseSetting<int>(OPT_SUBJECTS,settingDescriptions,o);

        param.alpha_ = parseSetting<double>(OPT_INIT_ALPHA,settingDescriptions,o);
        param.logalpha_ = log(param.alpha_);
        param.a_ = parseSetting<double>(OPT_INIT_A,settingDescriptions,o);
        param.b_ = parseSetting<double>(OPT_INIT_B,settingDescriptions,o);

        directed = parseSetting<bool>(OPT_DIRECTED,settingDescriptions,o);
        usemissing_ = parseSetting<bool>(OPT_USEMISSING,settingDescriptions,o);
        linksfile_ = parseSetting<std::string>(OPT_NETWORK_LINKS,settingDescriptions,o);

        //load network
        network_weighted = true;
        bool zeroindexed = false;
        bool missingweighted = network_weighted;
        bool missingToZero = false;
        if(usemissing_)
        {
            missinglinksfile_ = parseSetting<std::string>(OPT_NETWORK_MISSINGLINKS,settingDescriptions,o);
            UnipartiteNetwork<size_t> network(items,linksfile_, missinglinksfile_, zeroindexed, missingweighted, missingToZero, network_weighted, directed);
            networks.push_back(network);
        }
        else
        {
            UnipartiteNetwork<size_t> network(items,linksfile_, zeroindexed, network_weighted, directed);
            networks.push_back(network);
        }

        //initialize clustering
        ClusteringDocument cd;
        if(hasOption<bool>(o,OPT_CLUSTERING_CRP))
        {
            double clust_crp_alpha = parseSetting<double>(OPT_CLUSTERING_CRP,settingDescriptions,o);
            cd.init_crp(items,clust_crp_alpha);
        }
        else
        {
            int clust_random = parseSetting<int>(OPT_CLUSTERING_RANDOM,settingDescriptions,o);
            cd.init_uniform(items,clust_random);
        }
        clusteringData = Clustering(cd.clusteringVector);

        //initialize sufficient statistics
        sufstats.resize(networks.size());
        for(size_t i = 0; i<networks.size(); i++)
        {
            SufficientStatistics sf;
            sufstats[i] = sf;

            data.push_back({networks[i],networks[i].data,networks[i].data_transposed,networks[i].missing,networks[i].missing_transposed,sufstats[i]});
        }
        computeAllSufficientStatistics();

        //report, model setup suceeded.
        reportInfo("model setup completed",.5);
    }

    double computeLogPrior();
    double computeLogLikelihood();
    double computeLogPosterior();
    double computeLogLikelihood(Data& data_, Clustering& clustering_);

    //assist functions
    void computeAllSufficientStatistics();
    void computeSufficientStatistics(Data& data_, Clustering& clustering_);

    void getNodeCounts(size_t nodeId, Data& data_, Clustering& clustering_, size_t currentCluster, size_t max, NodeCounts<size_t>& nodecounts);

    inline double logPrior_effectiveChange(size_t nodeId, size_t cluster, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);
    inline double logPrior_effectiveChange_newCluster(size_t nodeId, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);


    inline double logLikelihood_effectiveChange(size_t nodeId, Data& data_, Clustering& clustering_, HyperParameters& param, size_t cluster,size_t currentCluster, size_t currentClusterSize,NodeCounts<size_t>& nodecounts);
    inline double logLikelihood_effectiveChange_newCluster(size_t nodeId, Data& data_, Clustering& clustering, HyperParameters& param, size_t currentCluster, size_t currentClusterSize, NodeCounts<size_t>& nodecounts);

    //clustering functions
    partial_vector<double> effectiveLogPosteriorRatio_clustering(size_t nodeId, Clustering::iterator begin, Clustering::iterator end, bool appendForNewCluster);
    partial_vector<double> effectiveLogPosteriorRatio_restricted_clustering(size_t nodeId,std::vector<size_t>& restrictedClusters);
    double effectiveLogPosteriorRatio_mergeClusters_clustering(size_t cluster1, size_t cluster2);

    void moveItem_clustering(size_t itemId, size_t clusterId);
    void moveItem_newCluster_clustering(size_t itemId);
    void mergeClusters_clustering(size_t cluster1,size_t cluster2);

    Clustering* getDataPointer_clustering();
    size_t getNumberOfItems_clustering();
    ClusteringDocument get_clustering();
    void set_clustering(ClusteringDocument& c);
    void setFromString_clustering(std::string str);

    double get_alpha();
    void set_alpha(double val);
    double logPosteriorRatio_alpha(double new_alpha);

    double get_a();
    void set_a(double val);
    double logPosteriorRatio_a(double new_a);


    double get_b();
    void set_b(double val);
    double logPosteriorRatio_b(double new_b);

    double effectiveLogLikelihoodRatio_clustering(std::vector<Data>* data_pointer,size_t nodeId,size_t cluster,bool emptyCluster);

    static Creator<StatisticalModel, IrmPoisson> Create;

    ModelDescription getModelDescription(){return modelDescription;}
    std::vector<ParameterDescription> getParameterDescriptions() {return parameterDescriptions;}
    std::vector<SettingDescription> getSettingDescriptions() {return settingDescriptions;};


    double FUNC(size_t ai, double ad, size_t bi, double bd)
    {
        //return betaln_table.betaln(ai,ad,bi,bd);
        return gammaln_table.gammaln(ai,ad) - (ai+ad)*LOG(bi,bd);
    }
    inline double LOG(size_t bi, double bd)
    {
        return log(bi+bd);
    }
};





#endif // IrmPoisson_H_INCLUDED
