/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
class NetworkDocument
An object of this class is used to read network files into generic data structures
*/

#ifndef NETWORKDOCUMENT_H_INCLUDED
#define NETWORKDOCUMENT_H_INCLUDED

#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "main.h"


template<typename T> class NetworkDocument
{
public:
    struct Link
    {
        int target;
        T value;
    };

    std::vector<T> values;
    std::vector<size_t> sources;
    std::vector<size_t> targets;
    std::vector<std::vector<Link>> links;

    std::vector<T> values_t;
    std::vector<size_t> sources_t;
    std::vector<size_t> targets_t;
    std::vector<std::vector<Link>> links_t;
private:
    int maxSource = 0;
    int maxTarget = 0;
    int totalEdges = 0;
public:
    NetworkDocument()
    {

    };
    /**
        Constructor, initialized by calling the load() function recieved arguments
    */
    NetworkDocument(int numberOfRows, int numberOfColumns, std::string filename, bool directed, bool weighted, bool zeroindexed,bool bipartite)
    {
        load(numberOfRows,numberOfColumns,filename,directed,weighted,zeroindexed,bipartite);
    };


    /**
        load network file into intermediate data structures
        @param numberOfRows - rows in the assignment matrix defining the network
        @param numberOfColumns - columns in the assignment matrix defining the network
        @param filename - full filepath and name for the text file containing correctly formatted network data
        @param directed - boolean to define if the network is directed
        @param weighted - boolean to define if the links in the network file has an associated weight
        @param zeroindexed - boolean to define if first node in the network file is identified by 0 (zero)
        @param bipartite - true: network is bipartite, false: network is unipartite
    */
    void load(int numberOfRows, int numberOfColumns, std::string filename, bool directed, bool weighted, bool zeroindexed,bool bipartite)
    {
        directed = directed || bipartite;

        links.resize(numberOfRows);
        if(directed)
            links_t.resize(numberOfColumns);

    //load network file
        std::ifstream file(filename);
        if(file == 0)
        {
            reportError("file not found:",filename,1);
        }
        std::string line;
        while (std::getline(file, line))
        {
            std::istringstream iss(line);
            int s, t;
            T v;
            if(weighted)
            {
                if (!(iss >> s >> t >> v)) {
                    reportError("In file "+filename+", cannot read line: " + line,1);
                    break;
                }
            }
            else
            {
                if (!(iss >> s >> t)) {
                    reportError("In file "+filename+", cannot read line: " + line,1);
                    break;
                }
                v = true;
            }
            if(!zeroindexed)
            {
                t = t-1;
                s = s-1;
            }
            if(t>=numberOfColumns || s>=numberOfRows)
            {
                reportError("Larger node number  than specified found in file: " + filename,1);
            }
            if(!directed)
            {
                if(t>s){
                    if(t>maxTarget){ maxTarget = t; }
                    if(s>maxSource){ maxSource = s; }
                    links[s].push_back({t,v});
                    links[t].push_back({s,v});
                    totalEdges+=2;
                }
            }
            else
            {
                if(t>maxTarget){ maxTarget = t; }
                if(s>maxSource){ maxSource = s; }
                links[s].push_back({t,v});
                links_t[t].push_back({s,v});
                totalEdges++;
            }
        }

        reportInfo("file loaded");

    //create data structure for each node
        for(int n = 0 ; n < numberOfRows; n ++ )
        {
            for(int l = 0; l < links[n].size(); l++)
            {
                Link link = (links[n])[l];
                sources.push_back(n);
                targets.push_back(link.target);
                values.push_back(link.value);
            }
        }
        if(directed)
        {
            for(int n = 0 ; n < numberOfColumns; n ++ )
            {
                //sort link_t
                int comparisons = 0;
                //int startNodePos = 0;
                for(int i=1; i<links_t[n].size(); i++)
                {
                    int s = (links_t[n])[i].target;
                    int sm1 = (links_t[n])[i-1].target;

                    if(s< sm1){
                        int ii = i;
                        T v = (links_t[n])[i].value;
                        do{
                            (links_t[n])[ii].target = (links_t[n])[ii-1].target;
                            (links_t[n])[ii].value = (links_t[n])[ii-1].value;
                            ii--;
                            comparisons++;
                        }while(ii > 0 && (links_t[n])[ii - 1].target > s);
                        (links_t[n])[ii].target = s;
                        (links_t[n])[ii].value = v;
                    }
                }

                for(int l = 0; l < links_t[n].size(); l++)
                {
                    Link link = (links_t[n])[l];
                    sources_t.push_back(n);
                    targets_t.push_back(link.target);
                    values_t.push_back(link.value);
                }
            }
        }
        reportInfo("adjacency lists created");
    }

};
#endif // NETWORKDOCUMENT_H_INCLUDED
