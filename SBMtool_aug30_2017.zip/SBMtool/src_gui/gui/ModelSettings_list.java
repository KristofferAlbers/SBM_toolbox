/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/



package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;



public class ModelSettings_list extends JPanel{
	
	private static final long serialVersionUID = 1L;

	

	class SettingComponent
	{		
		Object[] o;
		Object original;
		Object originalValue;
		
		String type;
		String description = "-no description-";
		String longDescription = "";
		String name = "";
		Boolean isCritical;
		String initValue;
	}
	
	ArrayList<SettingComponent> parameterComponents;
	
	public ModelSettings_list()
	{
		parameterComponents = new ArrayList<>();
		
		
	}
	
	private String[] headings = new String[]{"type","name","value","*"};
	
	private Object[][] data = { {"BOOL","withmissing", Boolean.FALSE,Boolean.TRUE},
								{"INT","items",new Integer(10),Boolean.TRUE},
								{"FLOAT","alpha.init",new Double(10),Boolean.TRUE}  };

	public JTable table;
	JTextField nameLabel;
	JTextField infoLabel;
	ArrayList<SettingComponent> settings;
	final JFileChooser fc = new JFileChooser();
	
	final int type_column = 0;
	final int value_column = 2;
	final int critical_column = 3;
	static Color unselectable = new Color(240, 240, 254);
	public void parseAndSet(ArrayList<String> lines)
	{
		
		settings = new ArrayList<SettingComponent>();
		
		String name = "";
		String type = "";
		String description = "";
		String longdescription = "";
		boolean haslongdescription = false;
		Boolean initialBool = null;
		Integer initialInt = null;
		Double initialFloat  = null;
		String initialString = null;
		boolean critical = false;
		String ll;
		
		boolean insetting = false;
		for(int i = 0; i<lines.size(); i++)
		{
			String l = lines.get(i).trim();
			
			if(!insetting)
			{
				if(l.trim().equals("setting:"))
				{
					name = "";
					type = "";
					description = "";
					longdescription = "";
					critical = false;
					haslongdescription = false;
					insetting = true;
				}
			}
			else
			{	
				boolean writeparameter = false;
				//start new parameter
				if(l.equals("setting:"))
				{
					writeparameter = true;
				}
				else if(l.equals("parameter:")  )
				{
					writeparameter = true;
					insetting = false;
				}
				
				if(writeparameter)
				{

					SettingComponent test = new SettingComponent();
					if(type.equals("BOOL"))
					{		
						
						//test.o = new Object[]{type,name,Boolean.FALSE,critical};
						test.original = new Boolean(false);
						if(test.original == null)
							test.originalValue = null;
						else
							test.originalValue = new Boolean(initialBool);
						test.o = new Object[]{type,name,test.originalValue,critical};
					}						
					else if(type.equals("INT"))
					{
						test.original = new Integer(0);
						if(initialInt == null)
							test.originalValue = null;
						else
							test.originalValue = new Integer(initialInt);
						test.o = new Object[]{type,name,test.originalValue,critical};
					}						
					else if(type.equals("FLOAT"))
					{
						test.original = new Float(0);
						if(initialFloat == null)
							test.originalValue = null;
						else
							test.originalValue = new Double(initialFloat);
						test.o = new Object[]{type,name,test.originalValue,critical};
					}
					else
					{
						test.original = new String("");
						if(initialString == null)
						{
							test.originalValue = null;
						}
						else
							test.originalValue = new String(initialString);
						test.o = new Object[]{type,name,test.originalValue,critical};
					}						
					test.description = description;
					if(haslongdescription)
						test.longDescription = longdescription;
					else
						test.longDescription = description;
					
					test.name = name;
					test.type = type;
					test.isCritical = critical;
					settings.add(test);
					
					haslongdescription = false;
					critical = false;
				}
				else
				{
					String[] sublines = l.split(":");
					String s0 = sublines[0].trim();
					if(s0.equals("name"))
					{
						name = sublines[1].trim();
					}
					if(s0.equals("type"))
					{
						type = sublines[1].trim();
					}
					if(s0.equals("description"))
					{
						description = sublines[1].trim();
					}
					if(s0.equals("longdescription"))
					{
						longdescription = sublines[1].trim();
						haslongdescription = true;
					}
					if(s0.equals("critical"))
					{
						critical = Boolean.getBoolean(sublines[1].trim());
						if(sublines[1].trim().equals("1"))
						{
							critical = true;
						}
					}
					if(s0.equals("initial_int"))
					{
						initialInt = Integer.parseInt(sublines[1].trim());
					}
					if(s0.equals("initial_float"))
					{
						initialFloat = Double.parseDouble(sublines[1].trim());
					}
					if(s0.equals("initial_bool"))
					{
						initialBool = Boolean.parseBoolean(sublines[1].trim());
					}
					if(s0.equals("initial_string"))
					{
						initialString = (sublines[1].trim());
					}
					
					
				}								
			}
		}
		if(insetting)
		{
			SettingComponent test = new SettingComponent();
			if(type.equals("BOOL"))
			{						
				//test.o = new Object[]{type,name,Boolean.FALSE,critical};
				test.original = new Boolean(false);
				if(test.original == null)
					test.originalValue = null;
				else
					test.originalValue = new Boolean(initialBool);
				test.o = new Object[]{type,name,test.originalValue,critical};
			}						
			else if(type.equals("INT"))
			{
				//test.o = new Object[]{type,name,new Integer(1),critical};
				test.original = new Integer(0);
				if(initialInt == null)
					test.originalValue = null;
				else
					test.originalValue = new Integer(initialInt);
				test.o = new Object[]{type,name,test.originalValue,critical};
			}						
			else if(type.equals("FLOAT"))
			{
				//test.o = new Object[]{type,name,new Double(1),critical};
				test.original = new Float(0);
				if(initialFloat == null)
					test.originalValue = null;
				else
					test.originalValue = new Double(initialFloat);
				test.o = new Object[]{type,name,test.originalValue,critical};
			}
			else
			{
				//test.o = new Object[]{type,name,new String(),critical};
				test.original = new String("");
				if(initialString == null)
				{
					test.originalValue = null;
				}
				else
					test.originalValue = new String(initialString);
				test.o = new Object[]{type,name,test.originalValue,critical};
			}						
			test.description = description;
			if(haslongdescription)
				test.longDescription = longdescription;
			else
				test.longDescription = description;
			
			test.name = name;
			test.type = type;
			test.isCritical = critical;

			settings.add(test);
			haslongdescription = false;
			critical = false;
		}
		
		
		data = new Object[settings.size()][4];
		for(int i = 0;i<settings.size();i++)
		{
			data[i] = settings.get(i).o;
		}
		
		
		
		
		

		
		removeAll();		
		
		table = new JTable(data, headings){
			private static final long serialVersionUID = 1L;
			@SuppressWarnings("rawtypes")
			private Class selected_class;

            @SuppressWarnings("rawtypes")
			public TableCellRenderer getCellRenderer(int row, int column){

                selected_class = null;
                int columninmodel = convertColumnIndexToModel(column);             
                if (columninmodel == value_column || columninmodel == critical_column) {
                	if(getModel().getValueAt(row, columninmodel) == null)
            		{	
                		return getDefaultRenderer(settings.get(row).original.getClass());
            		}
                    Class found_class = getModel().getValueAt(row, columninmodel).getClass();                                           
                    return getDefaultRenderer(found_class);
                } 
                else
                {
                    return super.getCellRenderer(row, column);
                }
            }
            

            public boolean isCellEditable(int row, int column){

            	//nameLabel.setText(settings.get(row).name);
                //infoLabel.setText(settings.get(row).description);

            	int columninmodel = convertColumnIndexToModel(column);
                if(columninmodel!=value_column && !(settings.get(row).type.equals("FILEPATH") && columninmodel == type_column )  )
                	return false;
                else
                	return true;
            }
            @SuppressWarnings({ "rawtypes", "unchecked" })
			public Class getColumnClass(int column){
            	int columninmodel = convertColumnIndexToModel(column);
                if(columninmodel!=value_column)
            	{
            		return super.getColumnClass(column);
            	}
            	else
            		return selected_class;
            }

            public TableCellEditor getCellEditor(int row, int column){
                selected_class = null;
                
                
                int modelColumn = convertColumnIndexToModel(column);

                if(modelColumn == type_column && settings.get(row).type.equals("FILEPATH"))
                {
                	openFileEditor edtt = new openFileEditor(new JCheckBox("select file"),"FILEPATH",row);
                    return edtt;	
                }
                
                if (modelColumn == value_column || modelColumn == critical_column) {                    
                    if(getModel().getValueAt(row, modelColumn) == null)
                    {
                    	//setValueAt(settings.get(row).original, row, column);
                    	setValueAt(null, row, column);
                    	selected_class = settings.get(row).original.getClass();
                    }    
                    else
                    {
                    	selected_class = getModel().getValueAt(row, modelColumn).getClass();	
                    }                                     
                    return getDefaultEditor(selected_class);
                } else {
                    return super.getCellEditor(row, column);
                }
            }
            
            @Override
            public Component prepareRenderer(TableCellRenderer renderer,
                  int row, int column) {
               Component comp = (Component) super.prepareRenderer(renderer, row, column);
               int columninmodel = convertColumnIndexToModel(column);
               if(columninmodel!=value_column && !(settings.get(row).type.equals("FILEPATH") && columninmodel == type_column )  )
               {
            	   comp.setBackground(unselectable);      	 
               }
               else
               {
            	   comp.setBackground(Color.white);
               }
               comp = super.prepareRenderer(renderer, row, column);
               if(columninmodel == critical_column)
               {
            	   comp.setBackground(unselectable);            	
               }
               return comp;               
            }
            
            public String getToolTipText(MouseEvent event) {
                String tooltip = null;
                try{
                    Point point = event.getPoint();
                    int col = columnAtPoint(point);
                    int row = rowAtPoint(point);
                    tooltip = settings.get(row).longDescription;                    
                }catch(Exception ex){
                    ex.printStackTrace();
                }
                 return tooltip;
               }  
            
        };
        
        //allow row to be selected :)
        ListSelectionModel selmodel = table.getSelectionModel();        
        selmodel.addListSelectionListener(new ListSelectionListener() {			
			@Override
			public void valueChanged(ListSelectionEvent e) {
		        int[] selectedRow = table.getSelectedRows();
		        if(selectedRow.length>0)
		        {		        	
        			nameLabel.setText(settings.get(selectedRow[0]).name);
                    infoLabel.setText(settings.get(selectedRow[0]).description);

		        }
		        	
			}
		});
  
		
       // table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(0).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setPreferredWidth(1);
        table.getColumnModel().getColumn(3).setMaxWidth(1);
        
       
        nameLabel = new JTextField("");
        nameLabel.setBorder(new EmptyBorder(2, 2, 2, 2));
        infoLabel = new JTextField("");
        infoLabel.setBorder(new EmptyBorder(2, 2, 2, 2));
        
        nameLabel.setEditable(false);
        infoLabel.setEditable(false);
        
        JPanel tablepanel = new JPanel();
        tablepanel.setLayout(new BorderLayout());
        tablepanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        JScrollPane scrollPane = new JScrollPane(table);
        tablepanel.add(scrollPane,BorderLayout.CENTER);       
        
        
        JPanel northpanel = new JPanel(); northpanel.setLayout(new BorderLayout());
      //  northpanel.setBorder(new TitledBorder(new LineBorder(Color.lightGray),"hello"));
        
        northpanel.add(nameLabel,BorderLayout.NORTH);northpanel.add(infoLabel,BorderLayout.SOUTH);
        
        
        //tablepanel.add(nameLabel);
        tablepanel.add(northpanel,BorderLayout.NORTH);
        tablepanel.add(new JLabel("* indicates that setting must be set"),BorderLayout.SOUTH);

        String[][] objs = new String[][]{{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"},{"hello","hello"}};
        String[] nam = new String[]{"1","2"};
        JTable tables = new JTable(objs,nam);
        
        this.add((tablepanel));
        
        //this.add(new JScrollPane(tablepanel));
       
        // this.setBorder(new TitledBorder(new EmptyBorder(10, 10, 10, 10),"Settings"));
        
              
        repaint();
	}

	
	public void clear()
	{
		
		
	}
	
class openFileEditor extends DefaultCellEditor
{
	private static final long serialVersionUID = 1L;
	String text;
	int row;
	public openFileEditor(JCheckBox box,String text,int row)
	{
		super(box);
		this.text = text;
		this.row = row;
	}
    public Object getCellEditorValue()
    {  	
        fc.setApproveButtonText("Select");
        int choise = fc.showOpenDialog(table);
    	if(fc.getSelectedFile()!=null)
    	{	
            if(choise == JFileChooser.APPROVE_OPTION)
            {
            	table.setValueAt(fc.getSelectedFile().getAbsolutePath(), row, value_column);	
            }
    	}    	
        return text;
    }
	
};

	
}
