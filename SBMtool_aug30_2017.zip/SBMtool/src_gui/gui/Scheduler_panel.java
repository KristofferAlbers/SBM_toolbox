/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

import gui.ModelParameters_list.ParameterComponent;
import gui.ModelSettings_list.SettingComponent;

public class Scheduler_panel extends JPanel{

	ArrayList<String> modelNames;
	public MainFrame mainFrame;
	
	public JComboBox<String> modelBox = new JComboBox<String>();
	ModelSettings_list settingslist = new ModelSettings_list();
	ModelParameters_list parameterlist = new ModelParameters_list();

	SettingsField settingsField; 
	
	public Scheduler_panel(MainFrame mainFrame_, ArrayList<String> modelNames_ )
	{
		this.mainFrame = mainFrame_;
		this.modelNames = modelNames_;

		final JTextArea settingsArea = new JTextArea();
		settingsField = new SettingsField(mainFrame_);

		this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		final JPanel settingsPanel = new JPanel();


		JPanel modelSelecter = new JPanel();
		//modelSelecter.setLayout(new BoxLayout(modelSelecter, BoxLayout.X_AXIS));
		modelSelecter.setLayout(new BorderLayout());
		
		for (int i = 0; i < modelNames.size(); i++)
			modelBox.addItem(modelNames.get(i));
		
		
		JPanel northPanel = new JPanel();
		northPanel.setLayout(new BorderLayout());		
		northPanel.add(modelBox,BorderLayout.CENTER);
		northPanel.setBackground(Color.white);
		JLabel westLabel = new JLabel("scheduler\t(  ");
		JLabel eastLabel = new JLabel("  )   ");
		westLabel.setForeground(Color.blue);
		eastLabel.setForeground(Color.blue);		
		northPanel.add(westLabel, BorderLayout.WEST);
		northPanel.add(eastLabel, BorderLayout.EAST);
		modelSelecter.add(northPanel,BorderLayout.NORTH);
		
		
		BasicComboBoxRenderer basicComboBoxRenderer = new BasicComboBoxRenderer() {
			private static final long serialVersionUID = 1L;
			public Component getListCellRendererComponent(@SuppressWarnings("rawtypes") JList list, Object obj, int index, boolean isSelected, boolean cellfocus) {
	            if (isSelected) {	            	
	            	if(index>=0)
	            	{
		            	//mainFrame.hoverModel(modelNames.get(index));
	            	}
	               setBackground(list.getSelectionBackground());
	               setForeground(list.getSelectionForeground());	             
	            }
	            else {
	               setBackground(list.getBackground());
	               setForeground(list.getForeground());
	            }
	            setFont(list.getFont());
	            if(obj == null)
	            {
	            	setText("");
	            }
	            else
	            {
	            	setText(obj.toString());
	            	
	            }
	            return this;
	         }
	      };
		modelBox.setRenderer(basicComboBoxRenderer);

		modelBox.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				String modelName = (String)modelBox.getSelectedItem();
	            //mainFrame.hoverModel(modelName);
			}
			public void focusGained(FocusEvent e) {	}
		});
		
		modelBox.addMouseListener(new MouseAdapter() {
		      public  void mouseEntered(MouseEvent e) {
		    	  //mainFrame.setHintLabel("select model");
		      }

		      public void mouseExited(MouseEvent e) {
		    	  //mainFrame.clearHintLabel();
		      }
		});
		
		modelBox.addActionListener(new ActionListener() {
		      public void actionPerformed(ActionEvent e) {
		    	  String modelName = ""+((JComboBox<String>)e.getSource()).getSelectedItem();
		    	  
		    	 settingslist.parseAndSet( mainFrame.newSchedulerSelected(modelName) );
		    	 
		    	 String parametertext = "";
		    	 for(ParameterComponent pc : parameterlist.parameterComponents)
		    	 {
		    		 parametertext = parametertext + pc.name + " ("+pc.type+")\n"+pc.description + "\n\n";
		    	 }
		    	 
		    	 settingsField.assign("parameters",parametertext,settingslist,false);
		    	 
		    	 settingsArea.setText("");
		    	 
		    	 String text = "";
		    	 for(SettingComponent sc:settingslist.settings)
		    	 {
		    		 text = text+"    "+sc.name+ "  =  "+ sc.originalValue + "\n";
		    	 }
		    	 settingsArea.setText(text);
		    	 
		    	 //parameterlist.parseAndSet(  mainFrame.newModelSelected(modelName) );
		    	 //settingslist.parseAndSet( mainFrame.newModelSelected(modelName) );
		    	  //mainFrame.setHintLabel(modelName);
		      }
	    });
				
		
		
		
		//TitledBorder modelSelectBorder = new TitledBorder(new LineBorder(Color.lightGray, 1),"scheduler");
		//modelSelectBorder.setTitleColor(Color.blue);
		//modelSelecter.setBorder(modelSelectBorder);
		
		//modelSelecter.setMaximumSize(new Dimension(modelSelecter.getMaximumSize().width, modelSelecter.getMinimumSize().height));

		
		modelSelecter.add(settingsField,BorderLayout.CENTER);
		//modelSelecter.add(settingsArea,BorderLayout.CENTER);		
		
		settingsPanel.setLayout(new BoxLayout(settingsPanel, BoxLayout.X_AXIS));
		
	 	
		
		
		
		
		this.add(modelSelecter);
		//this.add(settingsPanel);


	}
	
	public String toString()
	{		
		String name = (String)modelBox.getSelectedItem();
		name = name.trim();
		return "scheduler("+name+")\n"+settingsField.settings.getText();
	}
}
