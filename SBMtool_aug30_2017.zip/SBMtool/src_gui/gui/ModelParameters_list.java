/*
Author: Kristoffer Jon Albers, Technical University of Denmark

Copyright (C) 2017,

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this software.  If not, see <http://www.gnu.org/licenses/>.
*/


package gui;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;




public class ModelParameters_list extends JPanel{

	
	
	class ParameterComponent extends JPanel
	{
		String type;
		String name;
		String description;
		
		JTextField typelabel = new JTextField("");
		JTextField  nameLabel = new JTextField("clustering.init_crp",SwingConstants.LEFT);
		JTextField descriptionfield = new JTextField("The number of items in the network");
	
		public ParameterComponent(String type_, String name_, String description_) 
		{
			
			{
				type = type_;
				name = name_;
				description = description_;
			
				
				nameLabel.setText("  "+name);
				descriptionfield.setText(description);
			

/*
				int bigtext_size = 16;
				int smalltext_size = 12;
				typelabel.setFont(new Font("", Font.PLAIN, smalltext_size));
				nameLabel.setFont(new Font("", Font.PLAIN, bigtext_size));
*/
				descriptionfield.setEditable(false);
				descriptionfield.setFocusable(false);
//				descriptionfield.setFont(new Font("Serif", Font.ITALIC, smalltext_size));
//				descriptionfield.setBackground(Color.white);
				descriptionfield.setBorder(new EmptyBorder(2,2,2,2));
				
				

				JPanel upperpanel = new JPanel();
				upperpanel.setLayout(new GridLayout(2, 1));
				
			
//					this.setBackground(Color.white);
//					upperpanel.setBackground(Color.white);

					
				//this.setBorder(new TitledBorder(new LineBorder(Color.lightGray,1),name));
				//this.setBorder(new TitledBorder(new LineBorder(Color.lightGray,1),""));
				
				this.setLayout(new FlowLayout());
				
				//upperpanel.add(nameLabel);
				
			
				
				this.add(nameLabel);
				this.add(descriptionfield);
				
				
				
				this.setMaximumSize(new Dimension(this.getMaximumSize().width, this.getMinimumSize().height));
				
			}
			
		}
		
	}
	
	ArrayList<ParameterComponent> parameterComponents = new ArrayList<>();
	
	public ModelParameters_list() 
	{
	

	}
	

	public void parseAndSet(ArrayList<String> lines)
	{
		removeAll();
		parameterComponents = new ArrayList<>();
		String name = "";
		String type = "";
		String description = "";
		String ll;
		
		boolean inparameter = false;
		for(int i = 0; i<lines.size(); i++)
		{
			String l = lines.get(i).trim();
			
			if(!inparameter)
			{
				if(l.trim().equals("parameter:"))
				{
					name = "";
					type = "";
					description = "";
					inparameter = true;
				}
			}
			else
			{	
				boolean writeparameter = false;
				//start new parameter
				if(l.equals("parameter:"))
				{
					writeparameter = true;
				}
				else if(l.equals("setting:")  )
				{
					writeparameter = true;
					inparameter = false;
				}
				
				if(writeparameter)
				{

					ParameterComponent test = new ParameterComponent(type,name,description);			
					parameterComponents.add(test);
					this.add(test);
				}
				else
				{
					String[] sublines = l.split(":");
					String s0 = sublines[0].trim();
					if(s0.equals("name"))
					{
						name = sublines[1].trim();
					}
					if(s0.equals("type"))
					{
						type = sublines[1].trim();
					}
					if(s0.equals("description"))
					{
						description = sublines[1].trim();
					}
				}								
			}
		}
		if(inparameter)
		{
			ParameterComponent test = new ParameterComponent(type,name,description);			
			parameterComponents.add(test);
			this.add(test);
		}
		
		this.setLayout(new GridLayout(this.getComponentCount(),1));

		repaint();
	}

}









